const path = require("path");
const fs = require("fs");

function toBool(value, defaultValue) {
  if (value === undefined || value === null || value === "") return defaultValue;
  return String(value).toLowerCase() === "true";
}

function toInt(value, defaultValue) {
  const n = Number(value);
  if (!Number.isFinite(n)) return defaultValue;
  return Math.trunc(n);
}

function resolveSQLitePath(input) {
  const raw = input || "./database/app.db";
  if (path.isAbsolute(raw)) return raw;
  return path.resolve(process.cwd(), raw);
}

function stripQuotes(raw) {
  const value = String(raw || "").trim();
  if (
    (value.startsWith('"') && value.endsWith('"')) ||
    (value.startsWith("'") && value.endsWith("'"))
  ) {
    return value.slice(1, -1);
  }
  return value;
}

function loadEnvFile(filePath, targetEnv = process.env) {
  if (!fs.existsSync(filePath)) return;
  const text = fs.readFileSync(filePath, "utf8");
  for (const line of text.split(/\r?\n/)) {
    const trimmed = String(line || "").trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const idx = trimmed.indexOf("=");
    if (idx <= 0) continue;
    const key = trimmed.slice(0, idx).trim();
    if (!key || key in targetEnv) continue;
    const rawValue = trimmed.slice(idx + 1);
    targetEnv[key] = stripQuotes(rawValue);
  }
}

function loadEnvFiles({ cwd = process.cwd(), env = process.env } = {}) {
  const nodeEnv = env.NODE_ENV || "development";
  loadEnvFile(path.resolve(cwd, ".env"), env);
  loadEnvFile(path.resolve(cwd, `.env.${nodeEnv}`), env);
}

function loadConfig(env = process.env) {
  const nodeEnv = env.NODE_ENV || "development";

  return {
    app: {
      env: nodeEnv,
      host: env.HOST || "0.0.0.0",
      port: toInt(env.PORT, 8088),
      logLevel: env.LOG_LEVEL || (nodeEnv === "production" ? "info" : "debug"),
    },
    auth: {
      accessTokenTtlMs: toInt(env.ACCESS_TOKEN_TTL_MS, 2 * 60 * 60 * 1000),
      refreshTokenTtlMs: toInt(env.REFRESH_TOKEN_TTL_MS, 7 * 24 * 60 * 60 * 1000),
    },
    order: {
      payTimeoutMs: toInt(env.ORDER_PAY_TIMEOUT_MS, 15 * 60 * 1000),
      pickupTimeoutMs: toInt(env.ORDER_PICKUP_TIMEOUT_MS, toInt(env.ORDER_TIMEOUT_MS, 15 * 60 * 1000)),
    },
    storage: {
      sqliteEnabled: toBool(env.SQLITE_ENABLED, true),
      sqlitePath: resolveSQLitePath(env.SQLITE_PATH),
    },
    amap: {
      webKey: String(env.AMAP_WEB_KEY || "").trim(),
      jsKey: String(env.AMAP_JS_KEY || env.AMAP_WEB_KEY || "").trim(),
      securityJsCode: String(env.AMAP_SECURITY_JS_CODE || "").trim(),
      geocodeEndpoint: String(env.AMAP_GEOCODE_ENDPOINT || "https://restapi.amap.com/v3/geocode/geo").trim(),
      timeoutMs: toInt(env.AMAP_TIMEOUT_MS, 4000),
    },
    alipayMcp: {
      enabled: toBool(env.ALIPAY_MCP_ENABLED, false),
      mode: String(env.ALIPAY_MCP_MODE || "mock").trim().toLowerCase() === "live" ? "live" : "mock",
      baseUrl: String(env.ALIPAY_MCP_BASE_URL || "").trim(),
      apiKey: String(env.ALIPAY_MCP_API_KEY || "").trim(),
      timeoutMs: toInt(env.ALIPAY_MCP_TIMEOUT_MS, 6000),
      retryMax: toInt(env.ALIPAY_MCP_RETRY_MAX, 1),
    },
  };
}

module.exports = { loadConfig, loadEnvFiles };

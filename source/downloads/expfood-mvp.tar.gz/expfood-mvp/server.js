const http = require("http");
const fs = require("fs");
const path = require("path");
const { randomBytes, createHash } = require("crypto");
const { URL } = require("url");
const { loadConfig, loadEnvFiles } = require("./src/config");
const { createRepositories } = require("./src/repositories/createRepositories");
const { createAlipayMcpService } = require("./src/services/alipayMcpService");

loadEnvFiles();
const config = loadConfig();
const HOST = config.app.host;
const PORT = config.app.port;
const PUBLIC_DIR = path.join(__dirname, "public");
const ORDER_PAY_TIMEOUT_MS = config.order.payTimeoutMs;
const ORDER_PICKUP_TIMEOUT_MS = config.order.pickupTimeoutMs;
const ACCESS_TOKEN_TTL_MS = Math.max(1000, Number(config.auth.accessTokenTtlMs) || 2 * 60 * 60 * 1000);
const REFRESH_TOKEN_TTL_MS = Math.max(60 * 1000, Number(config.auth.refreshTokenTtlMs) || 7 * 24 * 60 * 60 * 1000);
const MAX_PRODUCT_IMAGES = 6;
const MAX_PRODUCT_DETAIL_IMAGES = 12;
const MAX_IMAGE_REF_LENGTH = 2048;
const MAX_SINGLE_DATA_IMAGE_BYTES = 8 * 1024 * 1024;
const MAX_TOTAL_DATA_IMAGE_BYTES = 40 * 1024 * 1024;
const MAX_REQUEST_BODY_BYTES = 48 * 1024 * 1024;
const AMAP_WEB_KEY = String(config.amap.webKey || "").trim();
const AMAP_JS_KEY = String(config.amap.jsKey || "").trim();
const AMAP_SERVICE_KEY = AMAP_WEB_KEY || AMAP_JS_KEY;
const AMAP_SECURITY_JS_CODE = String(config.amap.securityJsCode || "").trim();
const AMAP_GEOCODE_ENDPOINT = String(config.amap.geocodeEndpoint || "https://restapi.amap.com/v3/geocode/geo").trim();
const AMAP_TIMEOUT_MS = Math.max(500, Number(config.amap.timeoutMs) || 4000);
const ALIPAY_MCP = config.alipayMcp || {};
const SQLITE_ENABLED = config.storage.sqliteEnabled;
const SQLITE_PATH = config.storage.sqlitePath;

const users = [
  {
    id: 1,
    phone: "13800138000",
    role: "buyer",
    nickname: "buyer-demo",
    full_name: "买家示例",
    buyer_address: "上海市浦东新区示例路1号",
  },
  {
    id: 2,
    phone: "13800138001",
    role: "merchant",
    nickname: "merchant-demo",
    shop_id: 1,
    shop_name: "demo shop",
    shop_address: "demo road 1",
    contact_name: "merchant-demo",
    contact_phone: "13800138001",
    business_hours: "10:00-20:00",
    shop_lat: 31.2304,
    shop_lng: 121.4737,
    license_images: ["/assets/product-bread-main.svg"],
    merchant_status: "approved",
    is_open: true,
  },
];

const products = [
  {
    id: 1,
    shop_id: 1,
    category_id: 1,
    name: "demo bread",
    description: "daily fresh",
    images: ["/assets/product-bread-main.svg", "/assets/product-bread-angle.svg"],
    detail_images: ["/assets/product-bread-detail.svg"],
    ingredients: "小麦粉, 酵母, 水, 黄油",
    allergen_info: "含麸质, 含乳制品",
    production_date: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString().slice(0, 10),
    best_before_date: new Date(Date.now() + 1 * 24 * 3600 * 1000).toISOString().slice(0, 10),
    pickup_start_time: "10:00",
    pickup_end_time: "20:00",
    original_price: 20,
    discount_price: 10,
    discount: 50,
    stock: 20,
    expire_time: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
    status: 1,
    created_at: new Date().toISOString(),
  },
];

const orders = [];
const cartItems = [];
const accessTokens = new Map();
const refreshTokens = new Map();
const productLocks = new Map();
const idempotencyRecords = new Map();
let sqliteDb = null;
const seq = { user: 2, product: 2, order: 1, cart: 1 };
let repos = null;
const alipayMcpService = createAlipayMcpService(ALIPAY_MCP);

const ERROR_CODE_MAP = {
  400: "BAD_REQUEST",
  401: "UNAUTHORIZED",
  403: "FORBIDDEN",
  404: "NOT_FOUND",
  409: "CONFLICT",
  422: "UNPROCESSABLE_ENTITY",
  500: "INTERNAL_ERROR",
  501: "NOT_IMPLEMENTED",
};

function defaultErrorCode(status) {
  return ERROR_CODE_MAP[status] || `HTTP_${status}`;
}

function genRequestID() {
  return randomBytes(6).toString("hex");
}

function stableStringify(value) {
  if (value === null || value === undefined) return String(value);
  if (Array.isArray(value)) return `[${value.map((item) => stableStringify(item)).join(",")}]`;
  if (typeof value === "object") {
    const keys = Object.keys(value).sort();
    return `{${keys.map((k) => `${JSON.stringify(k)}:${stableStringify(value[k])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

function hashPayload(value) {
  return createHash("sha256").update(stableStringify(value)).digest("hex");
}

function cloneJson(value) {
  return JSON.parse(JSON.stringify(value));
}

function normalizeIdempotencyKey(raw) {
  const key = String(raw || "").trim();
  if (!key) return "";
  if (key.length > 128) return "";
  return key;
}

function extractIdempotencyKey(req, body) {
  const headerKey = normalizeIdempotencyKey(req.headers["idempotency-key"]);
  if (headerKey) return headerKey;
  return normalizeIdempotencyKey(body && body.idempotency_key);
}

function pruneIdempotencyRecords(maxAgeMs = 24 * 60 * 60 * 1000) {
  const now = Date.now();
  for (const [k, rec] of idempotencyRecords.entries()) {
    if (rec.state !== "done") continue;
    if (!Number.isFinite(rec.finishedAtMs)) continue;
    if (now - rec.finishedAtMs > maxAgeMs) {
      idempotencyRecords.delete(k);
    }
  }
}

async function runIdempotent({ scope, actorId, key, requestPayload, execute }) {
  if (!key) return execute();
  if (Math.random() < 0.02) pruneIdempotencyRecords();
  const mapKey = `${scope}:${actorId}:${key}`;
  const reqHash = hashPayload(requestPayload || {});
  const existing = idempotencyRecords.get(mapKey);
  if (existing) {
    if (existing.requestHash !== reqHash) {
      return {
        status: 409,
        payload: {
          code: 409,
          message: "idempotency key reused with different request",
          error_code: "IDEMPOTENCY_KEY_REUSED",
        },
      };
    }
    if (existing.state === "done") {
      return { status: existing.status, payload: cloneJson(existing.payload) };
    }
    return {
      status: 409,
      payload: {
        code: 409,
        message: "request is processing",
        error_code: "IDEMPOTENCY_IN_PROGRESS",
      },
    };
  }

  const record = { state: "processing", requestHash: reqHash, createdAtMs: Date.now() };
  idempotencyRecords.set(mapKey, record);
  try {
    const result = await execute();
    record.state = "done";
    record.status = result.status;
    record.payload = cloneJson(result.payload);
    record.finishedAtMs = Date.now();
    return { status: result.status, payload: cloneJson(result.payload) };
  } catch (err) {
    idempotencyRecords.delete(mapKey);
    throw err;
  }
}

function logRequest(req, res, startedAtMs) {
  const log = {
    ts: new Date().toISOString(),
    level: res.statusCode >= 500 ? "error" : "info",
    request_id: res.localsRequestId,
    method: req.method,
    path: req.url,
    status: res.statusCode,
    duration_ms: Date.now() - startedAtMs,
    error_code: res.localsErrorCode || null,
  };
  console.log(JSON.stringify(log));
}

function getProductById(id) {
  return products.find((p) => p.id === id);
}

function findMerchantByShopID(shopID) {
  const normalizedShopID = Number(shopID);
  if (!Number.isInteger(normalizedShopID) || normalizedShopID <= 0) return null;
  return (
    users.find(
      (u) =>
        u.role === "merchant" &&
        (Number(u.shop_id || 0) === normalizedShopID || Number(u.id || 0) === normalizedShopID)
    ) || null
  );
}

function isMerchantOpenByShopID(shopID) {
  const merchant = findMerchantByShopID(shopID);
  return Boolean(merchant && merchant.is_open !== false);
}

function toDateTimeString(value) {
  if (!value) return null;
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString().slice(0, 19).replace("T", " ");
}

function fromDbDate(value) {
  if (!value) return null;
  return new Date(value).toISOString();
}

function mapAlipayUpstreamError(prefix, result) {
  const code = String((result && result.error_code) || "");
  if (code === "ALIPAY_MCP_TIMEOUT") {
    return {
      status: 504,
      payload: {
        code: 504,
        message: `${prefix} upstream timeout`,
        error_code: `${prefix.toUpperCase()}_UPSTREAM_TIMEOUT`,
        data: {
          upstream_error_code: code,
          upstream_detail: (result && result.detail) || null,
        },
      },
    };
  }
  if (code === "ALIPAY_MCP_NETWORK_ERROR") {
    return {
      status: 502,
      payload: {
        code: 502,
        message: `${prefix} upstream network error`,
        error_code: `${prefix.toUpperCase()}_UPSTREAM_NETWORK_ERROR`,
        data: {
          upstream_error_code: code,
          upstream_detail: (result && result.detail) || null,
        },
      },
    };
  }
  if (code === "ALIPAY_MCP_HTTP_ERROR") {
    return {
      status: 502,
      payload: {
        code: 502,
        message: (result && result.message) || `${prefix} upstream http error`,
        error_code: `${prefix.toUpperCase()}_UPSTREAM_HTTP_ERROR`,
        data: {
          upstream_error_code: code,
          upstream_http_status: Number((result && result.http_status) || 0) || null,
          upstream_detail: (result && result.detail) || null,
        },
      },
    };
  }
  return {
    status: 502,
    payload: {
      code: 502,
      message: (result && result.message) || `${prefix} failed`,
      error_code: `${prefix.toUpperCase()}_FAILED`,
      data: {
        upstream_error_code: code || null,
        upstream_detail: (result && result.detail) || null,
      },
    },
  };
}

function assertAlipayMcpConfigReady() {
  const check = alipayMcpService.getConfigCheck();
  if (!check.enabled) return;
  if (check.mode !== "live") return;
  if (check.live_ready) return;
  throw new Error(
    `[ALIPAY_MCP] live mode config invalid, missing: ${check.missing_fields.join(", ")}`
  );
}

async function initSQLite() {
  if (!SQLITE_ENABLED) return;
  let Database;
  try {
    Database = require("better-sqlite3");
  } catch (err) {
    console.warn("[SQLITE] better-sqlite3 not installed, fallback to memory mode");
    return;
  }

  fs.mkdirSync(path.dirname(SQLITE_PATH), { recursive: true });
  sqliteDb = new Database(SQLITE_PATH);
  sqliteDb.pragma("journal_mode = WAL");

  sqliteDb.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      phone TEXT NOT NULL,
      role TEXT NOT NULL,
      nickname TEXT NOT NULL,
      full_name TEXT NULL,
      buyer_address TEXT NULL,
      shop_id INTEGER NULL,
      shop_name TEXT NULL,
      shop_address TEXT NULL,
      contact_name TEXT NULL,
      contact_phone TEXT NULL,
      business_hours TEXT NULL,
      shop_lat REAL NULL,
      shop_lng REAL NULL,
      license_images_json TEXT NULL,
      merchant_status TEXT NULL,
      is_open INTEGER NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(phone, role)
    );

    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      shop_id INTEGER NOT NULL,
      category_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      description TEXT NULL,
      images_json TEXT NOT NULL,
      detail_images_json TEXT NULL,
      ingredients TEXT NULL,
      allergen_info TEXT NULL,
      production_date TEXT NULL,
      best_before_date TEXT NULL,
      pickup_start_time TEXT NULL,
      pickup_end_time TEXT NULL,
      original_price REAL NOT NULL,
      discount_price REAL NOT NULL,
      discount INTEGER NOT NULL,
      stock INTEGER NOT NULL,
      expire_time TEXT NOT NULL,
      status INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NULL
    );

    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_no TEXT NOT NULL UNIQUE,
      user_id INTEGER NOT NULL,
      shop_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      product_name TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      total_amount REAL NOT NULL,
      verify_code TEXT NULL,
      status INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      pay_expire_at TEXT NULL,
      paid_at TEXT NULL,
      payment_no TEXT NULL,
      payment_channel TEXT NULL,
      payment_mode TEXT NULL,
      payment_meta_json TEXT NULL,
      expires_at TEXT NULL,
      cancel_reason TEXT NULL,
      canceled_at TEXT NULL,
      verified_at TEXT NULL,
      verified_by INTEGER NULL,
      refund_reason TEXT NULL,
      refund_requested_at TEXT NULL,
      refund_approved_at TEXT NULL,
      refund_by INTEGER NULL,
      refund_no TEXT NULL,
      refund_channel TEXT NULL,
      refund_mode TEXT NULL,
      refund_meta_json TEXT NULL,
      checkout_batch_no TEXT NULL,
      settled_at TEXT NULL,
      settle_no TEXT NULL,
      settled_by INTEGER NULL,
      settlement_channel TEXT NULL,
      settlement_mode TEXT NULL,
      settlement_meta_json TEXT NULL
    );

    CREATE TABLE IF NOT EXISTS cart_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      shop_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      product_name TEXT NOT NULL,
      product_price REAL NOT NULL,
      quantity INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
  `);

  // Backward-compatible migration for existing DB files.
  const alterIfNeeded = (sql) => {
    try {
      sqliteDb.exec(sql);
    } catch (_err) {
      // ignore duplicate-column errors
    }
  };
  alterIfNeeded("ALTER TABLE orders ADD COLUMN pay_expire_at TEXT NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN paid_at TEXT NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN payment_no TEXT NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN payment_channel TEXT NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN payment_mode TEXT NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN payment_meta_json TEXT NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN refund_reason TEXT NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN refund_requested_at TEXT NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN refund_approved_at TEXT NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN refund_by INTEGER NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN refund_no TEXT NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN refund_channel TEXT NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN refund_mode TEXT NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN refund_meta_json TEXT NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN checkout_batch_no TEXT NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN settled_at TEXT NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN settle_no TEXT NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN settled_by INTEGER NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN settlement_channel TEXT NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN settlement_mode TEXT NULL;");
  alterIfNeeded("ALTER TABLE orders ADD COLUMN settlement_meta_json TEXT NULL;");
  alterIfNeeded("ALTER TABLE users ADD COLUMN shop_name TEXT NULL;");
  alterIfNeeded("ALTER TABLE users ADD COLUMN full_name TEXT NULL;");
  alterIfNeeded("ALTER TABLE users ADD COLUMN buyer_address TEXT NULL;");
  alterIfNeeded("ALTER TABLE users ADD COLUMN shop_address TEXT NULL;");
  alterIfNeeded("ALTER TABLE users ADD COLUMN contact_name TEXT NULL;");
  alterIfNeeded("ALTER TABLE users ADD COLUMN contact_phone TEXT NULL;");
  alterIfNeeded("ALTER TABLE users ADD COLUMN business_hours TEXT NULL;");
  alterIfNeeded("ALTER TABLE users ADD COLUMN shop_lat REAL NULL;");
  alterIfNeeded("ALTER TABLE users ADD COLUMN shop_lng REAL NULL;");
  alterIfNeeded("ALTER TABLE users ADD COLUMN license_images_json TEXT NULL;");
  alterIfNeeded("ALTER TABLE users ADD COLUMN merchant_status TEXT NULL;");
  alterIfNeeded("ALTER TABLE users ADD COLUMN is_open INTEGER NULL;");
  alterIfNeeded("ALTER TABLE products ADD COLUMN detail_images_json TEXT NULL;");
  alterIfNeeded("ALTER TABLE products ADD COLUMN ingredients TEXT NULL;");
  alterIfNeeded("ALTER TABLE products ADD COLUMN allergen_info TEXT NULL;");
  alterIfNeeded("ALTER TABLE products ADD COLUMN production_date TEXT NULL;");
  alterIfNeeded("ALTER TABLE products ADD COLUMN best_before_date TEXT NULL;");
  alterIfNeeded("ALTER TABLE products ADD COLUMN pickup_start_time TEXT NULL;");
  alterIfNeeded("ALTER TABLE products ADD COLUMN pickup_end_time TEXT NULL;");

  const userCount = sqliteDb.prepare("SELECT COUNT(*) AS c FROM users").get().c;
  if (Number(userCount) === 0) {
    const now = toDateTimeString(new Date());
    sqliteDb
      .prepare(
        "INSERT INTO users (phone, role, nickname, full_name, buyer_address, shop_id, shop_name, shop_address, contact_name, contact_phone, business_hours, shop_lat, shop_lng, license_images_json, merchant_status, is_open, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?), (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
      )
      .run(
        "13800138000",
        "buyer",
        "buyer-demo",
        "买家示例",
        "上海市浦东新区示例路1号",
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        now,
        now,
        "13800138001",
        "merchant",
        "merchant-demo",
        null,
        null,
        1,
        "demo shop",
        "demo road 1",
        "merchant-demo",
        "13800138001",
        "10:00-20:00",
        31.2304,
        121.4737,
        JSON.stringify(["/assets/product-bread-main.svg"]),
        "approved",
        1,
        now,
        now
      );
  }

  const productCount = sqliteDb.prepare("SELECT COUNT(*) AS c FROM products").get().c;
  if (Number(productCount) === 0) {
    const now = new Date();
    sqliteDb
      .prepare(
        `INSERT INTO products
        (shop_id, category_id, name, description, images_json, detail_images_json, ingredients, allergen_info, production_date, best_before_date, pickup_start_time, pickup_end_time, original_price, discount_price, discount, stock, expire_time, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        1,
        1,
        "demo bread",
        "daily fresh",
        JSON.stringify(["/assets/product-bread-main.svg", "/assets/product-bread-angle.svg"]),
        JSON.stringify(["/assets/product-bread-detail.svg"]),
        "小麦粉, 酵母, 水, 黄油",
        "含麸质, 含乳制品",
        new Date(now.getTime() - 2 * 24 * 3600 * 1000).toISOString().slice(0, 10),
        new Date(now.getTime() + 1 * 24 * 3600 * 1000).toISOString().slice(0, 10),
        "10:00",
        "20:00",
        20,
        10,
        50,
        20,
        toDateTimeString(new Date(now.getTime() + 24 * 3600 * 1000)),
        1,
        toDateTimeString(now),
        toDateTimeString(now)
      );
  }

  await hydrateMemoryFromSQLite();
  console.log("[SQLITE] connected and hydrated");
}

async function hydrateMemoryFromSQLite() {
  if (!sqliteDb) return;
  const userRows = sqliteDb.prepare("SELECT * FROM users ORDER BY id ASC").all();
  users.splice(
    0,
    users.length,
    ...userRows.map((r) => ({
      id: Number(r.id),
      phone: r.phone,
      role: r.role,
      nickname: r.nickname,
      full_name: r.full_name || "",
      buyer_address: r.buyer_address || "",
      shop_id: r.shop_id === null ? null : Number(r.shop_id),
      shop_name: r.shop_name || "",
      shop_address: r.shop_address || "",
      contact_name: r.contact_name || "",
      contact_phone: r.contact_phone || "",
      business_hours: r.business_hours || "",
      shop_lat: r.shop_lat === null ? null : Number(r.shop_lat),
      shop_lng: r.shop_lng === null ? null : Number(r.shop_lng),
      license_images: JSON.parse(r.license_images_json || "[]"),
      merchant_status: r.merchant_status || "",
      is_open: r.role === "merchant" ? (r.is_open === null ? true : Number(r.is_open) !== 0) : false,
    }))
  );

  const productRows = sqliteDb.prepare("SELECT * FROM products ORDER BY id ASC").all();
  products.splice(
    0,
    products.length,
    ...productRows.map((r) => ({
      id: Number(r.id),
      shop_id: Number(r.shop_id),
      category_id: Number(r.category_id),
      name: r.name,
      description: r.description || "",
      images: JSON.parse(r.images_json || "[]"),
      detail_images: JSON.parse(r.detail_images_json || "[]"),
      ingredients: r.ingredients || "",
      allergen_info: r.allergen_info || "",
      production_date: r.production_date || "",
      best_before_date: r.best_before_date || "",
      pickup_start_time: r.pickup_start_time || "",
      pickup_end_time: r.pickup_end_time || "",
      original_price: Number(r.original_price),
      discount_price: Number(r.discount_price),
      discount: Number(r.discount),
      stock: Number(r.stock),
      expire_time: fromDbDate(r.expire_time),
      status: Number(r.status),
      created_at: fromDbDate(r.created_at),
      updated_at: fromDbDate(r.updated_at),
    }))
  );

  const orderRows = sqliteDb.prepare("SELECT * FROM orders ORDER BY id ASC").all();
  orders.splice(
    0,
    orders.length,
    ...orderRows.map((r) => ({
      id: Number(r.id),
      order_no: r.order_no,
      user_id: Number(r.user_id),
      shop_id: Number(r.shop_id),
      product_id: Number(r.product_id),
      product_name: r.product_name,
      quantity: Number(r.quantity),
      total_amount: Number(r.total_amount),
      verify_code: r.verify_code,
      status: Number(r.status),
      created_at: fromDbDate(r.created_at),
      pay_expire_at: fromDbDate(r.pay_expire_at) || undefined,
      paid_at: fromDbDate(r.paid_at) || undefined,
      payment_no: r.payment_no || undefined,
      payment_channel: r.payment_channel || undefined,
      payment_mode: r.payment_mode || undefined,
      payment_meta: (() => {
        try {
          return r.payment_meta_json ? JSON.parse(r.payment_meta_json) : undefined;
        } catch (_err) {
          return undefined;
        }
      })(),
      expires_at: fromDbDate(r.expires_at),
      cancel_reason: r.cancel_reason || undefined,
      canceled_at: fromDbDate(r.canceled_at) || undefined,
      verified_at: fromDbDate(r.verified_at) || undefined,
      verified_by: r.verified_by === null ? undefined : Number(r.verified_by),
      refund_reason: r.refund_reason || undefined,
      refund_requested_at: fromDbDate(r.refund_requested_at) || undefined,
      refund_approved_at: fromDbDate(r.refund_approved_at) || undefined,
      refund_by: r.refund_by === null ? undefined : Number(r.refund_by),
      refund_no: r.refund_no || undefined,
      refund_channel: r.refund_channel || undefined,
      refund_mode: r.refund_mode || undefined,
      refund_meta: (() => {
        try {
          return r.refund_meta_json ? JSON.parse(r.refund_meta_json) : undefined;
        } catch (_err) {
          return undefined;
        }
      })(),
      checkout_batch_no: r.checkout_batch_no || undefined,
      settled_at: fromDbDate(r.settled_at) || undefined,
      settle_no: r.settle_no || undefined,
      settled_by: r.settled_by === null ? undefined : Number(r.settled_by),
      settlement_channel: r.settlement_channel || undefined,
      settlement_mode: r.settlement_mode || undefined,
      settlement_meta: (() => {
        try {
          return r.settlement_meta_json ? JSON.parse(r.settlement_meta_json) : undefined;
        } catch (_err) {
          return undefined;
        }
      })(),
    }))
  );

  const cartRows = sqliteDb.prepare("SELECT * FROM cart_items ORDER BY id ASC").all();
  cartItems.splice(
    0,
    cartItems.length,
    ...cartRows.map((r) => ({
      id: Number(r.id),
      user_id: Number(r.user_id),
      shop_id: Number(r.shop_id),
      product_id: Number(r.product_id),
      product_name: r.product_name,
      product_price: Number(r.product_price),
      quantity: Number(r.quantity),
      created_at: fromDbDate(r.created_at),
      updated_at: fromDbDate(r.updated_at),
    }))
  );

  seq.user = Math.max(0, ...users.map((u) => u.id));
  seq.product = Math.max(1, ...products.map((p) => p.id)) + 1;
  seq.order = Math.max(1, ...orders.map((o) => o.id)) + 1;
  seq.cart = Math.max(1, ...cartItems.map((it) => it.id)) + 1;
}

async function withProductLock(productID, task) {
  const prev = productLocks.get(productID) || Promise.resolve();
  let release;
  const next = new Promise((resolve) => {
    release = resolve;
  });
  productLocks.set(productID, prev.then(() => next));
  await prev;
  try {
    return await task();
  } finally {
    release();
    if (productLocks.get(productID) === next) {
      productLocks.delete(productID);
    }
  }
}

async function persistUser(user) {
  if (!sqliteDb) return;
  const now = toDateTimeString(new Date());
  sqliteDb
    .prepare(
      `INSERT INTO users (id, phone, role, nickname, full_name, buyer_address, shop_id, shop_name, shop_address, contact_name, contact_phone, business_hours, shop_lat, shop_lng, license_images_json, merchant_status, is_open, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         nickname=excluded.nickname,
         full_name=excluded.full_name,
         buyer_address=excluded.buyer_address,
         shop_id=excluded.shop_id,
         shop_name=excluded.shop_name,
         shop_address=excluded.shop_address,
         contact_name=excluded.contact_name,
         contact_phone=excluded.contact_phone,
         business_hours=excluded.business_hours,
         shop_lat=excluded.shop_lat,
         shop_lng=excluded.shop_lng,
         license_images_json=excluded.license_images_json,
         merchant_status=excluded.merchant_status,
         is_open=excluded.is_open,
         updated_at=excluded.updated_at`
    )
    .run(
      user.id,
      user.phone,
      user.role,
      user.nickname,
      user.full_name || null,
      user.buyer_address || null,
      user.shop_id || null,
      user.shop_name || null,
      user.shop_address || null,
      user.contact_name || null,
      user.contact_phone || null,
      user.business_hours || null,
      user.shop_lat === undefined ? null : user.shop_lat,
      user.shop_lng === undefined ? null : user.shop_lng,
      JSON.stringify(user.license_images || []),
      user.merchant_status || null,
      user.role === "merchant" ? (user.is_open === false ? 0 : 1) : null,
      now,
      now
    );
}

async function persistProduct(product) {
  if (!sqliteDb) return;
  sqliteDb
    .prepare(
      `INSERT INTO products
       (id, shop_id, category_id, name, description, images_json, detail_images_json, ingredients, allergen_info, production_date, best_before_date, pickup_start_time, pickup_end_time, original_price, discount_price, discount, stock, expire_time, status, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
        category_id=excluded.category_id,
        name=excluded.name,
        description=excluded.description,
        images_json=excluded.images_json,
        detail_images_json=excluded.detail_images_json,
        ingredients=excluded.ingredients,
        allergen_info=excluded.allergen_info,
        production_date=excluded.production_date,
        best_before_date=excluded.best_before_date,
        pickup_start_time=excluded.pickup_start_time,
        pickup_end_time=excluded.pickup_end_time,
        original_price=excluded.original_price,
        discount_price=excluded.discount_price,
        discount=excluded.discount,
        stock=excluded.stock,
        expire_time=excluded.expire_time,
        status=excluded.status,
        updated_at=excluded.updated_at`
    )
    .run(
      product.id,
      product.shop_id,
      product.category_id,
      product.name,
      product.description || "",
      JSON.stringify(product.images || []),
      JSON.stringify(product.detail_images || []),
      product.ingredients || "",
      product.allergen_info || "",
      product.production_date || "",
      product.best_before_date || "",
      product.pickup_start_time || "",
      product.pickup_end_time || "",
      product.original_price,
      product.discount_price,
      product.discount || 0,
      product.stock,
      toDateTimeString(product.expire_time),
      product.status,
      toDateTimeString(product.created_at),
      toDateTimeString(product.updated_at || product.created_at)
    );
}

async function persistOrder(order) {
  if (!sqliteDb) return;
  const normalizedExpiresAt = toDateTimeString(order.expires_at) || "";
  sqliteDb
    .prepare(
      `INSERT INTO orders
      (id, order_no, user_id, shop_id, product_id, product_name, quantity, total_amount, verify_code, status, created_at, pay_expire_at, paid_at, payment_no, payment_channel, payment_mode, payment_meta_json, expires_at, cancel_reason, canceled_at, verified_at, verified_by, refund_reason, refund_requested_at, refund_approved_at, refund_by, refund_no, refund_channel, refund_mode, refund_meta_json, checkout_batch_no, settled_at, settle_no, settled_by, settlement_channel, settlement_mode, settlement_meta_json)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        verify_code=excluded.verify_code,
        status=excluded.status,
        pay_expire_at=excluded.pay_expire_at,
        paid_at=excluded.paid_at,
        payment_no=excluded.payment_no,
        payment_channel=excluded.payment_channel,
        payment_mode=excluded.payment_mode,
        payment_meta_json=excluded.payment_meta_json,
        expires_at=excluded.expires_at,
        cancel_reason=excluded.cancel_reason,
        canceled_at=excluded.canceled_at,
        verified_at=excluded.verified_at,
        verified_by=excluded.verified_by,
        refund_reason=excluded.refund_reason,
        refund_requested_at=excluded.refund_requested_at,
        refund_approved_at=excluded.refund_approved_at,
        refund_by=excluded.refund_by,
        refund_no=excluded.refund_no,
        refund_channel=excluded.refund_channel,
        refund_mode=excluded.refund_mode,
        refund_meta_json=excluded.refund_meta_json,
        checkout_batch_no=excluded.checkout_batch_no,
        settled_at=excluded.settled_at,
        settle_no=excluded.settle_no,
        settled_by=excluded.settled_by,
        settlement_channel=excluded.settlement_channel,
        settlement_mode=excluded.settlement_mode,
        settlement_meta_json=excluded.settlement_meta_json`
    )
    .run(
      order.id,
      order.order_no,
      order.user_id,
      order.shop_id,
      order.product_id,
      order.product_name,
      order.quantity,
      order.total_amount,
      order.verify_code,
      order.status,
      toDateTimeString(order.created_at),
      toDateTimeString(order.pay_expire_at),
      toDateTimeString(order.paid_at),
      order.payment_no || null,
      order.payment_channel || null,
      order.payment_mode || null,
      order.payment_meta ? JSON.stringify(order.payment_meta) : null,
      normalizedExpiresAt,
      order.cancel_reason || null,
      toDateTimeString(order.canceled_at),
      toDateTimeString(order.verified_at),
      order.verified_by || null,
      order.refund_reason || null,
      toDateTimeString(order.refund_requested_at),
      toDateTimeString(order.refund_approved_at),
      order.refund_by || null,
      order.refund_no || null,
      order.refund_channel || null,
      order.refund_mode || null,
      order.refund_meta ? JSON.stringify(order.refund_meta) : null,
      order.checkout_batch_no || null,
      toDateTimeString(order.settled_at),
      order.settle_no || null,
      order.settled_by || null,
      order.settlement_channel || null,
      order.settlement_mode || null,
      order.settlement_meta ? JSON.stringify(order.settlement_meta) : null
    );
}

async function persistCartItem(item) {
  if (!sqliteDb) return;
  sqliteDb
    .prepare(
      `INSERT INTO cart_items
      (id, user_id, shop_id, product_id, product_name, product_price, quantity, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        quantity=excluded.quantity,
        product_name=excluded.product_name,
        product_price=excluded.product_price,
        updated_at=excluded.updated_at`
    )
    .run(
      item.id,
      item.user_id,
      item.shop_id,
      item.product_id,
      item.product_name,
      item.product_price,
      item.quantity,
      toDateTimeString(item.created_at),
      toDateTimeString(item.updated_at)
    );
}

async function deleteCartItem(itemID) {
  if (!sqliteDb) return;
  sqliteDb.prepare("DELETE FROM cart_items WHERE id = ?").run(itemID);
}

async function refreshOrderStatuses() {
  if (repos) {
    await repos.orderRepo.refreshTimeoutCanceled();
    return;
  }
  const now = Date.now();
  for (const order of orders) {
    if (order.status !== 1 || !order.expires_at) continue;
    if (now >= new Date(order.expires_at).getTime()) {
      order.status = 3;
      order.cancel_reason = "超时未核销，系统自动取消";
      order.canceled_at = new Date().toISOString();
      await withProductLock(order.product_id, async () => {
        const product = getProductById(order.product_id);
        if (product) product.stock += order.quantity;
        if (product) await persistProduct(product);
      });
      await persistOrder(order);
    }
  }
}

function sendJSON(res, status, payload, reqId = res.localsRequestId) {
  const body = payload && typeof payload === "object" ? { ...payload } : { message: String(payload) };
  if (!body.request_id) body.request_id = reqId || null;
  if (status >= 400) {
    if (!body.error_code) body.error_code = defaultErrorCode(status);
    res.localsErrorCode = body.error_code;
  }

  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
    Pragma: "no-cache",
    Expires: "0",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "X-Request-Id": reqId || "",
  });
  res.end(JSON.stringify(body));
}

function sendFile(res, filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const contentType = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".gif": "image/gif",
    ".ico": "image/x-icon",
  }[ext] || "text/plain; charset=utf-8";

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      res.end("Not Found");
      return;
    }
    res.writeHead(200, { "Content-Type": contentType });
    res.end(data);
  });
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let raw = "";
    let tooLarge = false;
    req.on("data", (chunk) => {
      if (tooLarge) return;
      raw += chunk;
      if (raw.length > MAX_REQUEST_BODY_BYTES) tooLarge = true;
    });
    req.on("end", () => {
      if (tooLarge) {
        const err = new Error("payload too large");
        err.code = "PAYLOAD_TOO_LARGE";
        reject(err);
        return;
      }
      if (!raw) {
        resolve({});
        return;
      }
      try {
        resolve(JSON.parse(raw));
      } catch (err) {
        reject(err);
      }
    });
    req.on("error", reject);
  });
}

function getTokenFromRequest(req) {
  const auth = req.headers.authorization || "";
  if (!auth.startsWith("Bearer ")) return null;
  const token = auth.slice(7).trim();
  return token || null;
}

function nowMs() {
  return Date.now();
}

function revokeSessionByAccessToken(accessToken) {
  const session = accessTokens.get(accessToken);
  if (!session) return;
  accessTokens.delete(accessToken);
  if (session.refreshToken) {
    refreshTokens.delete(session.refreshToken);
  }
}

function expireAccessTokenOnly(accessToken) {
  const session = accessTokens.get(accessToken);
  if (!session) return;
  accessTokens.delete(accessToken);
  if (session.refreshToken) {
    const refreshSession = refreshTokens.get(session.refreshToken);
    if (refreshSession && refreshSession.accessToken === accessToken) {
      refreshSession.accessToken = null;
    }
  }
}

function createAuthSession(user) {
  const accessToken = randomBytes(24).toString("hex");
  const refreshToken = randomBytes(32).toString("hex");
  const issuedAt = nowMs();
  const accessExpiresAt = issuedAt + ACCESS_TOKEN_TTL_MS;
  const refreshExpiresAt = issuedAt + REFRESH_TOKEN_TTL_MS;

  accessTokens.set(accessToken, {
    userId: user.id,
    accessExpiresAt,
    refreshToken,
  });
  refreshTokens.set(refreshToken, {
    userId: user.id,
    refreshExpiresAt,
    accessToken,
  });

  return {
    token: accessToken,
    refresh_token: refreshToken,
    token_type: "Bearer",
    expires_in: Math.floor(ACCESS_TOKEN_TTL_MS / 1000),
    expires_at: new Date(accessExpiresAt).toISOString(),
  };
}

function requireAuth(req, res, role = null) {
  const token = getTokenFromRequest(req);
  if (!token) {
    sendJSON(res, 401, { code: 401, message: "unauthorized", error_code: "AUTH_TOKEN_MISSING" });
    return null;
  }

  const session = accessTokens.get(token);
  if (!session) {
    sendJSON(res, 401, { code: 401, message: "unauthorized", error_code: "AUTH_TOKEN_INVALID" });
    return null;
  }
  if (!Number.isFinite(session.accessExpiresAt) || session.accessExpiresAt <= nowMs()) {
    expireAccessTokenOnly(token);
    sendJSON(res, 401, { code: 401, message: "token expired", error_code: "AUTH_TOKEN_EXPIRED" });
    return null;
  }

  const user = users.find((u) => u.id === session.userId) || null;
  if (!user) {
    sendJSON(res, 401, { code: 401, message: "unauthorized", error_code: "AUTH_USER_NOT_FOUND" });
    return null;
  }

  if (role && user.role !== role) {
    sendJSON(res, 403, { code: 403, message: `${role} only`, error_code: "AUTH_ROLE_FORBIDDEN" });
    return null;
  }

  return user;
}

function parsePagination(searchParams) {
  const page = Math.max(1, Number(searchParams.get("page") || 1));
  const pageSize = Math.min(100, Math.max(1, Number(searchParams.get("page_size") || 20)));
  return { page, pageSize };
}

function parseDateRange(searchParams) {
  const startRaw = String(searchParams.get("start_date") || "").trim();
  const endRaw = String(searchParams.get("end_date") || "").trim();
  const isDateStr = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s);
  const parseStart = (s) => new Date(`${s}T00:00:00.000Z`).getTime();
  const parseEnd = (s) => new Date(`${s}T23:59:59.999Z`).getTime();

  let startTs;
  let endTs;
  if (!startRaw && !endRaw) {
    endTs = Date.now();
    startTs = endTs - 6 * 24 * 3600 * 1000;
  } else {
    if (!isDateStr(startRaw) || !isDateStr(endRaw)) return null;
    startTs = parseStart(startRaw);
    endTs = parseEnd(endRaw);
  }

  if (!Number.isFinite(startTs) || !Number.isFinite(endTs) || startTs > endTs) return null;
  return { startTs, endTs };
}

function parseSettlementDateBasis(searchParams) {
  const raw = String(searchParams.get("date_basis") || "created_at").trim();
  if (!raw) return "created_at";
  if (raw === "created_at" || raw === "settled_at") return raw;
  return null;
}

function normalizeImageList(input) {
  if (Array.isArray(input)) {
    return input.map((item) => String(item || "").trim()).filter(Boolean);
  }
  if (typeof input === "string") {
    return input
      .split(/[\n,]/)
      .map((item) => item.trim())
      .filter(Boolean);
  }
  return [];
}

function isValidImageRef(value) {
  const v = String(value || "").trim();
  if (!v) return false;
  if (/^data:[^,]+;base64,/i.test(v)) return true;
  if (v.length > MAX_IMAGE_REF_LENGTH) return false;
  if (v.startsWith("http://") || v.startsWith("https://")) return true;
  if (v.startsWith("/assets/")) return true;
  return false;
}

function estimateDataImageBytes(value) {
  const v = String(value || "");
  if (!v.startsWith("data:")) return 0;
  const commaAt = v.indexOf(",");
  if (commaAt < 0) return -1;
  const meta = v.slice(0, commaAt);
  const payload = v.slice(commaAt + 1);
  if (!/;base64/i.test(meta)) return -1;
  const clean = payload.replace(/\s/g, "");
  const pad = clean.endsWith("==") ? 2 : clean.endsWith("=") ? 1 : 0;
  return Math.max(0, Math.floor((clean.length * 3) / 4) - pad);
}

function validateProductImagePayload({ images, detailImages }) {
  if (!images.length) {
    return { code: 400, message: "missing required fields", error_code: "PRODUCT_MISSING_FIELDS" };
  }
  if (images.length > MAX_PRODUCT_IMAGES) {
    return { code: 400, message: `images max ${MAX_PRODUCT_IMAGES}`, error_code: "PRODUCT_IMAGES_TOO_MANY" };
  }
  if (detailImages.length > MAX_PRODUCT_DETAIL_IMAGES) {
    return {
      code: 400,
      message: `detail_images max ${MAX_PRODUCT_DETAIL_IMAGES}`,
      error_code: "PRODUCT_DETAIL_IMAGES_TOO_MANY",
    };
  }
  const invalidImage = images.find((it) => !isValidImageRef(it));
  if (invalidImage) {
    return {
      code: 400,
      message: "invalid images",
      error_code: "PRODUCT_INVALID_IMAGES",
      invalid_image_prefix: String(invalidImage).slice(0, 48),
    };
  }
  const invalidDetailImage = detailImages.find((it) => !isValidImageRef(it));
  if (invalidDetailImage) {
    return {
      code: 400,
      message: "invalid detail_images",
      error_code: "PRODUCT_INVALID_DETAIL_IMAGES",
      invalid_detail_image_prefix: String(invalidDetailImage).slice(0, 48),
    };
  }

  let totalDataImageBytes = 0;
  for (const imageRef of [...images, ...detailImages]) {
    const bytes = estimateDataImageBytes(imageRef);
    if (bytes < 0) {
      return { code: 400, message: "invalid data image", error_code: "PRODUCT_INVALID_DATA_IMAGE" };
    }
    if (bytes > MAX_SINGLE_DATA_IMAGE_BYTES) {
      return { code: 400, message: "data image too large", error_code: "PRODUCT_IMAGE_TOO_LARGE" };
    }
    totalDataImageBytes += bytes;
  }
  if (totalDataImageBytes > MAX_TOTAL_DATA_IMAGE_BYTES) {
    return { code: 400, message: "data images too large", error_code: "PRODUCT_IMAGES_TOTAL_TOO_LARGE" };
  }
  return null;
}

function isValidTimeHHmm(value) {
  return /^\d{2}:\d{2}$/.test(String(value || "").trim());
}

function isValidDateOnly(value) {
  return /^\d{4}-\d{2}-\d{2}$/.test(String(value || "").trim());
}

function dateOnlyToExpireTime(dateOnly) {
  const s = String(dateOnly || "").trim();
  if (!isValidDateOnly(s)) return null;
  return `${s}T23:59:59.999Z`;
}

function haversineKm(lat1, lng1, lat2, lng2) {
  const toRad = (d) => (d * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

async function geocodeAddressByAmap(address) {
  const rawAddress = String(address || "").trim();
  if (!rawAddress) return { ok: false, error_code: "AMAP_ADDRESS_EMPTY", message: "address empty" };
  if (!AMAP_SERVICE_KEY) return { ok: false, error_code: "AMAP_KEY_MISSING", message: "amap key not configured" };

  const query = new URLSearchParams({ address: rawAddress, key: AMAP_SERVICE_KEY });
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), AMAP_TIMEOUT_MS);
  try {
    const res = await fetch(`${AMAP_GEOCODE_ENDPOINT}?${query.toString()}`, {
      method: "GET",
      signal: controller.signal,
    });
    const text = await res.text();
    let payload;
    try {
      payload = JSON.parse(text);
    } catch (_err) {
      return { ok: false, error_code: "AMAP_INVALID_JSON", message: "amap response invalid json", raw: text };
    }
    if (String(payload.status) !== "1") {
      return {
        ok: false,
        error_code: "AMAP_API_ERROR",
        message: payload.info || "amap geocode failed",
        amap_infocode: payload.infocode || "",
      };
    }
    const first = Array.isArray(payload.geocodes) ? payload.geocodes[0] : null;
    if (!first || !first.location || typeof first.location !== "string" || first.location.indexOf(",") < 0) {
      return { ok: false, error_code: "AMAP_NO_RESULT", message: "no geocode result" };
    }
    const [lngStr, latStr] = first.location.split(",");
    const lat = Number(latStr);
    const lng = Number(lngStr);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
      return { ok: false, error_code: "AMAP_INVALID_LOCATION", message: "invalid location" };
    }
    return {
      ok: true,
      lat,
      lng,
      formatted_address: first.formatted_address || rawAddress,
      adcode: first.adcode || "",
      city: first.city || "",
      district: first.district || "",
    };
  } catch (err) {
    const aborted = err && err.name === "AbortError";
    return {
      ok: false,
      error_code: aborted ? "AMAP_TIMEOUT" : "AMAP_NETWORK_ERROR",
      message: aborted ? "amap request timeout" : String(err && err.message ? err.message : err),
    };
  } finally {
    clearTimeout(timer);
  }
}

function getOrderTimestampByBasis(order, basis) {
  if (basis === "settled_at") {
    return new Date(order.settled_at || "").getTime();
  }
  return new Date(order.created_at || "").getTime();
}

function isHttpStatusCode(value) {
  return Number.isInteger(value) && value >= 100 && value <= 599;
}

function toCsvCell(value) {
  const str = value === null || value === undefined ? "" : String(value);
  if (/[",\r\n]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function buildOrderTimeline(order) {
  const events = [];
  const push = (code, label, at, extra = null) => {
    if (!at) return;
    const ts = new Date(at).getTime();
    if (!Number.isFinite(ts)) return;
    const item = { code, label, at: new Date(ts).toISOString() };
    if (extra && typeof extra === "object") Object.assign(item, extra);
    events.push(item);
  };

  push("ORDER_CREATED", "订单创建", order.created_at);
  push("PAYMENT_SUCCESS", "支付成功", order.paid_at, order.payment_no ? { payment_no: order.payment_no } : null);
  push(
    "ORDER_VERIFIED",
    "订单核销",
    order.verified_at,
    order.verified_by ? { verified_by: Number(order.verified_by) } : null
  );
  push(
    "ORDER_CANCELED",
    "订单取消",
    order.canceled_at,
    order.cancel_reason ? { reason: order.cancel_reason } : null
  );
  push(
    "REFUND_REQUESTED",
    "申请退款",
    order.refund_requested_at,
    order.refund_reason ? { reason: order.refund_reason } : null
  );
  push(
    "REFUND_APPROVED",
    "退款完成",
    order.refund_approved_at,
    order.refund_by !== undefined && order.refund_by !== null ? { refund_by: Number(order.refund_by) } : null
  );
  push(
    "ORDER_SETTLED",
    "订单结算",
    order.settled_at,
    order.settle_no ? { settle_no: order.settle_no } : null
  );

  events.sort((a, b) => new Date(a.at).getTime() - new Date(b.at).getTime());
  return events;
}

async function handleApi(req, res, pathname, searchParams) {
  await refreshOrderStatuses();

  if (req.method === "GET" && pathname === "/api/v1/health") {
    return sendJSON(res, 200, { code: 200, message: "ok", data: { status: "up" } });
  }

  if (req.method === "POST" && (pathname === "/api/v1/auth/login" || pathname === "/api/v1/auth/sms/login")) {
    const body = await parseBody(req);
    const phone = String(body.phone || "").trim();
    const role = body.role === "merchant" ? "merchant" : "buyer";
    if (!/^\d{11}$/.test(phone)) {
      return sendJSON(res, 400, { code: 400, message: "invalid phone", error_code: "AUTH_INVALID_PHONE" });
    }

    let user = repos.userRepo.findByPhoneRole(phone, role);
    if (!user) {
      if (role === "merchant") {
        return sendJSON(res, 404, {
          code: 404,
          message: "merchant not registered, please register first",
          error_code: "MERCHANT_NOT_REGISTERED",
        });
      }
      user = await repos.userRepo.create({
        phone,
        role,
        nickname: role + "-" + phone.slice(-4),
        shopID: role === "merchant" ? seq.user + 1 : null,
      });
      if (role === "merchant" && !user.shop_id) {
        user.shop_id = user.id;
        await persistUser(user);
      }
    }

    const authSession = createAuthSession(user);
    return sendJSON(res, 200, {
      code: 200,
      message: "login success",
      data: {
        ...authSession,
        user_id: user.id,
        user_type: role === "merchant" ? 2 : 1,
        nickname: user.nickname,
        full_name: user.full_name || "",
        buyer_address: user.buyer_address || "",
        shop_id: user.shop_id || null,
        shop_name: user.shop_name || "",
        shop_address: user.shop_address || "",
        contact_name: user.contact_name || "",
        contact_phone: user.contact_phone || "",
        business_hours: user.business_hours || "",
        shop_lat: user.shop_lat === undefined ? null : Number(user.shop_lat),
        shop_lng: user.shop_lng === undefined ? null : Number(user.shop_lng),
        merchant_status: user.merchant_status || "",
        is_open: role === "merchant" ? user.is_open !== false : null,
      },
    });
  }

  if (req.method === "POST" && pathname === "/api/v1/auth/sms/send") {
    return sendJSON(res, 200, { code: 200, message: "mock sent", data: { expire_time: 300 } });
  }

  if (req.method === "POST" && pathname === "/api/v1/buyer/register") {
    const body = await parseBody(req);
    const phone = String(body.phone || "").trim();
    const fullName = String(body.full_name || "").trim();
    const buyerAddress = String(body.buyer_address || "").trim();

    if (!/^\d{11}$/.test(phone)) {
      return sendJSON(res, 400, { code: 400, message: "invalid phone", error_code: "AUTH_INVALID_PHONE" });
    }
    if (!fullName) {
      return sendJSON(res, 400, {
        code: 400,
        message: "full_name required",
        error_code: "BUYER_REGISTER_MISSING_FULL_NAME",
      });
    }

    let user = repos.userRepo.findByPhoneRole(phone, "buyer");
    if (!user) {
      user = await repos.userRepo.create({
        phone,
        role: "buyer",
        nickname: fullName,
        shopID: null,
      });
    }
    user.nickname = fullName;
    user.full_name = fullName;
    user.buyer_address = buyerAddress;
    await persistUser(user);

    return sendJSON(res, 200, {
      code: 200,
      message: "buyer register success",
      data: {
        user_id: user.id,
        phone: user.phone,
        role: user.role,
        nickname: user.nickname,
        full_name: user.full_name || "",
        buyer_address: user.buyer_address || "",
      },
    });
  }

  if (req.method === "PUT" && pathname === "/api/v1/buyer/profile") {
    const user = requireAuth(req, res, "buyer");
    if (!user) return;
    const body = await parseBody(req);
    const fullName = String(body.full_name || "").trim();
    const buyerAddress = String(body.buyer_address || "").trim();
    if (!fullName) {
      return sendJSON(res, 400, {
        code: 400,
        message: "full_name required",
        error_code: "BUYER_PROFILE_MISSING_FULL_NAME",
      });
    }

    user.nickname = fullName;
    user.full_name = fullName;
    user.buyer_address = buyerAddress;
    await persistUser(user);

    return sendJSON(res, 200, {
      code: 200,
      message: "buyer profile updated",
      data: {
        user_id: user.id,
        phone: user.phone,
        role: user.role,
        nickname: user.nickname,
        full_name: user.full_name || "",
        buyer_address: user.buyer_address || "",
      },
    });
  }

  if (req.method === "PUT" && pathname === "/api/v1/merchant/profile") {
    const user = requireAuth(req, res, "merchant");
    if (!user) return;
    const body = await parseBody(req);
    const shopName = String(body.shop_name || "").trim();
    const shopAddress = String(body.shop_address || "").trim();
    const contactName = String(body.contact_name || "").trim();
    const contactPhone = String(body.contact_phone || "").trim();
    const businessHours = String(body.business_hours || "").trim();
    let shopLat = Number(body.shop_lat);
    let shopLng = Number(body.shop_lng);
    const licenseImagesInput = normalizeImageList(body.license_images);
    const nextLicenseImages = licenseImagesInput.length ? licenseImagesInput : user.license_images || [];

    if (!shopName || !shopAddress || !contactName || !/^\d{11}$/.test(contactPhone) || !businessHours) {
      return sendJSON(res, 400, {
        code: 400,
        message: "missing required fields",
        error_code: "MERCHANT_PROFILE_MISSING_FIELDS",
      });
    }
    if (!nextLicenseImages.length) {
      return sendJSON(res, 400, {
        code: 400,
        message: "license_images required",
        error_code: "MERCHANT_PROFILE_LICENSE_REQUIRED",
      });
    }
    if (!nextLicenseImages.every(isValidImageRef)) {
      return sendJSON(res, 400, {
        code: 400,
        message: "invalid license_images",
        error_code: "MERCHANT_PROFILE_INVALID_LICENSE_IMAGES",
      });
    }
    if (!Number.isFinite(shopLat) || !Number.isFinite(shopLng)) {
      const geocode = await geocodeAddressByAmap(shopAddress);
      if (geocode.ok) {
        shopLat = geocode.lat;
        shopLng = geocode.lng;
      }
    }
    if (!Number.isFinite(shopLat) || !Number.isFinite(shopLng)) {
      return sendJSON(res, 400, {
        code: 400,
        message: "shop_lat/shop_lng missing and geocode failed",
        error_code: "MERCHANT_PROFILE_GEO_REQUIRED",
      });
    }
    if (shopLat < -90 || shopLat > 90 || shopLng < -180 || shopLng > 180) {
      return sendJSON(res, 400, {
        code: 400,
        message: "invalid shop_lat/shop_lng",
        error_code: "MERCHANT_PROFILE_INVALID_GEO",
      });
    }

    user.nickname = shopName;
    user.shop_name = shopName;
    user.shop_address = shopAddress;
    user.contact_name = contactName;
    user.contact_phone = contactPhone;
    user.business_hours = businessHours;
    user.shop_lat = Number(shopLat);
    user.shop_lng = Number(shopLng);
    user.license_images = nextLicenseImages;
    if (!user.shop_id) user.shop_id = user.id;
    if (!user.merchant_status) user.merchant_status = "approved";
    await persistUser(user);

    return sendJSON(res, 200, {
      code: 200,
      message: "merchant profile updated",
      data: {
        user_id: user.id,
        phone: user.phone,
        role: user.role,
        shop_id: user.shop_id || null,
        shop_name: user.shop_name || "",
        shop_address: user.shop_address || "",
        contact_name: user.contact_name || "",
        contact_phone: user.contact_phone || "",
        business_hours: user.business_hours || "",
        shop_lat: user.shop_lat === undefined ? null : Number(user.shop_lat),
        shop_lng: user.shop_lng === undefined ? null : Number(user.shop_lng),
        license_images: user.license_images || [],
        merchant_status: user.merchant_status || "approved",
        is_open: user.is_open !== false,
      },
    });
  }

  if (req.method === "PUT" && pathname === "/api/v1/merchant/open-status") {
    const user = requireAuth(req, res, "merchant");
    if (!user) return;
    const body = await parseBody(req);
    const raw = body.is_open;
    const parsed =
      raw === true || raw === 1 || raw === "1" || raw === "true"
        ? true
        : raw === false || raw === 0 || raw === "0" || raw === "false"
          ? false
          : null;
    if (parsed === null) {
      return sendJSON(res, 400, {
        code: 400,
        message: "is_open must be boolean",
        error_code: "MERCHANT_OPEN_STATUS_INVALID",
      });
    }
    user.is_open = parsed;
    await persistUser(user);
    return sendJSON(res, 200, {
      code: 200,
      message: parsed ? "merchant open" : "merchant closed",
      data: {
        user_id: user.id,
        shop_id: user.shop_id || null,
        is_open: user.is_open !== false,
      },
    });
  }

  if (req.method === "POST" && pathname === "/api/v1/merchant/register") {
    const body = await parseBody(req);
    const phone = String(body.phone || "").trim();
    const shopName = String(body.shop_name || "").trim();
    const shopAddress = String(body.shop_address || "").trim();
    const contactName = String(body.contact_name || "").trim();
    const contactPhone = String(body.contact_phone || "").trim();
    const businessHours = String(body.business_hours || "").trim();
    let shopLat = Number(body.shop_lat);
    let shopLng = Number(body.shop_lng);
    const licenseImages = normalizeImageList(body.license_images);

    if (!/^\d{11}$/.test(phone)) {
      return sendJSON(res, 400, { code: 400, message: "invalid phone", error_code: "AUTH_INVALID_PHONE" });
    }
    if (
      !shopName ||
      !shopAddress ||
      !contactName ||
      !/^\d{11}$/.test(contactPhone) ||
      !businessHours ||
      !licenseImages.length
    ) {
      return sendJSON(res, 400, {
        code: 400,
        message: "missing required fields",
        error_code: "MERCHANT_REGISTER_MISSING_FIELDS",
      });
    }
    if (!Number.isFinite(shopLat) || !Number.isFinite(shopLng)) {
      const geocode = await geocodeAddressByAmap(shopAddress);
      if (geocode.ok) {
        shopLat = geocode.lat;
        shopLng = geocode.lng;
      }
    }
    if (!Number.isFinite(shopLat) || !Number.isFinite(shopLng)) {
      return sendJSON(res, 400, {
        code: 400,
        message: "shop_lat/shop_lng missing and geocode failed",
        error_code: "MERCHANT_REGISTER_GEO_REQUIRED",
      });
    }
    if (shopLat < -90 || shopLat > 90 || shopLng < -180 || shopLng > 180) {
      return sendJSON(res, 400, {
        code: 400,
        message: "invalid shop_lat/shop_lng",
        error_code: "MERCHANT_REGISTER_INVALID_GEO",
      });
    }
    if (!licenseImages.every(isValidImageRef)) {
      return sendJSON(res, 400, {
        code: 400,
        message: "invalid license_images",
        error_code: "MERCHANT_REGISTER_INVALID_LICENSE_IMAGES",
      });
    }

    let user = repos.userRepo.findByPhoneRole(phone, "merchant");
    if (!user) {
      user = await repos.userRepo.create({
        phone,
        role: "merchant",
        nickname: shopName,
        shopID: seq.user + 1,
      });
    }
    if (!user.shop_id) user.shop_id = user.id;
    user.nickname = shopName;
    user.shop_name = shopName;
    user.shop_address = shopAddress;
    user.contact_name = contactName;
    user.contact_phone = contactPhone;
    user.business_hours = businessHours;
    user.shop_lat = Number(shopLat);
    user.shop_lng = Number(shopLng);
    user.license_images = licenseImages;
    user.merchant_status = "approved";
    user.is_open = true;
    await persistUser(user);

    return sendJSON(res, 200, {
      code: 200,
      message: "merchant register success",
      data: {
        user_id: user.id,
        phone: user.phone,
        role: user.role,
        shop_id: user.shop_id || null,
        shop_name: user.shop_name || "",
        shop_address: user.shop_address || "",
        contact_name: user.contact_name || "",
        contact_phone: user.contact_phone || "",
        business_hours: user.business_hours || "",
        shop_lat: user.shop_lat === undefined ? null : Number(user.shop_lat),
        shop_lng: user.shop_lng === undefined ? null : Number(user.shop_lng),
        license_images: user.license_images || [],
        merchant_status: user.merchant_status || "approved",
        is_open: user.is_open !== false,
      },
    });
  }

  if (req.method === "POST" && pathname === "/api/v1/auth/refresh") {
    const body = await parseBody(req);
    const refreshToken = String(body.refresh_token || "").trim();
    if (!refreshToken) {
      return sendJSON(res, 400, { code: 400, message: "refresh_token required", error_code: "AUTH_REFRESH_TOKEN_MISSING" });
    }

    const refreshSession = refreshTokens.get(refreshToken);
    if (!refreshSession) {
      return sendJSON(res, 401, { code: 401, message: "invalid refresh token", error_code: "AUTH_REFRESH_TOKEN_INVALID" });
    }
    if (!Number.isFinite(refreshSession.refreshExpiresAt) || refreshSession.refreshExpiresAt <= nowMs()) {
      if (refreshSession.accessToken) accessTokens.delete(refreshSession.accessToken);
      refreshTokens.delete(refreshToken);
      return sendJSON(res, 401, { code: 401, message: "refresh token expired", error_code: "AUTH_REFRESH_TOKEN_EXPIRED" });
    }

    const user = users.find((u) => u.id === refreshSession.userId) || null;
    if (!user) {
      if (refreshSession.accessToken) accessTokens.delete(refreshSession.accessToken);
      refreshTokens.delete(refreshToken);
      return sendJSON(res, 401, { code: 401, message: "unauthorized", error_code: "AUTH_USER_NOT_FOUND" });
    }

    if (refreshSession.accessToken) accessTokens.delete(refreshSession.accessToken);
    refreshTokens.delete(refreshToken);
    const authSession = createAuthSession(user);
    return sendJSON(res, 200, {
      code: 200,
      message: "refresh success",
      data: authSession,
    });
  }

  if (req.method === "POST" && pathname === "/api/v1/auth/logout") {
    const token = getTokenFromRequest(req);
    if (!token) {
      return sendJSON(res, 401, { code: 401, message: "unauthorized", error_code: "AUTH_TOKEN_MISSING" });
    }
    const session = accessTokens.get(token);
    if (!session) {
      return sendJSON(res, 401, { code: 401, message: "unauthorized", error_code: "AUTH_TOKEN_INVALID" });
    }
    revokeSessionByAccessToken(token);
    return sendJSON(res, 200, { code: 200, message: "logout success", data: { revoked: true } });
  }

  if (req.method === "GET" && pathname === "/api/v1/products") {
    const { page, pageSize } = parsePagination(searchParams);
    const keyword = String(searchParams.get("keyword") || "").trim().toLowerCase();
    const paged = repos.productRepo.listPublic({
      keyword,
      page,
      pageSize,
      shopFilter: (shopID) => isMerchantOpenByShopID(shopID),
    });
    return sendJSON(res, 200, {
      code: 200,
      message: "success",
      data: { products: paged.items, total: paged.total, page: paged.page, page_size: paged.page_size },
    });
  }

  if (req.method === "GET" && pathname === "/api/v1/map/geocode") {
    const address = String(searchParams.get("address") || "").trim();
    if (!address) {
      return sendJSON(res, 400, {
        code: 400,
        message: "address required",
        error_code: "MAP_GEOCODE_ADDRESS_REQUIRED",
      });
    }
    const geocode = await geocodeAddressByAmap(address);
    if (!geocode.ok) {
      return sendJSON(res, 400, {
        code: 400,
        message: geocode.message || "geocode failed",
        error_code: geocode.error_code || "MAP_GEOCODE_FAILED",
        data: {
          amap_infocode: geocode.amap_infocode || "",
          endpoint: AMAP_GEOCODE_ENDPOINT,
          has_key: Boolean(AMAP_SERVICE_KEY),
          has_amap_web_key: Boolean(AMAP_WEB_KEY),
          has_amap_js_key: Boolean(AMAP_JS_KEY),
        },
      });
    }
    return sendJSON(res, 200, {
      code: 200,
      message: "success",
      data: {
        address,
        formatted_address: geocode.formatted_address || address,
        lat: Number(geocode.lat),
        lng: Number(geocode.lng),
        adcode: geocode.adcode || "",
        city: geocode.city || "",
        district: geocode.district || "",
      },
    });
  }

  if (req.method === "GET" && pathname === "/api/v1/map/config") {
    return sendJSON(res, 200, {
      code: 200,
      message: "success",
      data: {
        amap_js_key: AMAP_JS_KEY || "",
        has_amap_js_key: Boolean(AMAP_JS_KEY),
        has_amap_web_key: Boolean(AMAP_WEB_KEY),
        amap_security_js_code: AMAP_SECURITY_JS_CODE || "",
        has_amap_security_js_code: Boolean(AMAP_SECURITY_JS_CODE),
      },
    });
  }

  if (req.method === "GET" && pathname === "/api/v1/payments/config") {
    const user = requireAuth(req, res);
    if (!user) return;
    const check = alipayMcpService.getConfigCheck();
    return sendJSON(res, 200, {
      code: 200,
      message: "success",
      data: {
        alipay_mcp: {
          ...check,
          startup_check: {
            ok: !check.enabled || check.mode !== "live" || check.live_ready,
            message:
              !check.enabled
                ? "disabled"
                : check.mode !== "live"
                ? "mock mode"
                : check.live_ready
                ? "live config ready"
                : `missing fields: ${check.missing_fields.join(", ")}`,
          },
        },
      },
    });
  }

  if (req.method === "GET" && pathname === "/api/v1/shops/nearby") {
    const user = requireAuth(req, res, "buyer");
    if (!user) return;
    const lat = Number(searchParams.get("lat"));
    const lng = Number(searchParams.get("lng"));
    const radiusKm = Math.max(0.1, Math.min(50, Number(searchParams.get("radius_km") || 3)));
    const sortByRaw = String(searchParams.get("sort_by") || "distance").trim().toLowerCase();
    const sortBy = ["distance", "discount", "price"].includes(sortByRaw) ? sortByRaw : null;
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
      return sendJSON(res, 400, {
        code: 400,
        message: "lat/lng required",
        error_code: "SHOP_NEARBY_INVALID_GEO",
      });
    }
    if (!sortBy) {
      return sendJSON(res, 400, {
        code: 400,
        message: "invalid sort_by",
        error_code: "SHOP_NEARBY_INVALID_SORT",
      });
    }
    if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
      return sendJSON(res, 400, {
        code: 400,
        message: "invalid lat/lng range",
        error_code: "SHOP_NEARBY_INVALID_GEO",
      });
    }

    const merchantUsers = users.filter(
      (u) => u.role === "merchant" && u.is_open !== false && Number.isFinite(u.shop_lat) && Number.isFinite(u.shop_lng)
    );
    const result = [];
    for (const merchant of merchantUsers) {
      const distanceKm = haversineKm(lat, lng, Number(merchant.shop_lat), Number(merchant.shop_lng));
      if (distanceKm > radiusKm) continue;
      const shopId = merchant.shop_id || merchant.id;
      const productsInShop = repos.productRepo.listByShop({ shopID: shopId, keyword: "", status: 1, page: 1, pageSize: 200 }).items;
      if (!productsInShop.length) continue;

      let bestDiscountRate = 0;
      let minPrice = Infinity;
      let featuredProduct = null;
      for (const p of productsInShop) {
        const original = Number(p.original_price || 0);
        const current = Number(p.discount_price || 0);
        let rate = 0;
        if (original > 0 && current >= 0) {
          rate = 1 - current / original;
          if (rate > bestDiscountRate) bestDiscountRate = rate;
        }
        if (current >= 0 && current < minPrice) minPrice = current;
        if (
          !featuredProduct ||
          rate > Number(featuredProduct.discount_rate || 0) ||
          (rate === Number(featuredProduct.discount_rate || 0) && current < Number(featuredProduct.discount_price || Infinity))
        ) {
          featuredProduct = {
            product_id: p.id,
            name: p.name,
            discount_price: Number(current.toFixed(2)),
            original_price: Number(original.toFixed(2)),
            discount_rate: Number(rate.toFixed(4)),
            best_before_date: p.best_before_date || "",
          };
        }
      }
      result.push({
        shop_id: shopId,
        shop_name: merchant.shop_name || merchant.nickname || `shop-${shopId}`,
        shop_address: merchant.shop_address || "",
        contact_phone: merchant.contact_phone || merchant.phone || "",
        business_hours: merchant.business_hours || "",
        shop_lat: Number(merchant.shop_lat),
        shop_lng: Number(merchant.shop_lng),
        distance_km: Number(distanceKm.toFixed(2)),
        active_product_count: productsInShop.length,
        best_discount_rate: Number(bestDiscountRate.toFixed(4)),
        best_discount_percent: Number((bestDiscountRate * 100).toFixed(1)),
        min_discount_price: Number((Number.isFinite(minPrice) ? minPrice : 0).toFixed(2)),
        featured_product: featuredProduct,
        is_open: true,
      });
    }

    if (sortBy === "discount") {
      result.sort((a, b) => b.best_discount_rate - a.best_discount_rate || a.distance_km - b.distance_km);
    } else if (sortBy === "price") {
      result.sort((a, b) => a.min_discount_price - b.min_discount_price || a.distance_km - b.distance_km);
    } else {
      result.sort((a, b) => a.distance_km - b.distance_km || b.best_discount_rate - a.best_discount_rate);
    }
    return sendJSON(res, 200, {
      code: 200,
      message: "success",
      data: {
        center: { lat, lng, radius_km: radiusKm },
        sort_by: sortBy,
        total: result.length,
        shops: result,
      },
    });
  }

  if (req.method === "POST" && pathname === "/api/v1/merchant/products") {
    const user = requireAuth(req, res, "merchant");
    if (!user) return;

    const body = await parseBody(req);
    const images = normalizeImageList(body.images);
    const detailImages = normalizeImageList(body.detail_images);
    const pickupStartTime = String(body.pickup_start_time || "").trim();
    const pickupEndTime = String(body.pickup_end_time || "").trim();
    const productionDate = String(body.production_date || "").trim();
    const bestBeforeDate = String(body.best_before_date || "").trim();
    if (!body.name || !body.category_id || !body.original_price || !body.discount_price || !body.stock || !images.length) {
      return sendJSON(res, 400, { code: 400, message: "missing required fields", error_code: "PRODUCT_MISSING_FIELDS" });
    }
    if (!productionDate || !bestBeforeDate || !isValidDateOnly(productionDate) || !isValidDateOnly(bestBeforeDate)) {
      return sendJSON(res, 400, {
        code: 400,
        message: "production_date and best_before_date are required in YYYY-MM-DD",
        error_code: "PRODUCT_INVALID_DATE_FIELDS",
      });
    }
    if (new Date(productionDate).getTime() > new Date(bestBeforeDate).getTime()) {
      return sendJSON(res, 400, {
        code: 400,
        message: "best_before_date must be >= production_date",
        error_code: "PRODUCT_INVALID_DATE_RANGE",
      });
    }
    const imageErr = validateProductImagePayload({ images, detailImages });
    if (imageErr) {
      return sendJSON(res, imageErr.code, imageErr);
    }
    if ((pickupStartTime || pickupEndTime) && (!isValidTimeHHmm(pickupStartTime) || !isValidTimeHHmm(pickupEndTime))) {
      return sendJSON(res, 400, {
        code: 400,
        message: "invalid pickup time format, use HH:mm",
        error_code: "PRODUCT_INVALID_PICKUP_TIME",
      });
    }

    const record = await repos.productRepo.create({
      shop_id: user.shop_id || user.id,
      category_id: Number(body.category_id),
      name: String(body.name),
      description: body.description ? String(body.description) : "",
      images,
      detail_images: detailImages,
      ingredients: String(body.ingredients || "").trim(),
      allergen_info: String(body.allergen_info || "").trim(),
      production_date: productionDate,
      best_before_date: bestBeforeDate,
      pickup_start_time: pickupStartTime,
      pickup_end_time: pickupEndTime,
      original_price: Number(body.original_price),
      discount_price: Number(body.discount_price),
      discount: body.discount ? Number(body.discount) : 0,
      stock: Number(body.stock),
      expire_time: dateOnlyToExpireTime(bestBeforeDate),
      status: 1,
      created_at: new Date().toISOString(),
    });
    return sendJSON(res, 200, { code: 200, message: "publish success", data: record });
  }

  if (req.method === "GET" && pathname === "/api/v1/merchant/products") {
    const user = requireAuth(req, res, "merchant");
    if (!user) return;
    const shopId = user.shop_id || user.id;
    const { page, pageSize } = parsePagination(searchParams);
    const keyword = String(searchParams.get("keyword") || "").trim().toLowerCase();
    const statusRaw = searchParams.get("status");
    const paged = repos.productRepo.listByShop({
      shopID: shopId,
      keyword,
      status: statusRaw,
      page,
      pageSize,
    });
    return sendJSON(res, 200, {
      code: 200,
      message: "success",
      data: { products: paged.items, total: paged.total, page: paged.page, page_size: paged.page_size },
    });
  }

  const merchantProductUpdateMatch = pathname.match(/^\/api\/v1\/merchant\/products\/(\d+)$/);
  if (req.method === "PUT" && merchantProductUpdateMatch) {
    const user = requireAuth(req, res, "merchant");
    if (!user) return;
    const shopId = user.shop_id || user.id;
    const productId = Number(merchantProductUpdateMatch[1]);
    const body = await parseBody(req);
    if (body.images !== undefined || body.detail_images !== undefined) {
      const existing = repos.productRepo.getByID(productId);
      if (!existing || existing.shop_id !== (user.shop_id || user.id)) {
        return sendJSON(res, 404, { code: 404, message: "product not found" });
      }
      const images = body.images !== undefined ? normalizeImageList(body.images) : normalizeImageList(existing.images);
      const detailImages =
        body.detail_images !== undefined ? normalizeImageList(body.detail_images) : normalizeImageList(existing.detail_images);
      const imageErr = validateProductImagePayload({ images, detailImages });
      if (imageErr) return sendJSON(res, imageErr.code, imageErr);
      body.images = images;
      body.detail_images = detailImages;
    }
    if (body.pickup_start_time !== undefined || body.pickup_end_time !== undefined) {
      const pickupStartTime = String(body.pickup_start_time || "").trim();
      const pickupEndTime = String(body.pickup_end_time || "").trim();
      if ((pickupStartTime || pickupEndTime) && (!isValidTimeHHmm(pickupStartTime) || !isValidTimeHHmm(pickupEndTime))) {
        return sendJSON(res, 400, {
          code: 400,
          message: "invalid pickup time format, use HH:mm",
          error_code: "PRODUCT_INVALID_PICKUP_TIME",
        });
      }
      body.pickup_start_time = pickupStartTime;
      body.pickup_end_time = pickupEndTime;
    }
    if (body.production_date !== undefined || body.best_before_date !== undefined) {
      const existing = repos.productRepo.getByID(productId);
      if (!existing || existing.shop_id !== (user.shop_id || user.id)) {
        return sendJSON(res, 404, { code: 404, message: "product not found" });
      }
      const productionDate = String(
        body.production_date !== undefined ? body.production_date : existing.production_date || ""
      ).trim();
      const bestBeforeDate = String(
        body.best_before_date !== undefined ? body.best_before_date : existing.best_before_date || ""
      ).trim();
      if (!productionDate || !bestBeforeDate || !isValidDateOnly(productionDate) || !isValidDateOnly(bestBeforeDate)) {
        return sendJSON(res, 400, {
          code: 400,
          message: "production_date and best_before_date are required in YYYY-MM-DD",
          error_code: "PRODUCT_INVALID_DATE_FIELDS",
        });
      }
      if (new Date(productionDate).getTime() > new Date(bestBeforeDate).getTime()) {
        return sendJSON(res, 400, {
          code: 400,
          message: "best_before_date must be >= production_date",
          error_code: "PRODUCT_INVALID_DATE_RANGE",
        });
      }
      body.production_date = productionDate;
      body.best_before_date = bestBeforeDate;
      body.expire_time = dateOnlyToExpireTime(bestBeforeDate);
    }

    const updated = await repos.productRepo.updateByShop({
      shopID: shopId,
      productID: productId,
      patch: body,
    });

    if (!updated) return sendJSON(res, 404, { code: 404, message: "product not found" });
    return sendJSON(res, 200, { code: 200, message: "update success", data: updated });
  }

  const merchantProductStatusMatch = pathname.match(/^\/api\/v1\/merchant\/products\/(\d+)\/status$/);
  if (req.method === "PUT" && merchantProductStatusMatch) {
    const user = requireAuth(req, res, "merchant");
    if (!user) return;
    const shopId = user.shop_id || user.id;
    const productId = Number(merchantProductStatusMatch[1]);
    const body = await parseBody(req);
    const nextStatus = Number(body.status);
    if (![0, 1].includes(nextStatus)) {
      return sendJSON(res, 400, { code: 400, message: "invalid status, use 0/1", error_code: "PRODUCT_INVALID_STATUS" });
    }

    const product = await repos.productRepo.setStatusByShop({
      shopID: shopId,
      productID: productId,
      status: nextStatus,
    });
    if (!product) {
      return sendJSON(res, 404, { code: 404, message: "product not found" });
    }
    return sendJSON(res, 200, { code: 200, message: "status updated", data: product });
  }

  if (req.method === "GET" && pathname === "/api/v1/cart/items") {
    const user = requireAuth(req, res, "buyer");
    if (!user) return;
    const items = repos.cartRepo.listByUser({ userID: user.id });
    const totalAmount = Number(items.reduce((sum, item) => sum + item.product_price * item.quantity, 0).toFixed(2));
    return sendJSON(res, 200, { code: 200, message: "success", data: { items, total: items.length, total_amount: totalAmount } });
  }

  if (req.method === "POST" && pathname === "/api/v1/cart/items") {
    const user = requireAuth(req, res, "buyer");
    if (!user) return;
    const body = await parseBody(req);
    const productId = Number(body.product_id);
    const quantity = Number(body.quantity || 1);
    const product = repos.productRepo.getByID(productId);
    if (!product || product.status !== 1) {
      return sendJSON(res, 404, { code: 404, message: "product not found", error_code: "PRODUCT_NOT_FOUND" });
    }
    if (!isMerchantOpenByShopID(product.shop_id)) {
      return sendJSON(res, 409, {
        code: 409,
        message: "商家已打烊，暂不可下单",
        error_code: "MERCHANT_CLOSED",
      });
    }

    const result = await repos.cartRepo.addItem({ userID: user.id, product, quantity });
    if (result.err) return sendJSON(res, result.err.code, result.err);
    return sendJSON(res, 200, { code: 200, message: "cart item added", data: result.item });
  }

  const cartItemMatch = pathname.match(/^\/api\/v1\/cart\/items\/(\d+)$/);
  if (req.method === "PUT" && cartItemMatch) {
    const user = requireAuth(req, res, "buyer");
    if (!user) return;
    const itemID = Number(cartItemMatch[1]);
    const body = await parseBody(req);
    const quantity = Number(body.quantity || 0);
    const result = await repos.cartRepo.updateQuantity({ userID: user.id, itemID, quantity });
    if (result.err) return sendJSON(res, result.err.code, result.err);
    return sendJSON(res, 200, { code: 200, message: "cart item updated", data: result.item });
  }

  if (req.method === "DELETE" && cartItemMatch) {
    const user = requireAuth(req, res, "buyer");
    if (!user) return;
    const itemID = Number(cartItemMatch[1]);
    const result = await repos.cartRepo.removeItem({ userID: user.id, itemID });
    if (result.err) return sendJSON(res, result.err.code, result.err);
    return sendJSON(res, 200, { code: 200, message: "cart item removed", data: { item_id: itemID } });
  }

  if (req.method === "POST" && pathname === "/api/v1/cart/checkout") {
    const user = requireAuth(req, res, "buyer");
    if (!user) return;
    const items = repos.cartRepo.listByUser({ userID: user.id });
    if (!items.length) {
      return sendJSON(res, 400, { code: 400, message: "购物车为空", error_code: "CART_EMPTY" });
    }

    const shopIDs = [...new Set(items.map((item) => Number(item.shop_id)))];
    if (shopIDs.length > 1) {
      return sendJSON(res, 409, {
        code: 409,
        message: "购物车仅支持单商家结算，请先清空或结算购物车",
        error_code: "CART_MULTI_SHOP_NOT_ALLOWED",
      });
    }

    const checkoutBatchNo = `CHK${Date.now()}${String(user.id).padStart(4, "0")}`;
    const reserved = [];
    try {
      for (const item of items) {
        if (!isMerchantOpenByShopID(item.shop_id)) {
          throw {
            code: 409,
            message: "商家已打烊，暂不可结算",
            error_code: "MERCHANT_CLOSED",
          };
        }
        const reserveResult = await repos.productRepo.reserveStock({ productID: item.product_id, quantity: item.quantity });
        if (reserveResult.err) {
          throw reserveResult.err;
        }
        reserved.push({ product: reserveResult.product, quantity: item.quantity });
      }

      const created = [];
      for (const row of reserved) {
        const order = await repos.orderRepo.create({ userID: user.id, product: row.product, quantity: row.quantity });
        order.checkout_batch_no = checkoutBatchNo;
        await repos.orderRepo.save(order);
        created.push({
          order_id: order.id,
          order_no: order.order_no,
          checkout_batch_no: order.checkout_batch_no,
          product_id: order.product_id,
          product_name: order.product_name,
          quantity: order.quantity,
          total_amount: order.total_amount,
          status: order.status,
          pay_expire_at: order.pay_expire_at,
        });
      }

      await repos.cartRepo.clearByUser({ userID: user.id });
      return sendJSON(res, 200, {
        code: 200,
        message: "checkout success",
        data: {
          checkout_batch_no: checkoutBatchNo,
          shop_id: shopIDs[0],
          order_count: created.length,
          orders: created,
        },
      });
    } catch (err) {
      for (const row of reserved) {
        await repos.productRepo.restoreStock({ productID: row.product.id, quantity: row.quantity });
      }
      if (err && isHttpStatusCode(err.code) && err.message) {
        return sendJSON(res, err.code, err);
      }
      return sendJSON(res, 500, {
        code: 500,
        message: "checkout failed",
        error_code: "CHECKOUT_FAILED",
      });
    }
  }

  if (req.method === "POST" && pathname === "/api/v1/orders") {
    const user = requireAuth(req, res, "buyer");
    if (!user) return;

    const body = await parseBody(req);
    const productId = Number(body.product_id);
    const quantity = Number(body.quantity || 1);
    if (quantity <= 0) return sendJSON(res, 400, { code: 400, message: "invalid quantity", error_code: "ORDER_INVALID_QUANTITY" });
    const product = repos.productRepo.getByID(productId);
    if (!product || product.status !== 1) {
      return sendJSON(res, 404, { code: 404, message: "product not found", error_code: "PRODUCT_NOT_FOUND" });
    }
    if (!isMerchantOpenByShopID(product.shop_id)) {
      return sendJSON(res, 409, {
        code: 409,
        message: "商家已打烊，暂不可下单",
        error_code: "MERCHANT_CLOSED",
      });
    }

    const { product: reservedProduct, err: reserveErr } = await repos.productRepo.reserveStock({ productID: productId, quantity });
    if (reserveErr) return sendJSON(res, reserveErr.code, reserveErr);
    const order = await repos.orderRepo.create({ userID: user.id, product: reservedProduct, quantity });
    return sendJSON(res, 200, {
      code: 200,
      message: "order created, waiting payment",
      data: {
        order_id: order.id,
        order_no: order.order_no,
        status: order.status,
        pay_expire_at: order.pay_expire_at,
      },
    });
  }

  if (req.method === "POST" && pathname === "/api/v1/orders/batch-pay") {
    const user = requireAuth(req, res, "buyer");
    if (!user) return;
    const body = await parseBody(req);
    const idempotencyKey = extractIdempotencyKey(req, body);
    const channel = String(body.channel || "alipay_mcp").trim().toLowerCase();
    if (channel !== "alipay_mcp") {
      return sendJSON(res, 400, {
        code: 400,
        message: "unsupported channel, use alipay_mcp",
        error_code: "PAYMENT_CHANNEL_UNSUPPORTED",
      });
    }
    const rawIDs = Array.isArray(body.order_ids) ? body.order_ids : [];
    const orderIDs = [...new Set(rawIDs.map((id) => Number(id)).filter((id) => Number.isInteger(id) && id > 0))];
    if (!orderIDs.length) {
      return sendJSON(res, 400, {
        code: 400,
        message: "order_ids 不能为空",
        error_code: "ORDER_BATCH_EMPTY",
      });
    }

    for (const orderID of orderIDs) {
      const order = repos.orderRepo.findByIDForUser({ orderID, userID: user.id });
      if (!order) {
        return sendJSON(res, 404, {
          code: 404,
          message: `order not found: ${orderID}`,
          error_code: "ORDER_NOT_FOUND",
        });
      }
      if (order.status !== 0) {
        return sendJSON(res, 409, {
          code: 409,
          message: `order is not payable: ${orderID}`,
          error_code: "ORDER_NOT_PAYABLE",
        });
      }
      if (order.pay_expire_at && Date.now() >= new Date(order.pay_expire_at).getTime()) {
        return sendJSON(res, 409, {
          code: 409,
          message: `order payment expired: ${orderID}`,
          error_code: "ORDER_PAYMENT_EXPIRED",
        });
      }
    }

    const result = await runIdempotent({
      scope: "buyer_batch_pay",
      actorId: user.id,
      key: idempotencyKey,
      requestPayload: { channel, order_ids: orderIDs },
      execute: async () => {
        const paidOrders = [];
        for (const orderID of orderIDs) {
          const current = repos.orderRepo.findByIDForUser({ orderID, userID: user.id });
          const upstreamIdempotencyKey = idempotencyKey
            ? `buyer_batch_pay:${idempotencyKey}:${orderID}`
            : `buyer_order_pay:${current.order_no || orderID}`;
          const collect = await alipayMcpService.collectBuyerPayment({
            order: current,
            buyer: user,
            idempotencyKey: upstreamIdempotencyKey,
          });
          if (!collect.ok) {
            return mapAlipayUpstreamError("payment", collect);
          }
          const { order, err } = await repos.orderRepo.payByUser({ orderID, userID: user.id });
          if (err) return { status: err.code, payload: err };
          order.payment_no = collect.trade_no || order.payment_no;
          order.payment_channel = collect.channel || "alipay_mcp";
          order.payment_mode = collect.mode || "mock";
          order.payment_meta = collect.raw || null;
          await repos.orderRepo.save(order);
          paidOrders.push({
            order_id: order.id,
            order_no: order.order_no,
            payment_no: order.payment_no,
            paid_at: order.paid_at,
            verify_code: order.verify_code,
            status: order.status,
            payment_channel: collect.channel || "alipay_mcp",
            payment_mode: collect.mode || "mock",
          });
        }
        return {
          status: 200,
          payload: {
            code: 200,
            message: "batch payment success",
            data: {
              count: paidOrders.length,
              orders: paidOrders,
            },
          },
        };
      },
    });
    return sendJSON(res, result.status, result.payload);
  }

  if (req.method === "GET" && pathname === "/api/v1/checkout-records") {
    const user = requireAuth(req, res, "buyer");
    if (!user) return;
    const allOrders = repos.orderRepo.listByUser({ userID: user.id, status: "", page: 1, pageSize: 1000 }).items;
    const grouped = new Map();

    for (const order of allOrders) {
      if (!order.checkout_batch_no) continue;
      if (!grouped.has(order.checkout_batch_no)) {
        grouped.set(order.checkout_batch_no, {
          checkout_batch_no: order.checkout_batch_no,
          created_at: order.created_at,
          order_count: 0,
          total_amount: 0,
          paid_count: 0,
          unpaid_count: 0,
          orders: [],
        });
      }
      const g = grouped.get(order.checkout_batch_no);
      g.order_count += 1;
      g.total_amount = Number((g.total_amount + Number(order.total_amount || 0)).toFixed(2));
      if (order.status === 0) g.unpaid_count += 1;
      else g.paid_count += 1;
      if (new Date(order.created_at).getTime() < new Date(g.created_at).getTime()) {
        g.created_at = order.created_at;
      }
      g.orders.push({
        order_id: order.id,
        order_no: order.order_no,
        product_name: order.product_name,
        quantity: order.quantity,
        total_amount: order.total_amount,
        status: order.status,
      });
    }

    const records = [...grouped.values()]
      .map((g) => ({
        ...g,
        payment_status_text: g.unpaid_count === 0 ? "全部已支付" : g.paid_count === 0 ? "全部待支付" : "部分已支付",
      }))
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    return sendJSON(res, 200, {
      code: 200,
      message: "success",
      data: { records, total: records.length },
    });
  }

  const payMatch = pathname.match(/^\/api\/v1\/orders\/(\d+)\/pay$/);
  const payQrMatch = pathname.match(/^\/api\/v1\/orders\/(\d+)\/pay\/qr$/);
  if (req.method === "POST" && payQrMatch) {
    const user = requireAuth(req, res, "buyer");
    if (!user) return;
    const body = await parseBody(req);
    const idempotencyKey = extractIdempotencyKey(req, body);
    const channel = String(body.channel || "alipay_mcp").trim().toLowerCase();
    if (channel !== "alipay_mcp") {
      return sendJSON(res, 400, {
        code: 400,
        message: "unsupported channel, use alipay_mcp",
        error_code: "PAYMENT_CHANNEL_UNSUPPORTED",
      });
    }
    const orderId = Number(payQrMatch[1]);
    const result = await runIdempotent({
      scope: "buyer_order_pay_qr",
      actorId: user.id,
      key: idempotencyKey,
      requestPayload: { order_id: orderId, channel },
      execute: async () => {
        const current = repos.orderRepo.findByIDForUser({ orderID: orderId, userID: user.id });
        if (!current) return { status: 404, payload: { code: 404, message: "order not found", error_code: "ORDER_NOT_FOUND" } };
        if (current.status !== 0) {
          return {
            status: 409,
            payload: { code: 409, message: "order is not payable", error_code: "ORDER_NOT_PAYABLE" },
          };
        }
        if (current.pay_expire_at && Date.now() >= new Date(current.pay_expire_at).getTime()) {
          return {
            status: 409,
            payload: { code: 409, message: "order payment expired", error_code: "ORDER_PAYMENT_EXPIRED" },
          };
        }
        const upstreamIdempotencyKey = idempotencyKey
          ? `buyer_order_pay_qr:${idempotencyKey}:${orderId}`
          : `buyer_order_pay_qr:${current.order_no || orderId}`;
        const collect = await alipayMcpService.collectBuyerPayment({
          order: current,
          buyer: user,
          idempotencyKey: upstreamIdempotencyKey,
          requireQr: true,
        });
        if (!collect.ok) return mapAlipayUpstreamError("payment", collect);
        const qrUrl = String(collect.qr_url || "").trim();
        if (!qrUrl) {
          return {
            status: 409,
            payload: {
              code: 409,
              message: "upstream missing qr url",
              error_code: "PAYMENT_QR_URL_MISSING",
            },
          };
        }
        return {
          status: 200,
          payload: {
            code: 200,
            message: "payment qr generated",
            data: {
              order_id: current.id,
              order_no: current.order_no,
              amount: current.total_amount,
              qr_url: qrUrl,
              payment_no: collect.trade_no || null,
              payment_channel: collect.channel || "alipay_mcp",
              payment_mode: collect.mode || "mock",
            },
          },
        };
      },
    });
    return sendJSON(res, result.status, result.payload);
  }

  if (req.method === "POST" && pathname === "/api/v1/orders/batch-pay/qr") {
    const user = requireAuth(req, res, "buyer");
    if (!user) return;
    const body = await parseBody(req);
    const idempotencyKey = extractIdempotencyKey(req, body);
    const channel = String(body.channel || "alipay_mcp").trim().toLowerCase();
    if (channel !== "alipay_mcp") {
      return sendJSON(res, 400, {
        code: 400,
        message: "unsupported channel, use alipay_mcp",
        error_code: "PAYMENT_CHANNEL_UNSUPPORTED",
      });
    }
    const rawIDs = Array.isArray(body.order_ids) ? body.order_ids : [];
    const orderIDs = [...new Set(rawIDs.map((id) => Number(id)).filter((id) => Number.isInteger(id) && id > 0))];
    if (!orderIDs.length) {
      return sendJSON(res, 400, {
        code: 400,
        message: "order_ids 不能为空",
        error_code: "ORDER_BATCH_EMPTY",
      });
    }
    for (const orderID of orderIDs) {
      const order = repos.orderRepo.findByIDForUser({ orderID, userID: user.id });
      if (!order) {
        return sendJSON(res, 404, {
          code: 404,
          message: `order not found: ${orderID}`,
          error_code: "ORDER_NOT_FOUND",
        });
      }
      if (order.status !== 0) {
        return sendJSON(res, 409, {
          code: 409,
          message: `order is not payable: ${orderID}`,
          error_code: "ORDER_NOT_PAYABLE",
        });
      }
      if (order.pay_expire_at && Date.now() >= new Date(order.pay_expire_at).getTime()) {
        return sendJSON(res, 409, {
          code: 409,
          message: `order payment expired: ${orderID}`,
          error_code: "ORDER_PAYMENT_EXPIRED",
        });
      }
    }
    const result = await runIdempotent({
      scope: "buyer_batch_pay_qr",
      actorId: user.id,
      key: idempotencyKey,
      requestPayload: { channel, order_ids: orderIDs },
      execute: async () => {
        const amount = Number(
          orderIDs.reduce((sum, orderID) => {
            const order = repos.orderRepo.findByIDForUser({ orderID, userID: user.id });
            return sum + Number((order && order.total_amount) || 0);
          }, 0).toFixed(2)
        );
        const pseudoOrderNo = `BATCH${Date.now()}${String(user.id).padStart(4, "0")}`;
        const collect = await alipayMcpService.collectBuyerPayment({
          order: { order_no: pseudoOrderNo, total_amount: amount },
          buyer: user,
          idempotencyKey: idempotencyKey ? `buyer_batch_pay_qr:${idempotencyKey}` : `buyer_batch_pay_qr:${pseudoOrderNo}`,
          requireQr: true,
        });
        if (!collect.ok) return mapAlipayUpstreamError("payment", collect);
        const qrUrl = String(collect.qr_url || "").trim();
        if (!qrUrl) {
          return {
            status: 409,
            payload: {
              code: 409,
              message: "upstream missing qr url",
              error_code: "PAYMENT_QR_URL_MISSING",
            },
          };
        }
        return {
          status: 200,
          payload: {
            code: 200,
            message: "batch payment qr generated",
            data: {
              order_ids: orderIDs,
              count: orderIDs.length,
              amount,
              qr_url: qrUrl,
              payment_no: collect.trade_no || null,
              payment_channel: collect.channel || "alipay_mcp",
              payment_mode: collect.mode || "mock",
            },
          },
        };
      },
    });
    return sendJSON(res, result.status, result.payload);
  }

  if (req.method === "POST" && payMatch) {
    const user = requireAuth(req, res, "buyer");
    if (!user) return;
    const body = await parseBody(req);
    const idempotencyKey = extractIdempotencyKey(req, body);
    const channel = String(body.channel || "alipay_mcp").trim().toLowerCase();
    if (channel !== "alipay_mcp") {
      return sendJSON(res, 400, {
        code: 400,
        message: "unsupported channel, use alipay_mcp",
        error_code: "PAYMENT_CHANNEL_UNSUPPORTED",
      });
    }
    const orderId = Number(payMatch[1]);
    const result = await runIdempotent({
      scope: "buyer_order_pay",
      actorId: user.id,
      key: idempotencyKey,
      requestPayload: { order_id: orderId, channel },
      execute: async () => {
        const current = repos.orderRepo.findByIDForUser({ orderID: orderId, userID: user.id });
        if (!current) return { status: 404, payload: { code: 404, message: "order not found", error_code: "ORDER_NOT_FOUND" } };
        if (current.status !== 0) {
          return {
            status: 409,
            payload: {
              code: 409,
              message: "order is not payable",
              error_code: "ORDER_NOT_PAYABLE",
            },
          };
        }
        if (current.pay_expire_at && Date.now() >= new Date(current.pay_expire_at).getTime()) {
          return {
            status: 409,
            payload: {
              code: 409,
              message: "order payment expired",
              error_code: "ORDER_PAYMENT_EXPIRED",
            },
          };
        }

        const upstreamIdempotencyKey = idempotencyKey
          ? `buyer_order_pay:${idempotencyKey}:${orderId}`
          : `buyer_order_pay:${current.order_no || orderId}`;
        const collect = await alipayMcpService.collectBuyerPayment({
          order: current,
          buyer: user,
          idempotencyKey: upstreamIdempotencyKey,
        });
        if (!collect.ok) {
          return mapAlipayUpstreamError("payment", collect);
        }
        const { order, err } = await repos.orderRepo.payByUser({ orderID: orderId, userID: user.id });
        if (err) return { status: err.code, payload: err };
        order.payment_no = collect.trade_no || order.payment_no;
        order.payment_channel = collect.channel || "alipay_mcp";
        order.payment_mode = collect.mode || "mock";
        order.payment_meta = collect.raw || null;
        await repos.orderRepo.save(order);
        return {
          status: 200,
          payload: {
            code: 200,
            message: "payment success",
            data: {
              order_id: order.id,
              order_no: order.order_no,
              payment_no: order.payment_no,
              paid_at: order.paid_at,
              verify_code: order.verify_code,
              status: order.status,
              payment_channel: collect.channel || "alipay_mcp",
              payment_mode: collect.mode || "mock",
            },
          },
        };
      },
    });
    return sendJSON(res, result.status, result.payload);
  }

  if (req.method === "GET" && pathname === "/api/v1/orders") {
    const user = requireAuth(req, res);
    if (!user) return;
    const { page, pageSize } = parsePagination(searchParams);
    const statusRaw = searchParams.get("status");
    const paged = repos.orderRepo.listByUser({ userID: user.id, status: statusRaw, page, pageSize });
    return sendJSON(res, 200, {
      code: 200,
      message: "success",
      data: { orders: paged.items, total: paged.total, page: paged.page, page_size: paged.page_size },
    });
  }

  const orderDetailMatch = pathname.match(/^\/api\/v1\/orders\/(\d+)$/);
  if (req.method === "GET" && orderDetailMatch) {
    const user = requireAuth(req, res, "buyer");
    if (!user) return;
    const orderId = Number(orderDetailMatch[1]);
    const order = repos.orderRepo.findByIDForUser({ orderID: orderId, userID: user.id });
    if (!order) return sendJSON(res, 404, { code: 404, message: "order not found" });
    const product = repos.productRepo.getByID(order.product_id);
    return sendJSON(res, 200, {
      code: 200,
      message: "success",
      data: {
        ...order,
        timeline: buildOrderTimeline(order),
        product_snapshot: product
          ? {
              id: product.id,
              name: product.name,
              price: product.discount_price,
              stock: product.stock,
              status: product.status,
            }
          : null,
      },
    });
  }

  const cancelMatch = pathname.match(/^\/api\/v1\/orders\/(\d+)\/cancel$/);
  if (req.method === "PUT" && cancelMatch) {
    const user = requireAuth(req, res, "buyer");
    if (!user) return;

    const orderId = Number(cancelMatch[1]);
    const body = await parseBody(req);
    const reason = String(body.cancel_reason || "用户取消").trim();
    const order = repos.orderRepo.findByIDForUser({ orderID: orderId, userID: user.id });
    if (!order) return sendJSON(res, 404, { code: 404, message: "order not found" });
    if (![0, 1].includes(order.status)) {
      return sendJSON(res, 400, { code: 400, message: "当前状态不可取消", error_code: "ORDER_CANNOT_CANCEL" });
    }

    order.status = 3;
    order.cancel_reason = reason || "用户取消";
    order.canceled_at = new Date().toISOString();
    await repos.productRepo.restoreStock({ productID: order.product_id, quantity: order.quantity });
    await repos.orderRepo.save(order);
    return sendJSON(res, 200, { code: 200, message: "cancel success", data: order });
  }

  const refundMatch = pathname.match(/^\/api\/v1\/orders\/(\d+)\/refund$/);
  if (req.method === "POST" && refundMatch) {
    const user = requireAuth(req, res, "buyer");
    if (!user) return;
    const orderId = Number(refundMatch[1]);
    const body = await parseBody(req);
    const idempotencyKey = extractIdempotencyKey(req, body);
    const reason = String(body.reason || body.refund_reason || "").trim() || "用户申请退款";
    const result = await runIdempotent({
      scope: "buyer_order_refund",
      actorId: user.id,
      key: idempotencyKey,
      requestPayload: { order_id: orderId, reason },
      execute: async () => {
        const order = repos.orderRepo.findByIDForUser({ orderID: orderId, userID: user.id });
        if (!order) return { status: 404, payload: { code: 404, message: "order not found", error_code: "ORDER_NOT_FOUND" } };

        if (![1, 2, 6].includes(order.status)) {
          return {
            status: 400,
            payload: {
              code: 400,
              message: "当前状态不可退款",
              error_code: "ORDER_NOT_REFUNDABLE",
            },
          };
        }

        order.refund_reason = reason;
        order.refund_requested_at = new Date().toISOString();

        // 统一进入商家确认退款，避免买家端提前显示“已退款”。
        order.status = 5;
        order.refund_approved_at = null;
        order.refund_by = null;
        order.refund_no = null;
        order.refund_channel = null;
        order.refund_mode = null;
        order.refund_meta = null;
        await repos.orderRepo.save(order);
        return { status: 200, payload: { code: 200, message: "refund pending merchant confirm", data: order } };
      },
    });
    return sendJSON(res, result.status, result.payload);
  }

  if (req.method === "GET" && pathname === "/api/v1/merchant/orders") {
    const user = requireAuth(req, res, "merchant");
    if (!user) return;
    const { page, pageSize } = parsePagination(searchParams);
    const statusRaw = searchParams.get("status");
    const shopId = user.shop_id || user.id;
    const paged = repos.orderRepo.listByShop({ shopID: shopId, status: statusRaw, page, pageSize });
    return sendJSON(res, 200, {
      code: 200,
      message: "success",
      data: { orders: paged.items, total: paged.total, page: paged.page, page_size: paged.page_size },
    });
  }

  if (req.method === "GET" && pathname === "/api/v1/merchant/settlement-summary") {
    const user = requireAuth(req, res, "merchant");
    if (!user) return;
    const range = parseDateRange(searchParams);
    const dateBasis = parseSettlementDateBasis(searchParams);
    if (!range) {
      return sendJSON(res, 400, {
        code: 400,
        message: "invalid date range, use start_date/end_date in YYYY-MM-DD",
        error_code: "INVALID_DATE_RANGE",
      });
    }
    if (!dateBasis) {
      return sendJSON(res, 400, {
        code: 400,
        message: "invalid date_basis, use created_at/settled_at",
        error_code: "INVALID_DATE_BASIS",
      });
    }

    const shopId = user.shop_id || user.id;
    const allOrders = repos.orderRepo.listByShop({ shopID: shopId, status: "", page: 1, pageSize: 5000 }).items;
    const scoped = allOrders.filter((o) => {
      const ts = getOrderTimestampByBasis(o, dateBasis);
      return Number.isFinite(ts) && ts >= range.startTs && ts <= range.endTs;
    });

    let pendingVerifyAmount = 0;
    let verifiedAmount = 0;
    let refundedAmount = 0;
    let settledAmount = 0;
    let pendingVerifyCount = 0;
    let verifiedCount = 0;
    let refundedCount = 0;
    let settledCount = 0;

    for (const o of scoped) {
      const amount = Number(o.total_amount || 0);
      if (o.status === 1) {
        pendingVerifyAmount += amount;
        pendingVerifyCount += 1;
      }
      if (o.status === 2) {
        verifiedAmount += amount;
        verifiedCount += 1;
      }
      if (o.status === 4) {
        refundedAmount += amount;
        refundedCount += 1;
      }
      if (o.status === 6) {
        settledAmount += amount;
        settledCount += 1;
      }
    }

    return sendJSON(res, 200, {
      code: 200,
      message: "success",
      data: {
        start_at: new Date(range.startTs).toISOString(),
        end_at: new Date(range.endTs).toISOString(),
        date_basis: dateBasis,
        total_orders: scoped.length,
        pending_verify_count: pendingVerifyCount,
        pending_verify_amount: Number(pendingVerifyAmount.toFixed(2)),
        verified_count: verifiedCount,
        verified_amount: Number(verifiedAmount.toFixed(2)),
        refunded_count: refundedCount,
        refunded_amount: Number(refundedAmount.toFixed(2)),
        settled_count: settledCount,
        settled_amount: Number(settledAmount.toFixed(2)),
      },
    });
  }

  if (req.method === "GET" && pathname === "/api/v1/merchant/settlement-details") {
    const user = requireAuth(req, res, "merchant");
    if (!user) return;
    const range = parseDateRange(searchParams);
    const dateBasis = parseSettlementDateBasis(searchParams);
    if (!range) {
      return sendJSON(res, 400, {
        code: 400,
        message: "invalid date range, use start_date/end_date in YYYY-MM-DD",
        error_code: "INVALID_DATE_RANGE",
      });
    }
    if (!dateBasis) {
      return sendJSON(res, 400, {
        code: 400,
        message: "invalid date_basis, use created_at/settled_at",
        error_code: "INVALID_DATE_BASIS",
      });
    }

    const bucket = String(searchParams.get("bucket") || "").trim();
    const bucketMap = {
      pending_verify: 1,
      verified: 2,
      refunded: 4,
      settled: 6,
    };
    const targetStatus = bucketMap[bucket];
    if (targetStatus === undefined) {
      return sendJSON(res, 400, {
        code: 400,
        message: "invalid bucket, use pending_verify/verified/refunded/settled",
        error_code: "INVALID_BUCKET",
      });
    }
    if (dateBasis === "settled_at" && targetStatus !== 6) {
      return sendJSON(res, 400, {
        code: 400,
        message: "date_basis=settled_at only supports bucket=settled",
        error_code: "INVALID_DATE_BASIS_BUCKET",
      });
    }

    const shopId = user.shop_id || user.id;
    const allOrders = repos.orderRepo.listByShop({ shopID: shopId, status: "", page: 1, pageSize: 5000 }).items;
    const details = allOrders
      .filter((o) => {
        const ts = getOrderTimestampByBasis(o, dateBasis);
        return Number.isFinite(ts) && ts >= range.startTs && ts <= range.endTs && Number(o.status) === targetStatus;
      })
      .sort((a, b) => b.id - a.id)
      .map((o) => ({
        id: o.id,
        order_no: o.order_no,
        product_name: o.product_name,
        quantity: o.quantity,
        total_amount: o.total_amount,
        status: o.status,
        created_at: o.created_at,
        payment_no: o.payment_no || "",
        payment_channel: o.payment_channel || "",
        payment_mode: o.payment_mode || "",
        settle_no: o.settle_no || "",
        settlement_channel: o.settlement_channel || "",
        settlement_mode: o.settlement_mode || "",
        refund_reason: o.refund_reason || "",
        refund_requested_at: o.refund_requested_at || "",
        refund_approved_at: o.refund_approved_at || "",
        refund_no: o.refund_no || "",
        refund_channel: o.refund_channel || "",
        refund_mode: o.refund_mode || "",
      }));

    const amount = Number(details.reduce((sum, o) => sum + Number(o.total_amount || 0), 0).toFixed(2));
    return sendJSON(res, 200, {
      code: 200,
      message: "success",
      data: {
        bucket,
        start_at: new Date(range.startTs).toISOString(),
        end_at: new Date(range.endTs).toISOString(),
        date_basis: dateBasis,
        total: details.length,
        total_amount: amount,
        orders: details,
      },
    });
  }

  if (req.method === "GET" && pathname === "/api/v1/merchant/settlement-details/export") {
    const user = requireAuth(req, res, "merchant");
    if (!user) return;
    const range = parseDateRange(searchParams);
    const dateBasis = parseSettlementDateBasis(searchParams);
    if (!range) {
      return sendJSON(res, 400, {
        code: 400,
        message: "invalid date range, use start_date/end_date in YYYY-MM-DD",
        error_code: "INVALID_DATE_RANGE",
      });
    }
    if (!dateBasis) {
      return sendJSON(res, 400, {
        code: 400,
        message: "invalid date_basis, use created_at/settled_at",
        error_code: "INVALID_DATE_BASIS",
      });
    }

    const bucket = String(searchParams.get("bucket") || "").trim();
    const bucketMap = {
      pending_verify: 1,
      verified: 2,
      refunded: 4,
      settled: 6,
    };
    const targetStatus = bucketMap[bucket];
    if (targetStatus === undefined) {
      return sendJSON(res, 400, {
        code: 400,
        message: "invalid bucket, use pending_verify/verified/refunded/settled",
        error_code: "INVALID_BUCKET",
      });
    }
    if (dateBasis === "settled_at" && targetStatus !== 6) {
      return sendJSON(res, 400, {
        code: 400,
        message: "date_basis=settled_at only supports bucket=settled",
        error_code: "INVALID_DATE_BASIS_BUCKET",
      });
    }

    const shopId = user.shop_id || user.id;
    const allOrders = repos.orderRepo.listByShop({ shopID: shopId, status: "", page: 1, pageSize: 5000 }).items;
    const details = allOrders
      .filter((o) => {
        const ts = getOrderTimestampByBasis(o, dateBasis);
        return Number.isFinite(ts) && ts >= range.startTs && ts <= range.endTs && Number(o.status) === targetStatus;
      })
      .sort((a, b) => b.id - a.id);

    const header = [
      "id",
      "order_no",
      "product_name",
      "quantity",
      "total_amount",
      "status",
      "created_at",
      "payment_no",
      "payment_channel",
      "payment_mode",
      "settle_no",
      "settlement_channel",
      "settlement_mode",
      "refund_reason",
      "refund_requested_at",
      "refund_approved_at",
      "refund_no",
      "refund_channel",
      "refund_mode",
    ];
    const rows = [header.join(",")];
    for (const o of details) {
      rows.push(
        [
          toCsvCell(o.id),
          toCsvCell(o.order_no),
          toCsvCell(o.product_name),
          toCsvCell(o.quantity),
          toCsvCell(o.total_amount),
          toCsvCell(o.status),
          toCsvCell(o.created_at),
          toCsvCell(o.payment_no || ""),
          toCsvCell(o.payment_channel || ""),
          toCsvCell(o.payment_mode || ""),
          toCsvCell(o.settle_no || ""),
          toCsvCell(o.settlement_channel || ""),
          toCsvCell(o.settlement_mode || ""),
          toCsvCell(o.refund_reason || ""),
          toCsvCell(o.refund_requested_at || ""),
          toCsvCell(o.refund_approved_at || ""),
          toCsvCell(o.refund_no || ""),
          toCsvCell(o.refund_channel || ""),
          toCsvCell(o.refund_mode || ""),
        ].join(",")
      );
    }

    const csv = rows.join("\n");
    const fileName = `settlement-${bucket}-${new Date(range.startTs).toISOString().slice(0, 10)}-${new Date(range.endTs)
      .toISOString()
      .slice(0, 10)}.csv`;
    res.writeHead(200, {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename=\"${fileName}\"`,
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "X-Request-Id": res.localsRequestId || "",
    });
    res.end(csv);
    return;
  }

  const merchantOrderDetailMatch = pathname.match(/^\/api\/v1\/merchant\/orders\/(\d+)$/);
  if (req.method === "GET" && merchantOrderDetailMatch) {
    const user = requireAuth(req, res, "merchant");
    if (!user) return;
    const shopId = user.shop_id || user.id;
    const orderId = Number(merchantOrderDetailMatch[1]);
    const order = repos.orderRepo.findByIDForShop({ orderID: orderId, shopID: shopId });
    if (!order) return sendJSON(res, 404, { code: 404, message: "order not found" });
    const product = repos.productRepo.getByID(order.product_id);
    return sendJSON(res, 200, {
      code: 200,
      message: "success",
      data: {
        ...order,
        timeline: buildOrderTimeline(order),
        product_snapshot: product
          ? {
              id: product.id,
              name: product.name,
              price: product.discount_price,
              stock: product.stock,
              status: product.status,
            }
          : null,
      },
    });
  }

  const verifyMatch = pathname.match(/^\/api\/v1\/merchant\/orders\/(\d+)\/verify$/);
  if (req.method === "POST" && verifyMatch) {
    const user = requireAuth(req, res, "merchant");
    if (!user) return;

    const orderId = Number(verifyMatch[1]);
    const body = await parseBody(req);
    const verifyCode = String(body.verify_code || "").trim();
    const shopId = user.shop_id || user.id;

    const order = repos.orderRepo.findByIDForShop({ orderID: orderId, shopID: shopId });
    if (!order) return sendJSON(res, 404, { code: 404, message: "order not found" });
    if (order.status !== 1) return sendJSON(res, 400, { code: 400, message: "order already handled", error_code: "ORDER_ALREADY_HANDLED" });
    if (!verifyCode || order.verify_code !== verifyCode) {
      return sendJSON(res, 400, { code: 400, message: "invalid verify_code", error_code: "ORDER_VERIFY_CODE_INVALID" });
    }

    order.status = 2;
    order.verified_at = new Date().toISOString();
    order.verified_by = user.id;
    await repos.orderRepo.save(order);
    return sendJSON(res, 200, { code: 200, message: "verify success", data: order });
  }

  const settleMatch = pathname.match(/^\/api\/v1\/merchant\/orders\/(\d+)\/settle$/);
  const settleQrMatch = pathname.match(/^\/api\/v1\/merchant\/orders\/(\d+)\/settle\/qr$/);
  if (req.method === "POST" && settleQrMatch) {
    const user = requireAuth(req, res, "merchant");
    if (!user) return;
    const body = await parseBody(req);
    const idempotencyKey = extractIdempotencyKey(req, body);
    const channel = String(body.channel || "alipay_mcp").trim().toLowerCase();
    if (channel !== "alipay_mcp") {
      return sendJSON(res, 400, {
        code: 400,
        message: "unsupported channel, use alipay_mcp",
        error_code: "SETTLEMENT_CHANNEL_UNSUPPORTED",
      });
    }
    const orderId = Number(settleQrMatch[1]);
    const result = await runIdempotent({
      scope: "merchant_order_settle_qr",
      actorId: user.id,
      key: idempotencyKey,
      requestPayload: { order_id: orderId, channel },
      execute: async () => {
        const shopId = user.shop_id || user.id;
        const order = repos.orderRepo.findByIDForShop({ orderID: orderId, shopID: shopId });
        if (!order) return { status: 404, payload: { code: 404, message: "order not found", error_code: "ORDER_NOT_FOUND" } };
        if (order.status !== 2) {
          return {
            status: 400,
            payload: { code: 400, message: "当前状态不可结算", error_code: "ORDER_NOT_SETTLEABLE" },
          };
        }
        const upstreamIdempotencyKey = idempotencyKey
          ? `merchant_order_settle_qr:${idempotencyKey}:${orderId}`
          : `merchant_order_settle_qr:${order.order_no || orderId}`;
        const transfer = await alipayMcpService.transferToMerchant({
          order,
          merchant: user,
          idempotencyKey: upstreamIdempotencyKey,
          requireQr: true,
        });
        if (!transfer.ok) return mapAlipayUpstreamError("settlement", transfer);
        const qrUrl = String(transfer.qr_url || "").trim();
        if (!qrUrl) {
          return {
            status: 409,
            payload: {
              code: 409,
              message: "upstream missing qr url",
              error_code: "SETTLEMENT_QR_URL_MISSING",
            },
          };
        }
        return {
          status: 200,
          payload: {
            code: 200,
            message: "settlement qr generated",
            data: {
              order_id: order.id,
              order_no: order.order_no,
              amount: order.total_amount,
              qr_url: qrUrl,
              settle_no: transfer.trade_no || null,
              settlement_channel: transfer.channel || "alipay_mcp",
              settlement_mode: transfer.mode || "mock",
            },
          },
        };
      },
    });
    return sendJSON(res, result.status, result.payload);
  }

  if (req.method === "POST" && settleMatch) {
    const user = requireAuth(req, res, "merchant");
    if (!user) return;
    const body = await parseBody(req);
    const idempotencyKey = extractIdempotencyKey(req, body);
    const channel = String(body.channel || "alipay_mcp").trim().toLowerCase();
    if (channel !== "alipay_mcp") {
      return sendJSON(res, 400, {
        code: 400,
        message: "unsupported channel, use alipay_mcp",
        error_code: "SETTLEMENT_CHANNEL_UNSUPPORTED",
      });
    }
    const orderId = Number(settleMatch[1]);
    const result = await runIdempotent({
      scope: "merchant_order_settle",
      actorId: user.id,
      key: idempotencyKey,
      requestPayload: { order_id: orderId, channel },
      execute: async () => {
        const shopId = user.shop_id || user.id;
        const order = repos.orderRepo.findByIDForShop({ orderID: orderId, shopID: shopId });
        if (!order) return { status: 404, payload: { code: 404, message: "order not found", error_code: "ORDER_NOT_FOUND" } };
        if (order.status !== 2) {
          return {
            status: 400,
            payload: {
              code: 400,
              message: "当前状态不可结算",
              error_code: "ORDER_NOT_SETTLEABLE",
            },
          };
        }

        const upstreamIdempotencyKey = idempotencyKey
          ? `merchant_order_settle:${idempotencyKey}:${orderId}`
          : `merchant_order_settle:${order.order_no || orderId}`;
        const transfer = await alipayMcpService.transferToMerchant({
          order,
          merchant: user,
          idempotencyKey: upstreamIdempotencyKey,
        });
        if (!transfer.ok) {
          return mapAlipayUpstreamError("settlement", transfer);
        }

        order.status = 6;
        order.settled_at = new Date().toISOString();
        order.settle_no = transfer.trade_no || `SET${Date.now()}${String(order.id).padStart(4, "0")}`;
        order.settled_by = user.id;
        order.settlement_channel = transfer.channel || "alipay_mcp";
        order.settlement_mode = transfer.mode || "mock";
        order.settlement_meta = transfer.raw || null;
        await repos.orderRepo.save(order);
        return {
          status: 200,
          payload: {
            code: 200,
            message: "settle success",
            data: {
              ...order,
              settlement_channel: transfer.channel || "alipay_mcp",
              settlement_mode: transfer.mode || "mock",
            },
          },
        };
      },
    });
    return sendJSON(res, result.status, result.payload);
  }

  if (req.method === "POST" && pathname === "/api/v1/merchant/orders/settle/batch") {
    const user = requireAuth(req, res, "merchant");
    if (!user) return;
    const shopId = user.shop_id || user.id;
    const body = await parseBody(req);
    const idempotencyKey = extractIdempotencyKey(req, body);
    const channel = String(body.channel || "alipay_mcp").trim().toLowerCase();
    if (channel !== "alipay_mcp") {
      return sendJSON(res, 400, {
        code: 400,
        message: "unsupported channel, use alipay_mcp",
        error_code: "SETTLEMENT_CHANNEL_UNSUPPORTED",
      });
    }
    const rawIDs = Array.isArray(body.order_ids) ? body.order_ids : [];
    const orderIDs = [...new Set(rawIDs.map((id) => Number(id)).filter((id) => Number.isInteger(id) && id > 0))];
    if (!orderIDs.length) {
      return sendJSON(res, 400, {
        code: 400,
        message: "order_ids 不能为空",
        error_code: "ORDER_BATCH_EMPTY",
      });
    }

    for (const orderId of orderIDs) {
      const order = repos.orderRepo.findByIDForShop({ orderID: orderId, shopID: shopId });
      if (!order) {
        return sendJSON(res, 404, { code: 404, message: `order not found: ${orderId}`, error_code: "ORDER_NOT_FOUND" });
      }
      if (order.status !== 2) {
        return sendJSON(res, 400, {
          code: 400,
          message: `order is not settleable: ${orderId}`,
          error_code: "ORDER_NOT_SETTLEABLE",
        });
      }
    }

    const result = await runIdempotent({
      scope: "merchant_batch_settle",
      actorId: user.id,
      key: idempotencyKey,
      requestPayload: { channel, order_ids: orderIDs },
      execute: async () => {
        const settled = [];
        for (const orderId of orderIDs) {
          const order = repos.orderRepo.findByIDForShop({ orderID: orderId, shopID: shopId });
          const upstreamIdempotencyKey = idempotencyKey
            ? `merchant_batch_settle:${idempotencyKey}:${orderId}`
            : `merchant_order_settle:${order.order_no || orderId}`;
          const transfer = await alipayMcpService.transferToMerchant({
            order,
            merchant: user,
            idempotencyKey: upstreamIdempotencyKey,
          });
          if (!transfer.ok) {
            return mapAlipayUpstreamError("settlement", transfer);
          }
          order.status = 6;
          order.settled_at = new Date().toISOString();
          order.settle_no = transfer.trade_no || `SET${Date.now()}${String(order.id).padStart(4, "0")}`;
          order.settled_by = user.id;
          order.settlement_channel = transfer.channel || "alipay_mcp";
          order.settlement_mode = transfer.mode || "mock";
          order.settlement_meta = transfer.raw || null;
          await repos.orderRepo.save(order);
          settled.push({
            order_id: order.id,
            order_no: order.order_no,
            settle_no: order.settle_no,
            settled_at: order.settled_at,
            status: order.status,
            settlement_channel: transfer.channel || "alipay_mcp",
            settlement_mode: transfer.mode || "mock",
          });
        }
        return {
          status: 200,
          payload: {
            code: 200,
            message: "batch settle success",
            data: { count: settled.length, orders: settled },
          },
        };
      },
    });
    return sendJSON(res, result.status, result.payload);
  }

  const refundApproveMatch = pathname.match(/^\/api\/v1\/merchant\/orders\/(\d+)\/refund\/approve$/);
  if (req.method === "POST" && refundApproveMatch) {
    const user = requireAuth(req, res, "merchant");
    if (!user) return;
    const body = await parseBody(req);
    const idempotencyKey = extractIdempotencyKey(req, body);

    const orderId = Number(refundApproveMatch[1]);
    const result = await runIdempotent({
      scope: "merchant_refund_approve",
      actorId: user.id,
      key: idempotencyKey,
      requestPayload: { order_id: orderId },
      execute: async () => {
        const shopId = user.shop_id || user.id;
        const order = repos.orderRepo.findByIDForShop({ orderID: orderId, shopID: shopId });
        if (!order) return { status: 404, payload: { code: 404, message: "order not found", error_code: "ORDER_NOT_FOUND" } };
        if (order.status !== 5) {
          return {
            status: 400,
            payload: {
              code: 400,
              message: "当前状态不可确认退款",
              error_code: "ORDER_REFUND_NOT_PENDING",
            },
          };
        }

        const buyer = users.find((u) => Number(u.id) === Number(order.user_id)) || null;
        const upstreamIdempotencyKey = idempotencyKey
          ? `merchant_refund_approve:${idempotencyKey}:${orderId}`
          : `merchant_refund_approve:${order.order_no || orderId}`;
        const refund = await alipayMcpService.refundBuyerPayment({
          order,
          buyer,
          merchant: user,
          reason: order.refund_reason || "商家确认退款",
          idempotencyKey: upstreamIdempotencyKey,
        });
        if (!refund.ok) return mapAlipayUpstreamError("refund", refund);

        order.status = 4;
        order.refund_approved_at = new Date().toISOString();
        order.refund_by = user.id;
        order.refund_no = refund.trade_no || order.refund_no || null;
        order.refund_channel = refund.channel || "alipay_mcp";
        order.refund_mode = refund.mode || "mock";
        order.refund_meta = refund.raw || null;
        // 未核销订单退款后回补库存；已核销/已结算订单不回补。
        if (!order.verified_at) {
          await repos.productRepo.restoreStock({ productID: order.product_id, quantity: order.quantity });
        }
        await repos.orderRepo.save(order);
        return { status: 200, payload: { code: 200, message: "refund approved", data: order } };
      },
    });
    return sendJSON(res, result.status, result.payload);
  }

  const reserved = new Set([
    "/api/v1/user/profile",
    "/api/v1/categories",
    "/api/v1/merchant/shop",
    "/api/v1/admin/login",
    "/api/v1/admin/dashboard",
    "/api/v1/admin/merchants",
  ]);

  if (reserved.has(pathname)) {
    return sendJSON(res, 501, {
      code: 501,
      message: "reserved endpoint (not connected in MVP)",
      error_code: "RESERVED_ENDPOINT",
      data: { path: pathname },
    });
  }

  return sendJSON(res, 404, { code: 404, message: "not found", error_code: "API_NOT_FOUND" });
}

const server = http.createServer(async (req, res) => {
  const startedAtMs = Date.now();
  res.localsRequestId = genRequestID();
  res.on("finish", () => logRequest(req, res, startedAtMs));

  const reqUrl = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const pathname = reqUrl.pathname;

  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    });
    res.end();
    return;
  }

  if (pathname.startsWith("/api/")) {
    try {
      await handleApi(req, res, pathname, reqUrl.searchParams);
    } catch (err) {
      if (err && (err.code === "PAYLOAD_TOO_LARGE" || String(err.message || "").includes("payload too large"))) {
        sendJSON(res, 413, {
          code: 413,
          message: "payload too large",
          error_code: "PAYLOAD_TOO_LARGE",
        });
        return;
      }
      sendJSON(res, 500, {
        code: 500,
        message: "server error",
        error: String(err.message || err),
        error_code: "INTERNAL_SERVER_ERROR",
      });
    }
    return;
  }

  let filePath = path.join(PUBLIC_DIR, pathname === "/" ? "/index.html" : pathname);
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("Forbidden");
    return;
  }
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    filePath = path.join(PUBLIC_DIR, "index.html");
  }
  sendFile(res, filePath);
});

function listenServer({ host, port }) {
  return new Promise((resolve, reject) => {
    const onError = (err) => {
      server.off("listening", onListening);
      reject(err);
    };
    const onListening = () => {
      server.off("error", onError);
      resolve();
    };
    server.once("error", onError);
    server.once("listening", onListening);
    server.listen(port, host);
  });
}

async function start() {
  try {
    assertAlipayMcpConfigReady();
    await initSQLite();
  } catch (err) {
    if (String((err && err.message) || "").startsWith("[ALIPAY_MCP]")) {
      console.error(err.message || err);
      process.exit(1);
    }
    console.warn("[SQLITE] init failed, fallback to memory mode:", err.message || err);
    sqliteDb = null;
  }

  repos = createRepositories({
    users,
    products,
    orders,
    cartItems,
    seq,
    persistUser,
    persistProduct,
    persistOrder,
    persistCartItem,
    deleteCartItem,
    withProductLock,
    payTimeoutMs: ORDER_PAY_TIMEOUT_MS,
    pickupTimeoutMs: ORDER_PICKUP_TIMEOUT_MS,
  });

  let listenHost = HOST;
  try {
    await listenServer({ host: listenHost, port: PORT });
  } catch (err) {
    // In some environments 0.0.0.0 binding may be blocked; fallback to localhost.
    if (err && err.code === "EPERM" && listenHost === "0.0.0.0") {
      listenHost = "127.0.0.1";
      console.warn("[MVP] bind 0.0.0.0 blocked, fallback to 127.0.0.1");
      await listenServer({ host: listenHost, port: PORT });
    } else {
      throw err;
    }
  }

  console.log(`[MVP] running on http://${listenHost}:${PORT}`);
  console.log("[MVP] open in browser: http://localhost:" + PORT);
  console.log(`[STORAGE] ${sqliteDb ? "sqlite" : "memory"}`);
  if (sqliteDb) console.log(`[SQLITE] db file: ${SQLITE_PATH}`);
}

start();

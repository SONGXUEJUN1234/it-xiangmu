"""星座认星镜打孔图纸生成。

用法：
    PYTHONUTF8=1 python make_card.py 列表
    PYTHONUTF8=1 python make_card.py 猎户座 --distance 100
"""
import argparse
import sys

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfgen import canvas

from card_math import hole_positions
from star_data import STARS

DIST_MIN, DIST_MAX = 80, 300
ANCHOR_HOLE_MM = 5.0   # 锚点孔直径
STAR_HOLE_MM = 3.0     # 普通星孔直径
MARGIN_MM = 18.0       # 图案到面板裁切边的余量（含星名标签）
EYE_TO_FRAME_MM = 15.0 # 眼睛到眼镜框的近似距离
PRINTABLE_W_MM, PRINTABLE_H_MM = 190.0, 277.0  # A4 去打印机边距

pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))
FONT = "STSong-Light"


def second_brightest(constel):
    """两星锁定法的第 2 颗星：非锚点中最亮者。"""
    others = [s for s in constel["stars"] if s["name"] != constel["anchor"]]
    return min(others, key=lambda s: s["mag"])["name"]


def draw_card(pdf_path, constel_name, constel, distance):
    pos = [{"name": p["name"], "x": p["x"] * mm, "y": p["y"] * mm}
           for p in hole_positions(constel["stars"], constel["anchor"], distance)]
    second = second_brightest(constel)

    half_w = max(abs(p["x"]) for p in pos) / mm + MARGIN_MM
    half_h = max(abs(p["y"]) for p in pos) / mm + MARGIN_MM
    if 2 * half_w > PRINTABLE_W_MM or 2 * half_h > PRINTABLE_H_MM - 10:
        print(f"面板超出 A4 可打印范围（约 {2*half_w:.0f}x{2*half_h:.0f}mm），"
              f"请减小 --distance 后重试", file=sys.stderr)
        raise SystemExit(1)

    c = canvas.Canvas(str(pdf_path), pagesize=A4)
    W, H = A4
    cx, cy = W / 2, H / 2 - 10 * mm

    def zh(txt, x, y, size, align="left"):
        c.setFont(FONT, size)
        if align == "center":
            c.drawCentredString(x, y, txt)
        else:
            c.drawString(x, y, txt)

    # 标题与说明
    zh(f"{constel_name}（{constel['season']}）· 离眼 {int(distance)}mm", W / 2, H - 18 * mm, 14, "center")
    zh("使用：1.闭一只眼，锚点大孔套住亮星  2.歪头旋转，让第二亮星的孔也套住星  "
       "3.其余孔即指向星座各星", W / 2, H - 26 * mm, 9, "center")
    zh("100% 实际大小打印（关闭打印机\"适合页面\"缩放），打印后先量下方标尺应为 50mm",
       W / 2, H - 32 * mm, 9, "center")

    # 面板裁切框
    pw, ph = 2 * half_w * mm, 2 * half_h * mm
    c.setLineWidth(1.2)
    c.rect(cx - pw / 2, cy - ph / 2, pw, ph)

    # 北方向箭头（大致参考，实际以两星锁定为准）
    c.line(cx, cy + ph / 2 - 12 * mm, cx, cy + ph / 2 - 5 * mm)
    c.line(cx, cy + ph / 2 - 5 * mm, cx - 1.5 * mm, cy + ph / 2 - 8 * mm)
    c.line(cx, cy + ph / 2 - 5 * mm, cx + 1.5 * mm, cy + ph / 2 - 8 * mm)
    zh("北", cx + 3 * mm, cy + ph / 2 - 12 * mm, 7)
    zh("此面朝眼", cx - pw / 2 + 3 * mm, cy - ph / 2 + 3 * mm, 7)

    # 折翼粘接边标记（左右边中点各一段虚线）
    c.setDash(3, 2)
    c.line(cx - pw / 2, cy - 10 * mm, cx - pw / 2, cy + 10 * mm)
    c.line(cx + pw / 2, cy - 10 * mm, cx + pw / 2, cy + 10 * mm)
    c.setDash()
    wing_len = distance - EYE_TO_FRAME_MM
    zh(f"折翼：另剪两条 20x{int(wing_len)}mm 硬纸板，沿左右虚线边向后折粘接（末端固定在眼镜框或头带）",
       W / 2, 24 * mm, 8, "center")

    # 孔
    for p in pos:
        x, y = cx + p["x"], cy + p["y"]
        is_anchor = p["name"] == constel["anchor"]
        r = (ANCHOR_HOLE_MM / 2) * mm if is_anchor else (STAR_HOLE_MM / 2) * mm
        c.setLineWidth(1.0)
        c.circle(x, y, r, stroke=1, fill=0)
        if is_anchor:
            c.circle(x, y, r + 2 * mm, stroke=1, fill=0)
            for dx0, dy0 in ((0, 1), (0, -1), (1, 0), (-1, 0)):
                c.line(x + dx0 * (r + 2 * mm), y + dy0 * (r + 2 * mm),
                       x + dx0 * (r + 5 * mm), y + dy0 * (r + 5 * mm))
            zh(f"锚点·{p['name']}", x + 7 * mm, y - 2 * mm, 8)
        elif p["name"] == second:
            c.setDash(2, 2)
            c.circle(x, y, r + 2 * mm, stroke=1, fill=0)
            c.setDash()
            zh(f"第二亮·{p['name']}", x + 7 * mm, y - 2 * mm, 7)
        else:
            zh(p["name"], x + 5 * mm, y - 2 * mm, 6.5)

    # 50mm 校验标尺
    rx, ry = 15 * mm, 40 * mm
    c.setLineWidth(1.2)
    c.line(rx, ry, rx + 50 * mm, ry)
    for i in range(6):
        c.line(rx + i * 10 * mm, ry, rx + i * 10 * mm, ry + 2.5 * mm)
    zh("50mm 校验标尺", rx, ry + 4 * mm, 8)

    c.showPage()
    c.save()


def main(argv=None):
    ap = argparse.ArgumentParser(description="星座认星镜打孔图纸生成")
    ap.add_argument("constellation", help="星座名，或输入：列表")
    ap.add_argument("--distance", type=float, default=100.0,
                    help=f"纸板离眼距离毫米（默认 100，允许 {DIST_MIN}-{DIST_MAX}）")
    ap.add_argument("--out", default=None, help="输出 PDF 路径（默认 星座_距离mm.pdf）")
    args = ap.parse_args(argv)

    if args.constellation == "列表":
        for name, constel in STARS.items():
            print(f"{name}（{constel['season']}，锚点 {constel['anchor']}）")
        return 0

    if args.constellation not in STARS:
        print(f"未知星座：{args.constellation}。可用：{'、'.join(STARS)}", file=sys.stderr)
        return 1
    if not (DIST_MIN <= args.distance <= DIST_MAX):
        print(f"--distance 需在 {DIST_MIN}-{DIST_MAX}mm 之间", file=sys.stderr)
        return 1

    out = args.out or f"{args.constellation}_{int(args.distance)}mm.pdf"
    draw_card(out, args.constellation, STARS[args.constellation], args.distance)
    print(f"已生成 {out}（按 100% 实际大小打印）")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# 外部地图与地理编码资料

| 用途 | 来源 | 关键结论 |
|---|---|---|
| 作品地点坐标的一次性地理编码 | [OpenStreetMap Nominatim 使用政策](https://operations.osmfoundation.org/policies/nominatim/) | 一次性查询采用单线程、1 请求/秒限制与本地缓存；共对 136 个地点查询并缓存坐标。 |
| 真实地图底图 | [Google Maps](https://www.google.com/maps/@20,15,2z?entry=ttu) | 使用 Google Maps 官方“分享→嵌入地图”生成的全球地图嵌入地址，中心约为 20°N, 15°E。 |
| OpenStreetMap 瓦片政策 | [OpenStreetMap Tile Usage Policy](https://operations.osmfoundation.org/policies/tiles/) | 作为地点坐标来源和备选底图参考；实际页面需保留可见归因。 |

作品与封面元数据来自用户授权的微信读书 Agent API；地图仅显示作者字段与书籍详情作者字段均为“猴面包的树”的 101 部作品。

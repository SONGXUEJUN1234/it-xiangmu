/**
 * 田野索引设计提醒：朱砂点与真实地图瓦片共用 Web Mercator 投影；地点索引作为地图顶部蓝色留白中的横向竖排标注带，点击后保留书籍卡片联动。
 */
import { ArrowUpRight, BookOpen, LoaderCircle, MapPin, MousePointer2, Search, X } from "lucide-react";
import { type CSSProperties, useEffect, useMemo, useRef, useState } from "react";

const MAP_DATA_URL = "/manus-storage/map_places_verified_v2_af1fdc78.json";
const MAP_CENTER = { lat: -25, lng: 0 };
const MAP_ZOOM = 2;

type Work = { bookId: string; title: string; cover: string; deepLink: string; evidence: string; confidence: "high" | "medium" | "low" };
type Place = { id: string; label: string; query: string; lat: number; lng: number; fallbackCoordinate: boolean; workCount: number; works: Work[]; verification?: string };

const pluralizeWorks = (count: number) => `${count} 部作品`;

function mercator(lat: number, lng: number) {
  const world = 256 * 2 ** MAP_ZOOM;
  const safeLat = Math.max(-85.05112878, Math.min(85.05112878, lat));
  const sin = Math.sin((safeLat * Math.PI) / 180);
  return { x: ((lng + 180) / 360) * world, y: (0.5 - Math.log((1 + sin) / (1 - sin)) / (4 * Math.PI)) * world };
}

function useMapFrameSize() {
  const frameRef = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ width: 0, height: 0 });
  useEffect(() => {
    if (!frameRef.current) return;
    const resize = () => {
      const rect = frameRef.current?.getBoundingClientRect();
      if (rect) setSize({ width: rect.width, height: rect.height });
    };
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(frameRef.current);
    return () => observer.disconnect();
  }, []);
  return { frameRef, size };
}

function ProjectedAtlas({ places, activePlaceId, onActivate }: { places: Place[]; activePlaceId: string | null; onActivate: (place: Place) => void }) {
  const { frameRef, size } = useMapFrameSize();
  const center = mercator(MAP_CENTER.lat, MAP_CENTER.lng);
  return <div ref={frameRef} className="projected-atlas" aria-label="经纬度核验后的作品地点标记层">
    {size.width > 0 && <svg viewBox={`0 0 ${size.width} ${size.height}`} role="img" aria-label="按真实经纬度标记的作品地点">
      <defs><filter id="pin-shadow" x="-100%" y="-100%" width="300%" height="300%"><feDropShadow dx="0" dy="2" stdDeviation="1.5" floodColor="#5f281e" floodOpacity=".35" /></filter></defs>
      {places.map((place) => {
        const point = mercator(place.lat, place.lng);
        const x = point.x - center.x + size.width / 2;
        const y = point.y - center.y + size.height / 2;
        if (x < -20 || x > size.width + 20 || y < -20 || y > size.height + 20) return null;
        const active = activePlaceId === place.id;
        return <g key={place.id} className={`atlas-dot ${active ? "is-active" : ""}`} transform={`translate(${x} ${y})`} onMouseEnter={() => onActivate(place)} onFocus={() => onActivate(place)} onClick={() => onActivate(place)} tabIndex={0} role="button" aria-label={`${place.label}，${pluralizeWorks(place.workCount)}`}>
          {active && <circle className="atlas-pin-pulse" r="9" />}<circle className="atlas-pin-shell" r={active ? 10 : 7} filter="url(#pin-shadow)" /><circle className="atlas-pin-core" r={active ? 3.8 : 2.4} />
        </g>;
      })}
    </svg>}
    <div className="static-map-caption"><span className="header-note-dot" /> 经纬度已核验 / 作品地点</div>
  </div>;
}

function OpenStreetMapBasemap() {
  const { frameRef, size } = useMapFrameSize();
  const tileSize = 256;
  const tileCount = 2 ** MAP_ZOOM;
  const center = mercator(MAP_CENTER.lat, MAP_CENTER.lng);
  const left = size.width / 2 - center.x;
  const top = size.height / 2 - center.y;
  const startColumn = Math.floor(-left / tileSize) - 1;
  const endColumn = Math.ceil((size.width - left) / tileSize) + 1;
  const startRow = Math.max(0, Math.floor(-top / tileSize) - 1);
  const endRow = Math.min(tileCount - 1, Math.ceil((size.height - top) / tileSize) + 1);
  const tiles: Array<{ key: string; x: number; y: number; sourceX: number }> = [];
  for (let y = startRow; y <= endRow; y += 1) for (let x = startColumn; x <= endColumn; x += 1) tiles.push({ key: `${x}-${y}`, x, y, sourceX: ((x % tileCount) + tileCount) % tileCount });
  return <div ref={frameRef} className="osm-basemap" aria-hidden="true">
    {tiles.map((tile) => <img key={tile.key} src={`https://tile.openstreetmap.org/${MAP_ZOOM}/${tile.sourceX}/${tile.y}.png`} alt="" draggable={false} style={{ left: left + tile.x * tileSize, top: top + tile.y * tileSize }} />)}
    <div className="osm-basemap-wash" />
  </div>;
}

export default function Home() {
  const [places, setPlaces] = useState<Place[]>([]);
  const [query, setQuery] = useState("");
  const [activePlaceId, setActivePlaceId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [dossierTop, setDossierTop] = useState<number | null>(null);
  const [indexAligned, setIndexAligned] = useState(false);
  const mapCanvasRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let mounted = true;
    fetch(MAP_DATA_URL).then((response) => { if (!response.ok) throw new Error("Map data unavailable"); return response.json(); }).then((data: Place[]) => { if (mounted) setPlaces(data); }).catch(() => { if (mounted) setLoadError(true); }).finally(() => { if (mounted) setLoading(false); });
    return () => { mounted = false; };
  }, []);

  const filteredPlaces = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return normalized ? places.filter((place) => `${place.label} ${place.works.map((work) => work.title).join(" ")}`.toLowerCase().includes(normalized)) : places;
  }, [places, query]);
  const activePlace = useMemo(() => places.find((place) => place.id === activePlaceId) ?? null, [activePlaceId, places]);
  const totalWorks = useMemo(() => new Set(places.flatMap((place) => place.works.map((work) => work.bookId))).size, [places]);
  const activateFromMap = (place: Place) => { setActivePlaceId(place.id); setIndexAligned(false); setDossierTop(null); };
  const activateFromIndex = (place: Place, item: HTMLElement) => {
    const canvas = mapCanvasRef.current;
    if (canvas) {
      const itemRect = item.getBoundingClientRect();
      const canvasRect = canvas.getBoundingClientRect();
      const nextTop = itemRect.bottom - canvasRect.top + 20;
      setDossierTop(Math.max(184, Math.min(nextTop, canvasRect.height - 326)));
    }
    setIndexAligned(true);
    setActivePlaceId(place.id);
  };
  const dossierStyle = dossierTop === null ? undefined : ({ "--dossier-top": `${dossierTop}px` } as CSSProperties);

  return <main className="atlas-shell">
    <header className="atlas-header"><div className="brand-lockup"><img className="brand-mark" src="/manus-storage/baobab-map-logo_117d5b8c.png" alt="猴面包树地图标记" /><div><p className="eyebrow">FIELD INDEX / 2026</p><h1>猴面包的树<span>·</span>作品地点地图</h1></div></div><div className="header-note"><span className="header-note-dot" /><p>文字从哪里出发，地图就从哪里展开。</p></div></header>
    <section className="atlas-intro" aria-labelledby="intro-heading"><div className="intro-copy"><p className="eyebrow">A LITERARY ATLAS</p><h2 id="intro-heading">一枚朱砂点，<em>一段远行。</em></h2><p className="intro-body">仅展示同时通过作者字段、原始简介地点证据和坐标核验的关联。每一枚朱砂点均按对应经纬度附着在地图上。</p></div><div className="intro-art" aria-hidden="true" /></section>
    <section className="map-stage" aria-label="作品地点互动地图">
      <div ref={mapCanvasRef} className="map-canvas">
        <OpenStreetMapBasemap />
        <ProjectedAtlas places={filteredPlaces} activePlaceId={activePlaceId} onActivate={activateFromMap} />
        <section className="map-index-rail" aria-label="核验地点索引">
          <div className="rail-summary"><p className="eyebrow">VERIFIED LOCATION INDEX</p><div className="stats-row"><span><strong>{totalWorks || "—"}</strong> 作品</span><span><strong>{places.length || "—"}</strong> 地点</span><span><strong>已核验</strong></span></div><label className="rail-search"><Search size={14} strokeWidth={1.8} /><span className="sr-only">搜索地点或书名</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索地点 / 书名" />{query && <button type="button" onClick={() => setQuery("")} aria-label="清除搜索"><X size={14} /></button>}</label></div>
          <div className="rail-place-track" aria-live="polite">
            {loading && <div className="rail-state"><LoaderCircle className="spin" size={17} /> 读取地点</div>}
            {loadError && <div className="rail-state error">地点资料暂时无法读取</div>}
            {!loading && !loadError && filteredPlaces.length === 0 && <div className="rail-state">没有找到对应地点或作品</div>}
            {!loading && !loadError && filteredPlaces.map((place, index) => <button key={place.id} type="button" className={`rail-place ${activePlaceId === place.id ? "is-active" : ""}`} onMouseEnter={(event) => activateFromIndex(place, event.currentTarget)} onFocus={(event) => activateFromIndex(place, event.currentTarget)} onClick={(event) => activateFromIndex(place, event.currentTarget)} aria-label={`${String(index + 1).padStart(2, "0")} ${place.label}，${pluralizeWorks(place.workCount)}`}><span className="rail-place-index">{String(index + 1).padStart(2, "0")}</span><span className="rail-place-name">{place.label}</span><span className="rail-place-count">{place.workCount}</span></button>)}
          </div>
        </section>
        <div className="map-instruction"><MousePointer2 size={15} /> 悬停朱砂点，查看核验书封</div><div className="map-credit">地点坐标与底图：OpenStreetMap</div>
        {activePlace && <section className={`work-dossier ${indexAligned ? "index-aligned" : ""}`} style={dossierStyle} aria-label={`${activePlace.label} 的作品卡片`}><button type="button" className="close-dossier" onClick={() => setActivePlaceId(null)} aria-label="关闭作品卡片"><X size={16} /></button><div className="dossier-kicker"><MapPin size={14} fill="currentColor" /> {activePlace.label}</div><div className="dossier-title-row"><h3>{pluralizeWorks(activePlace.workCount)}</h3>{activePlace.fallbackCoordinate && <span className="approximate">近似定位</span>}</div><p className="dossier-intro">{activePlace.works[0]?.evidence}</p><div className="cover-rail">{activePlace.works.slice(0, 6).map((work) => <a key={work.bookId} href={work.deepLink} target="_blank" rel="noreferrer" className="book-cover" title={`在微信读书打开《${work.title}》`}><img src={work.cover} alt={`《${work.title}》封面`} /><span>{work.title}</span></a>)}</div>{activePlace.workCount > 6 && <p className="more-works">另有 {activePlace.workCount - 6} 部作品涉及此地</p>}<div className="dossier-footer"><BookOpen size={14} /> 点击封面，可在微信读书查看</div></section>}
      </div>
    </section>
    <footer className="atlas-footer"><p>作品与封面信息来自微信读书；仅展示作者字段、原始简介地点证据及坐标三者均通过核验的关联。</p><a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">© OpenStreetMap contributors <ArrowUpRight size={13} /></a></footer>
  </main>;
}

const { paginate } = require("./paginate");

function createOrderRepository({ orders, seq, persistOrder, productRepo, payTimeoutMs, pickupTimeoutMs }) {
  return {
    async create({ userID, product, quantity }) {
      const orderNo = "ORD" + Date.now() + String(seq.order).padStart(4, "0");
      const order = {
        id: seq.order++,
        order_no: orderNo,
        user_id: userID,
        shop_id: product.shop_id,
        product_id: product.id,
        product_name: product.name,
        quantity,
        total_amount: Number((product.discount_price * quantity).toFixed(2)),
        verify_code: "",
        status: 0, // 待支付
        created_at: new Date().toISOString(),
        pay_expire_at: new Date(Date.now() + payTimeoutMs).toISOString(),
        expires_at: null,
      };
      orders.push(order);
      await persistOrder(order);
      return order;
    },
    async payByUser({ orderID, userID }) {
      const order = orders.find((o) => o.id === orderID && o.user_id === userID) || null;
      if (!order) return { order: null, err: { code: 404, message: "order not found", error_code: "ORDER_NOT_FOUND" } };
      if (order.status !== 0) {
        return { order: null, err: { code: 409, message: "order is not payable", error_code: "ORDER_NOT_PAYABLE" } };
      }
      const now = Date.now();
      if (order.pay_expire_at && now >= new Date(order.pay_expire_at).getTime()) {
        return { order: null, err: { code: 409, message: "order payment expired", error_code: "ORDER_PAYMENT_EXPIRED" } };
      }

      order.status = 1; // 待核销
      order.paid_at = new Date().toISOString();
      order.payment_no = `PAY${Date.now()}${String(order.id).padStart(4, "0")}`;
      order.verify_code = String(Math.floor(100000 + Math.random() * 900000));
      order.expires_at = new Date(Date.now() + pickupTimeoutMs).toISOString();
      await persistOrder(order);
      return { order, err: null };
    },
    listByUser({ userID, status, page, pageSize }) {
      let list = orders.filter((o) => o.user_id === userID);
      if (status !== null && status !== undefined && status !== "") {
        list = list.filter((o) => o.status === Number(status));
      }
      list.sort((a, b) => b.id - a.id);
      return paginate(list, page, pageSize);
    },
    listByShop({ shopID, status, page, pageSize }) {
      let list = orders.filter((o) => o.shop_id === shopID);
      if (status !== null && status !== undefined && status !== "") {
        list = list.filter((o) => o.status === Number(status));
      }
      list.sort((a, b) => b.id - a.id);
      return paginate(list, page, pageSize);
    },
    findByIDForUser({ orderID, userID }) {
      return orders.find((o) => o.id === orderID && o.user_id === userID) || null;
    },
    findByIDForShop({ orderID, shopID }) {
      return orders.find((o) => o.id === orderID && o.shop_id === shopID) || null;
    },
    async save(order) {
      await persistOrder(order);
      return order;
    },
    async refreshTimeoutCanceled() {
      const now = Date.now();
      for (const order of orders) {
        if (order.status === 0 && order.pay_expire_at && now >= new Date(order.pay_expire_at).getTime()) {
          order.status = 3;
          order.cancel_reason = "超时未支付，系统自动取消";
          order.canceled_at = new Date().toISOString();
          await productRepo.restoreStock({ productID: order.product_id, quantity: order.quantity });
          await persistOrder(order);
          continue;
        }

        if (order.status === 1 && order.expires_at && now >= new Date(order.expires_at).getTime()) {
          order.status = 3;
          order.cancel_reason = "超时未核销，系统自动取消";
          order.canceled_at = new Date().toISOString();
          await productRepo.restoreStock({ productID: order.product_id, quantity: order.quantity });
          await persistOrder(order);
        }
      }
    },
  };
}

module.exports = { createOrderRepository };

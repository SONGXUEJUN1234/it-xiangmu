# batch_select.py
# 对最新一批(默认5部)进行：强化 -> 评分 -> 排名 -> 选最优 -> 打包发行
#
# 用法：
#   python batch_select.py --genre hardcore
#   python batch_select.py --genre hardcore --take 5 --pass 80

import argparse
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "out"

def run_cmd(args, timeout=7200):
    return subprocess.run(
        args,
        cwd=str(ROOT),
        text=True,
        capture_output=True,
        encoding="utf-8",
        timeout=timeout
    )

def load_json(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))

def write_json(p: Path, obj):
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")

def find_latest_batch_files(genre: str, take: int):
    # 文件名形如 genre_out_YYYYMMDD_HHMMSS_01.json
    files = sorted(OUT.glob(f"{genre}_out_????????_??????_??.json"))
    if not files:
        raise FileNotFoundError("找不到批量生成文件，请先运行 panel_gen.py")
    # 取最新时间戳
    latest = files[-1].name.split("_out_")[1].split("_")[0] + "_" + files[-1].name.split("_out_")[1].split("_")[1]
    batch = sorted(OUT.glob(f"{genre}_out_{latest}_??.json"))
    if len(batch) < take:
        # 兜底：取最后 take 个
        batch = files[-take:]
    else:
        batch = batch[:take]
    return batch, latest

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--genre", required=True, choices=["hardcore","mechanism","emotional","horror"])
    ap.add_argument("--take", type=int, default=5)
    ap.add_argument("--pass", dest="pass_threshold", type=int, default=80)
    args = ap.parse_args()

    enhancer = ROOT / "enhancer.py"
    scorer = ROOT / "scorer.py"
    releaser = ROOT / "juben_release.py"

    batch_files, batch_id = find_latest_batch_files(args.genre, args.take)
    print("本批次:", batch_id)
    print("文件数:", len(batch_files))

    ranking = []

    for i, f in enumerate(batch_files, 1):
        print(f"\n[{i}/{len(batch_files)}] 强化: {f.name}")
        p2 = run_cmd(["python", str(enhancer), str(f)])
        if p2.returncode != 0:
            print("强化失败:", (p2.stderr or p2.stdout)[:300])
            continue

        plus = OUT / (f.stem + "_plus.json")
        if not plus.exists():
            # 兼容 enhancer 旧命名：genre_out_plus.json
            alt = OUT / f"{args.genre}_out_plus.json"
            plus = alt if alt.exists() else plus

        print(f"[{i}/{len(batch_files)}] 评分: {plus.name}")
        p3 = run_cmd(["python", str(scorer), str(plus)])
        if p3.returncode != 0:
            print("评分失败:", (p3.stderr or p3.stdout)[:300])
            continue

        score_path = OUT / (plus.stem + "_score.json")
        if not score_path.exists():
            # 兼容 scorer 固定命名
            alt = OUT / f"{args.genre}_out_plus_score.json"
            score_path = alt if alt.exists() else score_path

        score_obj = load_json(score_path)
        final_score = int(score_obj.get("final_score", 0))
        passed = bool(score_obj.get("pass", False))

        ranking.append({
            "source": str(f),
            "enhanced": str(plus),
            "score_file": str(score_path),
            "final_score": final_score,
            "pass": passed
        })

        print("得分:", final_score, "通过:", passed)

    ranking.sort(key=lambda x: x["final_score"], reverse=True)

    rank_out = OUT / f"{args.genre}_batch_rank_{batch_id}.json"
    write_json(rank_out, {"batch_id": batch_id, "items": ranking})
    print("\n榜单已写入:", rank_out)

    if not ranking:
        print("本批次没有可用结果")
        return

    best = ranking[0]
    if best["final_score"] < args.pass_threshold or not best["pass"]:
        print("最高分未达标，停止打包。最高分:", best["final_score"])
        return

    print("\n开始打包最优作品:", best["enhanced"])
    p4 = run_cmd(["python", str(releaser), "pack", best["enhanced"]])
    if p4.returncode != 0:
        print("打包失败:", (p4.stderr or p4.stdout)[:400])
        return

    print(p4.stdout.strip())

if __name__ == "__main__":
    main()
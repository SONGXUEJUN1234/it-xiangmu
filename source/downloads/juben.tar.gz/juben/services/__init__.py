# Service layer for UI pipeline orchestration.

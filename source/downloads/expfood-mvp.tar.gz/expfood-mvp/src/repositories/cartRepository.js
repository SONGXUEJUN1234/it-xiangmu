function createCartRepository({ cartItems, seq, persistCartItem, deleteCartItem }) {
  return {
    listByUser({ userID }) {
      return cartItems.filter((item) => item.user_id === userID).sort((a, b) => b.id - a.id);
    },
    async addItem({ userID, product, quantity }) {
      if (quantity <= 0) {
        return { item: null, err: { code: 400, message: "invalid quantity", error_code: "CART_INVALID_QUANTITY" } };
      }

      const userItems = cartItems.filter((item) => item.user_id === userID);
      const existingShopId = userItems.length ? Number(userItems[0].shop_id) : null;
      if (existingShopId !== null && existingShopId !== Number(product.shop_id)) {
        return {
          item: null,
          err: {
            code: 409,
            message: "购物车仅支持单商家，请先清空或结算购物车",
            error_code: "CART_MULTI_SHOP_NOT_ALLOWED",
            data: { current_shop_id: existingShopId, incoming_shop_id: Number(product.shop_id) },
          },
        };
      }

      const now = new Date().toISOString();
      const existing = userItems.find((item) => item.product_id === product.id);
      if (existing) {
        existing.quantity += quantity;
        existing.updated_at = now;
        await persistCartItem(existing);
        return { item: existing, err: null };
      }

      const item = {
        id: seq.cart++,
        user_id: userID,
        shop_id: Number(product.shop_id),
        product_id: Number(product.id),
        product_name: String(product.name || ""),
        product_price: Number(product.discount_price),
        quantity,
        created_at: now,
        updated_at: now,
      };
      cartItems.push(item);
      await persistCartItem(item);
      return { item, err: null };
    },
    async updateQuantity({ userID, itemID, quantity }) {
      if (quantity <= 0) {
        return { item: null, err: { code: 400, message: "invalid quantity", error_code: "CART_INVALID_QUANTITY" } };
      }
      const item = cartItems.find((it) => it.id === itemID && it.user_id === userID) || null;
      if (!item) return { item: null, err: { code: 404, message: "cart item not found", error_code: "CART_ITEM_NOT_FOUND" } };
      item.quantity = quantity;
      item.updated_at = new Date().toISOString();
      await persistCartItem(item);
      return { item, err: null };
    },
    async removeItem({ userID, itemID }) {
      const idx = cartItems.findIndex((it) => it.id === itemID && it.user_id === userID);
      if (idx < 0) return { ok: false, err: { code: 404, message: "cart item not found", error_code: "CART_ITEM_NOT_FOUND" } };
      const [removed] = cartItems.splice(idx, 1);
      await deleteCartItem(removed.id);
      return { ok: true, err: null };
    },
    async clearByUser({ userID }) {
      const targets = cartItems.filter((it) => it.user_id === userID).map((it) => it.id);
      for (const id of targets) {
        await deleteCartItem(id);
      }
      for (let i = cartItems.length - 1; i >= 0; i -= 1) {
        if (cartItems[i].user_id === userID) cartItems.splice(i, 1);
      }
    },
  };
}

module.exports = { createCartRepository };

"""CLI 行为测试。"""
import pytest

import make_card


def test_list_outputs_all_constellations(capsys):
    rc = make_card.main(["列表"])
    assert rc == 0
    out = capsys.readouterr().out
    for name in ("猎户座", "北斗七星", "仙后座", "天鹅座", "天琴座"):
        assert name in out


def test_generate_pdf(tmp_path):
    out = tmp_path / "北斗_100mm.pdf"
    rc = make_card.main(["北斗七星", "--distance", "100", "--out", str(out)])
    assert rc == 0
    assert out.exists() and out.stat().st_size > 1000


def test_unknown_constellation_returns_1(capsys):
    assert make_card.main(["处女座"]) == 1
    assert "未知星座" in capsys.readouterr().err


def test_distance_out_of_range_returns_1(capsys):
    assert make_card.main(["北斗七星", "--distance", "50"]) == 1
    assert "--distance" in capsys.readouterr().err


def test_oversize_distance_rejected(tmp_path, capsys):
    """1:1 毫米尺度守卫：北斗在 300mm 离眼时面板必然超 A4，应报错而非缩放。

    若孔位毫米被误当点用，守卫口径随之缩小 2.83 倍、永不触发，本测试失败。"""
    out = tmp_path / "oversize.pdf"
    with pytest.raises(SystemExit) as exc_info:
        make_card.main(["北斗七星", "--distance", "300", "--out", str(out)])
    assert exc_info.value.code == 1
    assert "减小 --distance" in capsys.readouterr().err

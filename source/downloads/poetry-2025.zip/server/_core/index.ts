import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { streamLLM } from "./llm";
import { cacheInterpretation, getPoemById } from "../db";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => server.close(() => resolve(true)));
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) return port;
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function writeChunk(res: express.Response, chunk: string) {
  if (!res.writableEnded) res.write(`data: ${JSON.stringify({ chunk })}\n\n`);
}

function finishStream(res: express.Response) {
  if (!res.writableEnded) { res.write("data: [DONE]\n\n"); res.end(); }
}

async function streamInterpretation(req: express.Request, res: express.Response) {
  const id = Number(req.params.id);
  const poem = await getPoemById(id);
  if (!poem) return res.status(404).json({ error: "Poem not found" });
  res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();

  if (poem.interpretation) { writeChunk(res, poem.interpretation); return finishStream(res); }

  try {
    const interpretation = await streamLLM({
      messages: [
        { role: "system", content: "你是一位克制、敏锐的中文诗歌评论家。请用中文写一篇约500字的赏析，分为‘阅读入口’、‘意象与语言’、‘余韵’三段，避免过度拔高，不虚构作者背景。" },
        { role: "user", content: `请赏析以下诗作《${poem.title}》：\n\n${poem.body}` },
      ],
    }, chunk => writeChunk(res, chunk));
    await cacheInterpretation(id, interpretation);
    finishStream(res);
  } catch (error) {
    console.error("[LLM] interpretation failed", error);
    if (!res.writableEnded) {
      res.write(`data: ${JSON.stringify({ error: "赏析生成失败，请稍后再试。" })}\n\n`);
      res.end();
    }
  }
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  app.get("/api/poems/:id/interpretation", streamInterpretation);
  app.use("/api/trpc", createExpressMiddleware({ router: appRouter, createContext }));
  if (process.env.NODE_ENV === "development") await setupVite(app, server);
  else serveStatic(app);
  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);
  if (port !== preferredPort) console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  server.listen(port, () => console.log(`Server running on http://localhost:${port}/`));
}

startServer().catch(console.error);

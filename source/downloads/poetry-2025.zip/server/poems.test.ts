import { describe, expect, it } from "vitest";
import { selectedPoems } from "../shared/poems";

describe("selected poems", () => {
  it("contains exactly twenty numbered poems", () => {
    expect(selectedPoems).toHaveLength(20);
    expect(selectedPoems.map(poem => poem.id)).toEqual(Array.from({ length: 20 }, (_, index) => index + 1));
  });

  it("covers both classical and modern forms with readable content", () => {
    expect(new Set(selectedPoems.map(poem => poem.form))).toEqual(new Set(["古体诗", "现代诗"]));
    for (const poem of selectedPoems) {
      expect(poem.title.trim().length).toBeGreaterThan(0);
      expect(poem.body.trim().length).toBeGreaterThan(8);
      expect(poem.note.trim().length).toBeGreaterThan(0);
    }
  });
});

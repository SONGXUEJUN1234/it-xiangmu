import datetime
import sys
from pathlib import Path

import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from services.pipeline_service import get_job, get_job_log, list_outputs, recent_jobs, submit_pipeline


st.set_page_config(page_title="剧本杀内容工厂 UI", layout="wide")
st.title("剧本杀内容工厂 UI")
st.caption("基于现有 factory.py 流水线的可视化入口")


with st.sidebar:
    st.subheader("运行参数")
    genre = st.selectbox("Genre", ["all", "hardcore", "mechanism", "emotional", "horror"], index=0)
    count = st.number_input("每类生成数量 --count", min_value=1, max_value=20, value=5, step=1)
    top = st.number_input("每类保留 Top --top", min_value=1, max_value=10, value=1, step=1)
    base_pass = st.number_input("基础通过线 --pass", min_value=60, max_value=95, value=80, step=1)
    player_count = st.number_input("玩家人数 --player-count", min_value=4, max_value=12, value=6, step=1)
    difficulty = st.selectbox("难度 --difficulty", ["easy", "medium", "hard"], index=2)
    duration = st.text_input("时长 --duration", value="")
    tags = st.text_input("标签 --tags（逗号分隔）", value="")
    setting_hint = st.text_area("背景提示 --setting-hint", value="", height=90)
    retries = st.number_input("重试次数 --retries", min_value=1, max_value=8, value=3, step=1)
    timeout = st.number_input("超时秒数 --timeout", min_value=300, max_value=14400, value=3600, step=60)
    no_pack = st.checkbox("只选优不打包 --no-pack", value=False)

    run = st.button("启动任务", type="primary", use_container_width=True)

if run:
    params = {
        "genre": genre,
        "count": int(count),
        "top": int(top),
        "base_pass": int(base_pass),
        "player_count": int(player_count),
        "difficulty": difficulty,
        "duration": duration.strip(),
        "tags": tags.strip(),
        "setting_hint": setting_hint.strip(),
        "retries": int(retries),
        "timeout": int(timeout),
        "no_pack": no_pack,
    }
    job_id = submit_pipeline(params)
    st.session_state["active_job_id"] = job_id
    st.success(f"任务已启动: {job_id}")


cols = st.columns([1.2, 2.2])

with cols[0]:
    st.subheader("最近任务")
    jobs = recent_jobs(limit=20)
    if not jobs:
        st.info("暂无任务")
    else:
        options = [f"{j.get('job_id')} | {j.get('status')}" for j in jobs]
        picked = st.selectbox("选择任务查看", options=options, index=0)
        selected_id = picked.split("|")[0].strip()
        st.session_state["active_job_id"] = selected_id

        status = get_job(selected_id)
        st.write(
            {
                "job_id": status.get("job_id"),
                "status": status.get("status"),
                "returncode": status.get("returncode"),
                "updated_at": status.get("updated_at"),
            }
        )

        if st.button("刷新任务状态", use_container_width=True):
            st.rerun()

with cols[1]:
    st.subheader("任务日志")
    active_job_id = st.session_state.get("active_job_id")
    if not active_job_id:
        st.info("先在左侧启动或选择一个任务")
    else:
        status = get_job(active_job_id)
        st.caption(
            f"Job: {active_job_id} | Status: {status.get('status')} | "
            f"Updated: {status.get('updated_at') or datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        )
        log_text = get_job_log(active_job_id, max_lines=500)
        st.text_area("run.log", value=log_text, height=420)
        if st.button("刷新日志", key="refresh_log"):
            st.rerun()


st.subheader("最新产物")
outputs = list_outputs(limit=60)
if not outputs:
    st.info("暂无产物")
else:
    for item in outputs:
        p = Path(item["path"])
        c1, c2, c3, c4 = st.columns([2.6, 1.0, 1.1, 1.3])
        c1.write(item["relative"])
        c2.write(f"{item['size'] / 1024:.1f} KB")
        c3.write(datetime.datetime.fromtimestamp(item["mtime"]).strftime("%Y-%m-%d %H:%M:%S"))
        if p.exists():
            with p.open("rb") as f:
                c4.download_button(
                    "下载",
                    data=f.read(),
                    file_name=p.name,
                    mime="application/octet-stream",
                    key=f"dl_{item['relative']}",
                )

import { describe, expect, it } from "vitest";
import { clampSoundVolume, toggleSoundMode } from "@shared/soundscape";

describe("soundscape controls", () => {
  it("starts muted and resumes the last active mode", () => {
    expect(toggleSoundMode("off", "music")).toBe("music");
    expect(toggleSoundMode("music", "music")).toBe("off");
    expect(toggleSoundMode("off", "nature")).toBe("nature");
  });

  it("clamps volume to the intentionally quiet ambient range", () => {
    expect(clampSoundVolume(-1)).toBe(0);
    expect(clampSoundVolume(0.22)).toBe(0.22);
    expect(clampSoundVolume(1)).toBe(0.4);
  });
});

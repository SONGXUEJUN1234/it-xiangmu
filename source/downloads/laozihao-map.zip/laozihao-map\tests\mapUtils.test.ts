import { describe, it, expect } from "vitest";
import { clusterPlaces } from "../src/mapUtils";
import seeds from "../public/data/brands.json";
import { validateBrands } from "../src/model";
const brands = validateBrands(seeds);
const places = [
  { name: "甲市", point: [0, 0] as [number, number], members: [brands[0]] },
  {
    name: "乙市",
    point: [20, 0] as [number, number],
    members: [brands[1], brands[2]],
  },
  { name: "丙市", point: [200, 50] as [number, number], members: [brands[3]] },
];
describe("screen-space marker clustering", () => {
  it("combines nearby places while retaining every brand", () => {
    const result = clusterPlaces(places, 1);
    expect(result).toHaveLength(2);
    expect(result[0].members).toHaveLength(3);
    expect(result[0].places.map((p) => p.name)).toEqual(["甲市", "乙市"]);
    expect(result.reduce((n, c) => n + c.members.length, 0)).toBe(4);
  });
  it("unpacks nearby places when zooming in", () =>
    expect(clusterPlaces(places, 3)).toHaveLength(3));
  it("uses screen pixels so narrow screens cluster sooner", () =>
    expect(clusterPlaces(places, 0.1)).toHaveLength(1));
  it("does not mutate input member arrays or positions", () => {
    const before = JSON.stringify(places);
    clusterPlaces(places, 0.1);
    expect(JSON.stringify(places)).toBe(before);
  });
  it("handles empty filtered results", () =>
    expect(clusterPlaces([], 1)).toEqual([]));
});

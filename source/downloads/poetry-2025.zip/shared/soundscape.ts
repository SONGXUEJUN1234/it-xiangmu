export type SoundMode = "off" | "music" | "nature";

export function toggleSoundMode(mode: SoundMode, lastActiveMode: Exclude<SoundMode, "off">): SoundMode {
  return mode === "off" ? lastActiveMode : "off";
}

export function clampSoundVolume(value: number) {
  return Math.min(0.4, Math.max(0, value));
}

const test = require("node:test");
const assert = require("node:assert/strict");
const { createRepositories } = require("../src/repositories/createRepositories");

function createTestRepos() {
  const users = [{ id: 1, phone: "13800138000", role: "buyer", nickname: "buyer-demo", shop_id: null }];
  const products = [
    {
      id: 1,
      shop_id: 1,
      category_id: 1,
      name: "test product",
      description: "",
      images: [],
      original_price: 20,
      discount_price: 10,
      discount: 50,
      stock: 5,
      status: 1,
      created_at: new Date().toISOString(),
    },
  ];
  const orders = [];
  const cartItems = [];
  const seq = { user: 1, product: 2, order: 1, cart: 1 };
  const noop = async () => {};
  const withProductLock = async (_id, task) => task();

  const repos = createRepositories({
    users,
    products,
    orders,
    cartItems,
    seq,
    persistUser: noop,
    persistProduct: noop,
    persistOrder: noop,
    persistCartItem: noop,
    deleteCartItem: noop,
    withProductLock,
    payTimeoutMs: 15 * 60 * 1000,
    pickupTimeoutMs: 15 * 60 * 1000,
  });

  return { repos, users, products, orders, cartItems };
}

test("下单会扣减库存并创建订单", async () => {
  const { repos, products, orders } = createTestRepos();
  const reserved = await repos.productRepo.reserveStock({ productID: 1, quantity: 2 });
  assert.equal(reserved.err, null);
  assert.equal(products[0].stock, 3);

  const order = await repos.orderRepo.create({ userID: 1, product: reserved.product, quantity: 2 });
  assert.equal(order.status, 0);
  assert.equal(order.quantity, 2);
  assert.equal(orders.length, 1);
});

test("取消订单会恢复库存并更新状态", async () => {
  const { repos, products } = createTestRepos();
  const reserved = await repos.productRepo.reserveStock({ productID: 1, quantity: 1 });
  const order = await repos.orderRepo.create({ userID: 1, product: reserved.product, quantity: 1 });

  order.status = 3;
  order.cancel_reason = "用户取消";
  await repos.productRepo.restoreStock({ productID: order.product_id, quantity: order.quantity });
  await repos.orderRepo.save(order);

  const loaded = repos.orderRepo.findByIDForUser({ orderID: order.id, userID: 1 });
  assert.equal(loaded.status, 3);
  assert.equal(loaded.cancel_reason, "用户取消");
  assert.equal(products[0].stock, 5);
});

test("核销订单会更新为已完成且可按状态筛选", async () => {
  const { repos } = createTestRepos();
  const reserved = await repos.productRepo.reserveStock({ productID: 1, quantity: 1 });
  const order = await repos.orderRepo.create({ userID: 1, product: reserved.product, quantity: 1 });

  const paid = await repos.orderRepo.payByUser({ orderID: order.id, userID: 1 });
  assert.equal(paid.err, null);
  assert.equal(paid.order.status, 1);

  paid.order.status = 2;
  paid.order.verified_at = new Date().toISOString();
  paid.order.verified_by = 99;
  await repos.orderRepo.save(paid.order);

  const done = repos.orderRepo.listByShop({ shopID: 1, status: 2, page: 1, pageSize: 10 });
  assert.equal(done.total, 1);
  assert.equal(done.items[0].id, paid.order.id);
  assert.equal(done.items[0].status, 2);
});

test("退款待确认状态可按商家维度筛选", async () => {
  const { repos } = createTestRepos();
  const reserved = await repos.productRepo.reserveStock({ productID: 1, quantity: 1 });
  const order = await repos.orderRepo.create({ userID: 1, product: reserved.product, quantity: 1 });
  const paid = await repos.orderRepo.payByUser({ orderID: order.id, userID: 1 });
  assert.equal(paid.err, null);

  paid.order.status = 5;
  paid.order.refund_reason = "已核销申请退款";
  paid.order.refund_requested_at = new Date().toISOString();
  await repos.orderRepo.save(paid.order);

  const pendingRefund = repos.orderRepo.listByShop({ shopID: 1, status: 5, page: 1, pageSize: 10 });
  assert.equal(pendingRefund.total, 1);
  assert.equal(pendingRefund.items[0].status, 5);
});

test("分页和关键词筛选返回正确结果", () => {
  const { repos } = createTestRepos();
  repos.productRepo.create({
    shop_id: 1,
    category_id: 1,
    name: "apple bread",
    description: "",
    images: [],
    original_price: 10,
    discount_price: 8,
    discount: 20,
    stock: 10,
    status: 1,
    created_at: new Date().toISOString(),
  });
  repos.productRepo.create({
    shop_id: 1,
    category_id: 1,
    name: "apple cake",
    description: "",
    images: [],
    original_price: 12,
    discount_price: 9,
    discount: 25,
    stock: 10,
    status: 1,
    created_at: new Date().toISOString(),
  });

  const page1 = repos.productRepo.listPublic({ keyword: "apple", page: 1, pageSize: 1 });
  const page2 = repos.productRepo.listPublic({ keyword: "apple", page: 2, pageSize: 1 });

  assert.equal(page1.total, 2);
  assert.equal(page1.items.length, 1);
  assert.equal(page2.items.length, 1);
  assert.notEqual(page1.items[0].id, page2.items[0].id);
});

test("购物车限制单商家且同商品会合并数量", async () => {
  const { repos } = createTestRepos();
  const first = repos.productRepo.getByID(1);
  const add1 = await repos.cartRepo.addItem({ userID: 1, product: first, quantity: 1 });
  assert.equal(add1.err, null);
  assert.equal(add1.item.quantity, 1);

  const add2 = await repos.cartRepo.addItem({ userID: 1, product: first, quantity: 2 });
  assert.equal(add2.err, null);
  assert.equal(add2.item.quantity, 3);

  const otherShopProduct = await repos.productRepo.create({
    shop_id: 2,
    category_id: 1,
    name: "other shop bread",
    description: "",
    images: [],
    original_price: 8,
    discount_price: 6,
    discount: 25,
    stock: 8,
    status: 1,
    created_at: new Date().toISOString(),
  });
  const add3 = await repos.cartRepo.addItem({ userID: 1, product: otherShopProduct, quantity: 1 });
  assert.equal(add3.err.code, 409);
  assert.equal(add3.err.error_code, "CART_MULTI_SHOP_NOT_ALLOWED");
});

export type PosterPoem = { id: number; title: string; body: string; form: string };

function escapeXml(value: string) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

function wrapText(text: string, width: number) {
  const result: string[] = [];
  for (const paragraph of text.split(/\n/)) {
    if (!paragraph) { result.push(""); continue; }
    for (let i = 0; i < paragraph.length; i += width) result.push(paragraph.slice(i, i + width));
  }
  return result;
}

function svgLines(lines: string[], x: number, y: number, lineHeight: number, className: string) {
  return `<text x="${x}" y="${y}" class="${className}">${lines.map((line, index) => `<tspan x="${x}" dy="${index === 0 ? 0 : lineHeight}">${escapeXml(line) || " "}</tspan>`).join("")}</text>`;
}

export function createPosterSvg(poem: PosterPoem, summary: string) {
  const poemLines = wrapText(poem.body, 25).slice(0, 18);
  const summaryLines = wrapText(summary, 38).slice(0, 8);
  const number = String(poem.id).padStart(2, "0");
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1600" viewBox="0 0 1080 1600"><rect width="1080" height="1600" fill="#f4f1ea"/><rect x="42" y="42" width="996" height="1516" fill="none" stroke="#d9d3c7" stroke-width="2"/><circle cx="92" cy="100" r="22" fill="none" stroke="#a24e38" stroke-width="2"/><path d="M82 109 Q92 91 103 89 Q95 104 82 109Z" fill="none" stroke="#a24e38" stroke-width="2"/><text x="135" y="98" class="brand">2025 诗篇</text><text x="135" y="123" class="meta">一年之内的回声</text><text x="950" y="103" text-anchor="end" class="meta">${number} / 20</text><line x1="92" y1="190" x2="988" y2="190" stroke="#a24e38" stroke-width="3"/><text x="92" y="245" class="meta accent">${escapeXml(poem.form)} · 2025</text><text x="92" y="330" class="title">${escapeXml(poem.title)}</text>${svgLines(poemLines, 92, 430, 42, "poem")}<line x1="92" y1="1065" x2="988" y2="1065" stroke="#d9d3c7" stroke-width="2"/><text x="92" y="1115" class="meta accent">AI 赏析摘要</text>${svgLines(summaryLines, 92, 1165, 35, "summary")}<text x="92" y="1515" class="footer">从《2025》精选 · 愿每一次阅读，都把时间还给自己。</text><style>.brand{font:600 25px 'Noto Serif SC',serif;letter-spacing:5px;fill:#28251f}.meta{font:16px 'Source Sans 3',sans-serif;letter-spacing:3px;fill:#8e897e}.accent{fill:#a24e38}.title{font:600 64px 'Noto Serif SC',serif;letter-spacing:3px;fill:#28251f}.poem{font:25px 'Noto Serif SC',serif;letter-spacing:2px;fill:#28251f}.summary{font:19px 'Noto Serif SC',serif;letter-spacing:1px;fill:#59544b}.footer{font:14px 'Source Sans 3',sans-serif;letter-spacing:2px;fill:#8e897e}</style></svg>`;
}

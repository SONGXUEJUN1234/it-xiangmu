import { z } from "zod";
import Papa from "papaparse";

export const CATEGORIES = [
  { id: "all", label: "全部老字号", short: "全部", color: "#a33e2c" },
  { id: "restaurant", label: "餐饮饭店", short: "餐饮", color: "#a33e2c" },
  { id: "food", label: "食品糕点", short: "食品", color: "#b68443" },
  { id: "tea", label: "茶叶茶饮", short: "茶叶", color: "#4b7560" },
  { id: "seasoning", label: "调味香料", short: "调味", color: "#ac6748" },
  { id: "medicine", label: "传统医药", short: "医药", color: "#757752" },
  { id: "drink", label: "酒水饮品", short: "酒饮", color: "#8a5961" },
  { id: "daily", label: "日用美妆", short: "日用", color: "#7a8e94" },
  { id: "clothing", label: "服饰鞋帽", short: "服饰", color: "#637b96" },
  { id: "craft", label: "工艺文具", short: "工艺", color: "#88789b" },
] as const;
export const categoryIds = [
  "restaurant",
  "food",
  "tea",
  "seasoning",
  "medicine",
  "drink",
  "daily",
  "clothing",
  "craft",
] as const;
const webUrl = z
  .string()
  .url()
  .max(2000)
  .refine((s) => /^https?:\/\//i.test(s), "仅允许 http / https 链接");
const sourceSchema = z.object({
  title: z.string().min(1).max(200),
  url: webUrl,
});
export const brandSchema = z.object({
  id: z
    .string()
    .regex(/^[a-z0-9][a-z0-9-]{0,79}$/, "ID 只允许小写字母、数字、连字符"),
  name: z.string().trim().min(1).max(60),
  province: z.string().trim().min(1).max(30),
  city: z.string().trim().min(1).max(40),
  categories: z.array(z.enum(categoryIds)).min(1).max(9),
  description: z.string().trim().min(1).max(800),
  specialties: z.array(z.string().min(1).max(60)).max(12),
  sources: z.array(sourceSchema).min(1).max(15),
  shop: z
    .object({
      label: z.string().min(1).max(100),
      url: webUrl,
      evidenceUrl: webUrl,
      verification: z.enum(["official", "platform"]).optional(),
    })
    .nullable(),
  website: webUrl.nullable(),
  checkedAt: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/)
    .refine(
      (s) =>
        !Number.isNaN(Date.parse(s)) &&
        new Date(s).toISOString().slice(0, 10) === s,
      "核验日期无效",
    ),
  recognitionEvidence: z.string().min(1).max(1200),
  image: z
    .object({
      url: webUrl,
      alt: z.string().min(1).max(200),
      sourceUrl: webUrl,
      license: z.string().min(1).max(300),
    })
    .nullable()
    .optional(),
});
export type Brand = z.infer<typeof brandSchema>;
export type Region = {
  name: string;
  code: number;
  center: [number, number];
  cities: { name: string; center: [number, number] }[];
};
export type Filters = {
  query: string;
  category: string;
  province: string;
  city: string;
  shopping: boolean;
};
export const EMPTY_FILTERS: Filters = {
  query: "",
  category: "all",
  province: "",
  city: "",
  shopping: false,
};
export type Correction = {
  id: string;
  brandId: string;
  brandName: string;
  text: string;
  createdAt: string;
};
export const STORAGE_KEY = "laozihao-map.brands.v1";
export const CORRECTION_KEY = "laozihao-map.corrections.v1";
export const REGISTRY_URL =
  "https://opendata.mofcom.gov.cn/front/data/detail?id=NM012";

export function validateBrands(input: unknown, regions?: Region[]): Brand[] {
  const result = z
    .array(brandSchema)
    .min(1, "至少保留一个品牌")
    .max(10000)
    .parse(input);
  const ids = new Set<string>();
  for (const brand of result) {
    if (ids.has(brand.id)) throw new Error(`品牌 ID 重复：${brand.id}`);
    ids.add(brand.id);
    if (regions) {
      const region = regions.find((r) => r.name === brand.province);
      if (!region) throw new Error(`${brand.name}：省份不在地区表中`);
      if (
        brand.city !== region.name &&
        !region.cities.some((c) => c.name === brand.city)
      )
        throw new Error(`${brand.name}：城市与省份不匹配`);
    }
  }
  return result;
}

export function filterBrands(brands: Brand[], filters: Filters) {
  const words = filters.query
    .trim()
    .toLocaleLowerCase()
    .split(/\s+/)
    .filter(Boolean);
  return brands.filter((b) => {
    const haystack = [
      b.name,
      b.province,
      b.city,
      b.description,
      ...b.specialties,
      ...b.categories.map((c) => CATEGORIES.find((x) => x.id === c)?.label),
    ]
      .join(" ")
      .toLocaleLowerCase();
    return (
      words.every((w) => haystack.includes(w)) &&
      (filters.category === "all" ||
        b.categories.includes(
          filters.category as (typeof categoryIds)[number],
        )) &&
      (!filters.province || b.province === filters.province) &&
      (!filters.city || b.city === filters.city) &&
      (!filters.shopping || b.shop !== null)
    );
  });
}

export function readFilters(search: string): Filters {
  const p = new URLSearchParams(search);
  return {
    query: (p.get("q") || "").slice(0, 100),
    category: CATEGORIES.some((c) => c.id === p.get("category"))
      ? p.get("category")!
      : "all",
    province: p.get("province") || "",
    city: p.get("city") || "",
    shopping: p.get("shop") === "1",
  };
}
export function writeFilters(f: Filters, brandId?: string) {
  const p = new URLSearchParams();
  if (f.query) p.set("q", f.query);
  if (f.category !== "all") p.set("category", f.category);
  if (f.province) p.set("province", f.province);
  if (f.city) p.set("city", f.city);
  if (f.shopping) p.set("shop", "1");
  if (brandId) p.set("brand", brandId);
  return p.size ? `?${p}` : window.location.pathname;
}
export function shortRegion(name: string) {
  return name.replace(
    /壮族自治区|回族自治区|维吾尔自治区|特别行政区|自治区|省|市/g,
    "",
  );
}
export function exportCsv(brands: Brand[]) {
  return (
    "\uFEFF" +
    Papa.unparse(
      brands.map((b) => ({
        id: b.id,
        name: b.name,
        province: b.province,
        city: b.city,
        categories: b.categories.join("|"),
        description: b.description,
        specialties: b.specialties.join("|"),
        sources: JSON.stringify(b.sources),
        shop: b.shop ? JSON.stringify(b.shop) : "",
        website: b.website || "",
        checkedAt: b.checkedAt,
        recognitionEvidence: b.recognitionEvidence,
        image: b.image ? JSON.stringify(b.image) : "",
      })),
      { escapeFormulae: true },
    )
  );
}
export function importCsv(text: string, regions?: Region[]) {
  const parsed = Papa.parse<Record<string, string>>(
    text.replace(/^\uFEFF/, ""),
    {
      header: true,
      skipEmptyLines: "greedy",
      transformHeader: (h) => h.trim(),
    },
  );
  if (parsed.errors.length)
    throw new Error(`CSV 格式错误：${parsed.errors[0].message}`);
  return validateBrands(
    parsed.data.map((row) => ({
      ...row,
      categories: (row.categories || "").split("|").filter(Boolean),
      specialties: (row.specialties || "").split("|").filter(Boolean),
      sources: JSON.parse(row.sources || "[]"),
      shop: row.shop ? JSON.parse(row.shop) : null,
      website: row.website || null,
      image: row.image ? JSON.parse(row.image) : null,
    })),
    regions,
  );
}
export function downloadFile(
  filename: string,
  content: string,
  type = "application/json",
) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export function errorMessage(error: unknown) {
  return error instanceof z.ZodError
    ? error.issues
        .slice(0, 3)
        .map((i) => `${i.path.join(".")}：${i.message}`)
        .join("；")
    : error instanceof Error
      ? error.message
      : "操作失败，请重试";
}

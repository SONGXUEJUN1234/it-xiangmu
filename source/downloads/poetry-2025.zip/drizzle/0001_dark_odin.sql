CREATE TABLE `poems` (
	`id` int NOT NULL,
	`title` varchar(120) NOT NULL,
	`body` text NOT NULL,
	`form` enum('现代诗','古体诗') NOT NULL,
	`note` text NOT NULL,
	`interpretation` text,
	`interpretationUpdatedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `poems_id` PRIMARY KEY(`id`)
);

# Project Status (Snapshot)

更新时间：2026-02-13 11:35

## 当前结论

- 当前项目目录：`/home/erp17/expfood-mvp`
- 运行模式：`SQLite 持久化`
- 数据库文件：`/home/erp17/expfood-mvp/database/app.db`
- 浏览器入口：`http://localhost:8088`
- 中间版本备份：
  - `/home/erp17/backups/expfood-mvp-intermediate-20260212-230706.tar.gz`
  - `/home/erp17/backups/expfood-mvp-intermediate-20260212-230706.tar.gz.sha256`

## 已完成业务能力

- 买家/商家登录
- 买家注册（姓名必填、常用地址可选）
- 买家资料编辑（登录后可修改姓名、常用地址）
- 商家资料编辑（登录后可修改地址/营业时间/联系人，支持重算坐标）
- 商家营业状态（开店/打烊）与买家搜索联动
- 商家注册（店铺资料 + 资质图）
- 商品发布与管理（编辑、上下架、分页筛选）
  - 图片必填（至少 1 张）
  - 临期关键日期：`production_date`（生产日期）、`best_before_date`（保质到期日）
  - 详情字段：`detail_images`、`ingredients`、`allergen_info`、`pickup_start_time`、`pickup_end_time`
- 下单、支付、核销、取消、超时取消
- 退款闭环：
  - 未核销自动退款
  - 已核销商家确认退款
  - 已结算售后退款（商家确认）
- 购物车闭环：
  - 单商家限制
  - 购物车结算
  - 批量支付本次结算订单
- 买家结算记录（checkout batch）
- 商家订单结算（单笔 + 批量），新增状态 `6=已结算`
- 附近商家搜索增强：
  - 支持排序：`distance` / `discount` / `price`
  - 返回店铺营业时间、在售数量、主推商品摘要
- 买家地图展示改为系统自动读取 Key（不再要求用户手填）
- 商家对账：
  - 汇总（时间范围）
  - 明细（待核销/已核销/退款/已结算）
  - CSV 导出
- 结算统计口径切换：
  - `date_basis=created_at`（默认）
  - `date_basis=settled_at`（按结算时间统计）
- 买家/商家订单详情时间线（创建/支付/核销/取消/退款/结算）

## 工程化状态

- 配置分层：`src/config.js`
- 仓储拆分：
  - `src/repositories/userRepository.js`
  - `src/repositories/productRepository.js`
  - `src/repositories/orderRepository.js`
  - `src/repositories/cartRepository.js`
  - `src/repositories/createRepositories.js`
- 数据迁移兼容：`orders` 已包含支付、退款、结算、结算批次字段
- 测试：
  - `npm test`（仓储回归）
  - `npm run test:api`（API 集成）
- API 文档：
  - `public/openapi.json`
  - `public/api-docs.html`
- 鉴权生命周期：
  - access token 过期校验
  - refresh token 刷新轮换
  - logout 当前会话失效
- 部署固化：
  - `Dockerfile`
  - `docker-compose.yml`
  - `deploy/expfood-mvp.service`
- 前端配图资源：
  - `public/assets/product-bread-main.svg`
  - `public/assets/product-bread-angle.svg`
  - `public/assets/product-bread-detail.svg`
  - `public/assets/product-salad-main.svg`

## 下次继续建议

1. SQLite -> MySQL 迁移脚本与适配层

## 下次启动命令

```bash
cd /home/erp17/expfood-mvp
npm test
npm run test:api
npm run dev
```

const { createUserRepository } = require("./userRepository");
const { createProductRepository } = require("./productRepository");
const { createOrderRepository } = require("./orderRepository");
const { createCartRepository } = require("./cartRepository");

function createRepositories(deps) {
  const userRepo = createUserRepository(deps);
  const productRepo = createProductRepository(deps);
  const orderRepo = createOrderRepository({
    ...deps,
    productRepo,
    payTimeoutMs: deps.payTimeoutMs,
    pickupTimeoutMs: deps.pickupTimeoutMs,
  });
  const cartRepo = createCartRepository(deps);

  return { userRepo, productRepo, orderRepo, cartRepo };
}

module.exports = { createRepositories };

import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const poems = mysqlTable("poems", {
  id: int("id").primaryKey(),
  title: varchar("title", { length: 120 }).notNull(),
  body: text("body").notNull(),
  form: mysqlEnum("form", ["现代诗", "古体诗"]).notNull(),
  note: text("note").notNull(),
  interpretation: text("interpretation"),
  interpretationUpdatedAt: timestamp("interpretationUpdatedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Poem = typeof poems.$inferSelect;
export type InsertPoem = typeof poems.$inferInsert;

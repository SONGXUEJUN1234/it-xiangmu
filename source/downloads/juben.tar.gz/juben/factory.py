# factory.py (industrial stable)
# 一体化工业入口：生成 -> 强化 -> 评分 -> 选优 -> 打包发行
#
# 依赖：
#   panel_gen.py enhancer.py scorer.py juben_release.py
#
# 推荐用法：
#   python factory.py --genre all --count 5 --top 1
#   python factory.py --genre hardcore --count 5 --top 1 --pass 82
#   python factory.py --genre emotional --count 5 --top 1 --difficulty medium --tags "亲情,错过,牺牲,和解" --setting-hint "一场葬礼把六个人拉回彼此人生"
#
# 输出：
#   out/                 中间产物
#   pipeline_reports/     汇总报告
#   release_zips/         最终发行包zip（如启用打包）

import argparse
import json
import re
import subprocess
import time
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "out"
REPORT_DIR = ROOT / "pipeline_reports"

GENRES = ["hardcore", "mechanism", "emotional", "horror"]


def now_stamp() -> str:
    return time.strftime("%Y%m%d_%H%M%S")


def must_exist(p: Path, label: str) -> None:
    if not p.exists():
        raise FileNotFoundError(f"{label} not found: {p}")


def write_json(p: Path, obj: Any) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def run_cmd_live(args: List[str], timeout: int = 7200) -> int:
    """
    实时输出子进程日志，便于确认系统在运行。
    返回 returncode。
    """
    p = subprocess.Popen(
        args,
        cwd=str(ROOT),
        text=True,
        encoding="utf-8",
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )

    start = time.time()
    assert p.stdout is not None
    for line in p.stdout:
        print(line.rstrip())
        if timeout and (time.time() - start) > timeout:
            p.kill()
            return 124

    return p.wait()


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def find_latest_batch_files(genre: str, take: int) -> Tuple[List[Path], str]:
    """
    寻找某个genre最近一批生成文件：
    out/<genre>_out_YYYYMMDD_HHMMSS_01.json ...
    返回：这一批的文件列表 + batch_id(YYYYMMDD_HHMMSS)
    """
    files = sorted(OUT.glob(f"{genre}_out_????????_??????_??.json"))
    if not files:
        raise FileNotFoundError(f"找不到 {genre} 的批量生成文件，请先生成。")

    m = re.match(rf"{genre}_out_(\d{{8}}_\d{{6}})_\d{{2}}\.json", files[-1].name)
    if not m:
        return files[-take:], "unknown"

    batch_id = m.group(1)
    batch = sorted(OUT.glob(f"{genre}_out_{batch_id}_??.json"))
    if len(batch) >= take:
        return batch[:take], batch_id

    return files[-take:], batch_id


def newest_in_out(patterns: List[str]) -> Optional[Path]:
    cand: List[Path] = []
    for pat in patterns:
        cand += list(OUT.glob(pat))
    cand = [c for c in cand if c.exists()]
    if not cand:
        return None
    cand.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return cand[0]


def genre_pass_threshold(genre: str, base: int) -> int:
    """
    按类型动态通过线，避免某些类型被硬核门槛压死。
    你也可以后续按你的市场标准调整这几条。
    """
    base = int(base)
    if genre == "hardcore":
        t = base
    elif genre == "mechanism":
        t = base - 2
    elif genre == "horror":
        t = base - 3
    elif genre == "emotional":
        t = base - 4
    else:
        t = base
    if t < 70:
        t = 70
    if t > 95:
        t = 95
    return t


def step_generate(panel_gen: Path, genre: str, count: int, player_count: int,
                  duration: str, difficulty: str, tags: str, setting_hint: str,
                  retries: int, timeout: int) -> Tuple[List[Path], str]:
    args = [
        "python", str(panel_gen),
        "--genre", genre,
        "--count", str(count),
        "--player-count", str(player_count),
        "--difficulty", difficulty,
        "--retries", str(retries),
        "--timeout", str(timeout),
    ]
    if duration:
        args += ["--duration", duration]
    if tags:
        args += ["--tags", tags]
    if setting_hint:
        args += ["--setting-hint", setting_hint]

    rc = run_cmd_live(args, timeout=timeout + 600)
    if rc != 0:
        raise RuntimeError(f"生成失败，returncode={rc}")

    batch_files, batch_id = find_latest_batch_files(genre, count)
    return batch_files, batch_id


def step_enhance(enhancer: Path, src_json: Path, timeout: int) -> Path:
    rc = run_cmd_live(["python", str(enhancer), str(src_json)], timeout=timeout)
    if rc != 0:
        raise RuntimeError(f"强化失败，returncode={rc}")

    plus_same = OUT / f"{src_json.stem}_plus.json"
    if plus_same.exists():
        return plus_same

    alt = newest_in_out(["*_out_plus.json", "*_plus.json"])
    if alt:
        return alt

    raise FileNotFoundError("强化输出未找到（_plus.json）。")


def step_score(scorer: Path, plus_json: Path, pass_threshold: int, timeout: int) -> Tuple[Path, Dict[str, Any]]:
    rc = run_cmd_live(
        ["python", str(scorer), str(plus_json), "--pass", str(pass_threshold)],
        timeout=timeout,
    )
    if rc != 0:
        raise RuntimeError(f"评分失败，returncode={rc}")

    score_path = OUT / f"{plus_json.stem}_score.json"
    if score_path.exists():
        return score_path, load_json(score_path)

    alt = newest_in_out(["*_score.json", "*_out_plus_score.json"])
    if alt:
        return alt, load_json(alt)

    raise FileNotFoundError("评分输出未找到（_score.json）。")


def step_pack(releaser: Path, plus_json: Path, timeout: int) -> Optional[str]:
    p = subprocess.run(
        ["python", str(releaser), "pack", str(plus_json)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
        encoding="utf-8",
        timeout=timeout,
    )
    if p.returncode != 0:
        msg = (p.stderr or p.stdout or "").strip()
        raise RuntimeError(f"打包失败：{msg[:400]}")

    zip_path = None
    for line in (p.stdout or "").splitlines():
        if "发行包已生成" in line:
            parts = line.split("：", 1)
            zip_path = parts[-1].strip() if parts else None
    return zip_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--genre", default="hardcore", help="hardcore/mechanism/emotional/horror/all")
    ap.add_argument("--count", type=int, default=5, help="每个类型生成数量，默认5")
    ap.add_argument("--top", type=int, default=1, help="每个类型保留并打包的Top数量，默认1")
    ap.add_argument("--pass", dest="base_pass", type=int, default=80, help="基础通过线，系统会按类型做微调")
    ap.add_argument("--no-pack", action="store_true", help="只选优不打包")
    ap.add_argument("--player-count", type=int, default=6)
    ap.add_argument("--duration", default="")
    ap.add_argument("--difficulty", default="hard")
    ap.add_argument("--tags", default="")
    ap.add_argument("--setting-hint", default="")
    ap.add_argument("--retries", type=int, default=3)
    ap.add_argument("--timeout", type=int, default=3600)
    args = ap.parse_args()

    panel_gen = ROOT / "panel_gen.py"
    enhancer = ROOT / "enhancer.py"
    scorer = ROOT / "scorer.py"
    releaser = ROOT / "juben_release.py"

    must_exist(panel_gen, "panel_gen.py")
    must_exist(enhancer, "enhancer.py")
    must_exist(scorer, "scorer.py")
    must_exist(releaser, "juben_release.py")

    OUT.mkdir(exist_ok=True)
    REPORT_DIR.mkdir(exist_ok=True)

    genres = GENRES if args.genre == "all" else [args.genre]
    for g in genres:
        if g not in GENRES:
            raise ValueError(f"unknown genre: {g}")

    run_id = now_stamp()
    report: Dict[str, Any] = {
        "run_id": run_id,
        "genres": genres,
        "count_per_genre": args.count,
        "top_per_genre": args.top,
        "base_pass": args.base_pass,
        "no_pack": args.no_pack,
        "items": [],
        "winners": [],
    }

    for genre in genres:
        pass_line = genre_pass_threshold(genre, args.base_pass)
        print(f"\n=== 产线 {genre}：生成 {args.count} 部 | 通过线 {pass_line} ===")

        batch_files, batch_id = step_generate(
            panel_gen=panel_gen,
            genre=genre,
            count=args.count,
            player_count=args.player_count,
            duration=args.duration,
            difficulty=args.difficulty,
            tags=args.tags,
            setting_hint=args.setting_hint,
            retries=args.retries,
            timeout=args.timeout,
        )

        print(f"批次ID：{batch_id}")
        print(f"批次数量：{len(batch_files)}")

        ranking: List[Dict[str, Any]] = []

        for i, src in enumerate(batch_files, 1):
            item: Dict[str, Any] = {
                "genre": genre,
                "batch_id": batch_id,
                "index": i,
                "pass_line": pass_line,
                "source": str(src),
                "enhanced": None,
                "score_file": None,
                "scores": None,
                "final_score": 0,
                "pass": False,
                "zip": None,
                "status": "START",
                "error": None,
            }

            try:
                print(f"\n[{genre} {i}/{len(batch_files)}] 强化：{src.name}")
                plus = step_enhance(enhancer, src, timeout=args.timeout)
                item["enhanced"] = str(plus)

                print(f"[{genre} {i}/{len(batch_files)}] 评分：{plus.name}")
                score_path, score_obj = step_score(scorer, plus, pass_threshold=pass_line, timeout=args.timeout)
                item["score_file"] = str(score_path)
                item["scores"] = score_obj
                item["final_score"] = int(score_obj.get("final_score", 0))
                item["pass"] = bool(score_obj.get("pass", False))
                item["status"] = "SCORED"

                print(f"[{genre} {i}/{len(batch_files)}] 得分：{item['final_score']} 通过：{item['pass']}")

                ranking.append(item)
                report["items"].append(item)

            except Exception as e:
                item["status"] = "FAIL"
                item["error"] = str(e)
                report["items"].append(item)
                print(f"[{genre} {i}/{len(batch_files)}] 失败：{e}")

        ranking.sort(key=lambda x: x["final_score"], reverse=True)

        winners: List[Dict[str, Any]] = []
        for cand in ranking[: max(args.top, 1)]:
            if not cand.get("pass"):
                continue
            if int(cand.get("final_score", 0)) < pass_line:
                continue
            winners.append(cand)

        print(f"\n=== 产线 {genre}：候选 {len(ranking)}，达标入选 {len(winners)} ===")

        for w in winners:
            if args.no_pack:
                report["winners"].append(w)
                continue

            try:
                print(f"打包：{Path(w['enhanced']).name}")
                zip_path = step_pack(releaser, Path(w["enhanced"]), timeout=args.timeout)
                w["zip"] = zip_path
                w["status"] = "PACKED"
                report["winners"].append(w)
                print(f"已打包：{zip_path}")
            except Exception as e:
                w["status"] = "PACK_FAIL"
                w["error"] = str(e)
                report["winners"].append(w)
                print(f"打包失败：{e}")

        rank_path = OUT / f"{genre}_rank_{run_id}_{batch_id}.json"
        write_json(rank_path, {"genre": genre, "run_id": run_id, "batch_id": batch_id, "pass_line": pass_line, "ranking": ranking})
        print(f"榜单已写入：{rank_path}")

    report_path = REPORT_DIR / f"factory_report_{run_id}.json"
    write_json(report_path, report)

    print("\n=== 本次工厂运行完成 ===")
    print("报告：", report_path)
    print("入选：", len(report.get("winners", [])))
    if not args.no_pack:
        packed = [x for x in report.get("winners", []) if x.get("zip")]
        print("已打包：", len(packed))


if __name__ == "__main__":
    main()
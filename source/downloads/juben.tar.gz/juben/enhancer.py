import json
import subprocess
import pathlib
import sys

def _extract_first_json(text: str) -> str:
    text = (text or "").strip()
    start = text.find("{")
    if start == -1:
        raise ValueError("No JSON start")
    stack = []
    in_str = False
    esc = False

    for i in range(start, len(text)):
        ch = text[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        else:
            if ch == '"':
                in_str = True
                continue
            if ch == "{":
                stack.append("{")
            elif ch == "}":
                stack.pop()
                if not stack:
                    return text[start:i+1]

    raise ValueError("JSON incomplete")

def validate_json(text):
    try:
        return json.loads(text)
    except:
        try:
            snippet = _extract_first_json(text)
            return json.loads(snippet)
        except:
            return None

def run_claude(prompt: str):
    return subprocess.run(
        ["cmd", "/c", "claude"],
        input=prompt,
        text=True,
        capture_output=True,
        encoding="utf-8"
    )

def main():
    if len(sys.argv) < 2:
        print("Usage: python enhancer.py path_to_json")
        sys.exit(1)

    input_path = pathlib.Path(sys.argv[1])
    if not input_path.exists():
        print("File not found.")
        sys.exit(1)

    original = input_path.read_text(encoding="utf-8")

    prompt = f"""
你是顶级剧本杀逻辑强化专家。
请在不改变JSON结构、不新增字段、不删除字段的前提下，
强化以下剧本的逻辑强度。

强化目标：
1 提升时间诡计复杂度，使至少两条线索组合才能锁定凶手。
2 减少“直接暴露”证据。
3 增强误导线索合理性。
4 强化 hidden_twist 的戏剧反转感。
5 保持字段结构完全一致。

只允许输出合法JSON。

原始JSON如下：
{original}
"""

    print("正在强化...")

    for attempt in range(3):
        p = run_claude(prompt)
        parsed = validate_json(p.stdout)

        if parsed:
            out_path = input_path.parent / (input_path.stem + "_plus.json")
            out_path.write_text(json.dumps(parsed, ensure_ascii=False, indent=2), encoding="utf-8")
            print("强化成功:", out_path)
            return

        print("强化输出异常，重试中...")

    print("强化失败。")

if __name__ == "__main__":
    main()
import json
import pathlib
import sys
import re

PAGE_BREAK = "\n" + "=" * 60 + "\n\n"

def safe_filename(name: str) -> str:
    name = (name or "").strip()
    name = re.sub(r'[\\/:*?"<>|]+', "_", name)
    return name[:80] if name else "untitled"

def read_json(path: pathlib.Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))

def write_text(path: pathlib.Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content.strip() + "\n", encoding="utf-8")

def build_export_dir(data: dict) -> pathlib.Path:
    title = safe_filename(data.get("meta", {}).get("title", "script"))
    genre = safe_filename(data.get("meta", {}).get("genre", "unknown"))
    out_dir = pathlib.Path("export") / f"{title}_{genre}"
    out_dir.mkdir(parents=True, exist_ok=True)
    return out_dir

def clue_number_key(c):
    cid = c.get("id", "")
    num = "".join([x for x in cid if x.isdigit()])
    try:
        return int(num)
    except Exception:
        return 0

def header_block(data: dict) -> str:
    meta = data.get("meta", {}) or {}
    tags = meta.get("tags", []) or []
    return (
        f"标题：{meta.get('title','')}\n"
        f"类型：{meta.get('genre','')}\n"
        f"人数：{meta.get('player_count','')}\n"
        f"时长：{meta.get('duration','')}\n"
        f"难度：{meta.get('difficulty','')}\n"
        + (f"标签：{', '.join(tags)}\n" if tags else "")
    )

# -----------------------------
# 主持人本 普通版 + 打印版
# -----------------------------
def export_host_books(data: dict, out_dir: pathlib.Path) -> None:
    meta = data.get("meta", {}) or {}
    hs = data.get("host_script", {}) or {}
    structure = data.get("structure", {}) or {}
    rounds = structure.get("rounds", []) or []

    # 普通版
    lines = []
    lines.append(header_block(data).strip())
    lines.append("")
    lines.append("【开场】")
    lines.append(hs.get("opening", ""))
    if rounds:
        lines.append("")
        lines.append("【回合结构】")
        for i, r in enumerate(rounds, 1):
            theme = r.get("theme", "") or f"第{i}回合"
            lines.append(f"\n第{i}回合：{theme}")
            if r.get("unlock_condition"):
                lines.append(f"触发条件：{r.get('unlock_condition')}")
            if r.get("script_event"):
                lines.append(f"剧情事件：{r.get('script_event')}")
            if r.get("actions"):
                lines.append(f"行动：{r.get('actions')}")
    rg = hs.get("round_guidance", []) or []
    if rg:
        lines.append("")
        lines.append("【回合引导】")
        for i, g in enumerate(rg, 1):
            lines.append(f"\n第{i}轮引导：")
            lines.append(str(g))
    lines.append("")
    lines.append("【结尾】")
    lines.append(hs.get("ending", ""))

    write_text(out_dir / "主持人本.txt", "\n".join(lines))

    # 打印版：分页
    content = header_block(data) + PAGE_BREAK
    content += "【开场】\n" + hs.get("opening", "") + PAGE_BREAK

    if rounds:
        for i, r in enumerate(rounds, 1):
            theme = r.get("theme", "") or f"第{i}回合"
            content += f"【第{i}回合】{theme}\n"
            if r.get("unlock_condition"):
                content += f"触发条件：{r.get('unlock_condition')}\n"
            if r.get("script_event"):
                content += f"剧情事件：{r.get('script_event')}\n"
            if r.get("actions"):
                content += f"行动：{r.get('actions')}\n"
            content += PAGE_BREAK
    else:
        content += "【回合结构】\n未提供 structure.rounds。\n" + PAGE_BREAK

    if rg:
        content += "【回合引导】\n"
        for i, g in enumerate(rg, 1):
            content += f"\n第{i}轮引导：\n{g}\n"
        content += PAGE_BREAK

    content += "【结尾】\n" + hs.get("ending", "")
    write_text(out_dir / "主持人本_打印版.txt", content)

# -----------------------------
# 角色本 普通版 + 打印版
# -----------------------------
def export_character_books(data: dict, out_dir: pathlib.Path) -> None:
    chars = data.get("characters", []) or []
    char_dir = out_dir / "角色本"
    char_print_dir = out_dir / "角色本_打印版"
    char_dir.mkdir(exist_ok=True)
    char_print_dir.mkdir(exist_ok=True)

    for c in chars:
        name = c.get("name", "角色")
        fname = safe_filename(name)

        # 普通版
        lines = []
        lines.append(f"角色：{name}")
        lines.append("")
        lines.append("公开背景：")
        lines.append(c.get("public_background", ""))
        lines.append("")
        lines.append("你的秘密：")
        lines.append(c.get("secret", ""))
        lines.append("")
        lines.append("你的目标：")
        lines.append(c.get("goal", ""))

        rm = c.get("relationship_map", {}) or {}
        if rm:
            lines.append("")
            lines.append("关系：")
            for k, v in rm.items():
                lines.append(f"{k}：{v}")

        ke = c.get("key_evidence", []) or []
        if ke:
            lines.append("")
            lines.append("你掌握的关键物件或信息：")
            for item in ke:
                lines.append(f"- {item}")

        write_text(char_dir / f"{fname}.txt", "\n".join(lines))

        # 打印版：分页，结构更适合装订
        p = header_block(data) + PAGE_BREAK
        p += f"【角色】{name}\n" + PAGE_BREAK
        p += "【公开背景】\n" + c.get("public_background", "") + PAGE_BREAK
        p += "【你的秘密】\n" + c.get("secret", "") + PAGE_BREAK
        p += "【你的目标】\n" + c.get("goal", "") + PAGE_BREAK

        if rm:
            rel = "【关系】\n" + "\n".join([f"{k}：{v}" for k, v in rm.items()])
            p += rel + PAGE_BREAK

        if ke:
            kev = "【你掌握的关键物件或信息】\n" + "\n".join([f"- {x}" for x in ke])
            p += kev + PAGE_BREAK

        write_text(char_print_dir / f"{fname}_打印版.txt", p)

# -----------------------------
# 线索卡 双模式 + 打印版
# -----------------------------
def export_clue_cards(data: dict, out_dir: pathlib.Path, mode: str) -> None:
    clues = data.get("clues", []) or []
    clue_dir = out_dir / "线索卡"
    clue_dir.mkdir(exist_ok=True)

    def clue_page(clue, round_prefix: str = "") -> str:
        s = ""
        if round_prefix:
            s += round_prefix + "\n"
        s += f"线索编号：{clue.get('id','')}\n"
        s += f"类型：{clue.get('type','')}\n"
        s += f"出现回合：{clue.get('appear_round','')}\n"
        s += f"强度：{clue.get('strength','')}\n"
        s += f"误导：{clue.get('misleading', False)}\n\n"
        s += "内容：\n"
        s += f"{clue.get('content','')}\n"
        return s

    if mode == "number":
        clues_sorted = sorted(clues, key=clue_number_key)
        content = ""
        for clue in clues_sorted:
            content += clue_page(clue) + PAGE_BREAK
        write_text(clue_dir / "线索卡_按编号排序_打印版.txt", content)
        return

    if mode == "round":
        grouped = {}
        for c in clues:
            r = c.get("appear_round", 1)
            try:
                r = int(r)
            except Exception:
                r = 1
            grouped.setdefault(r, []).append(c)

        content = ""
        for r in sorted(grouped.keys()):
            round_clues = sorted(grouped[r], key=clue_number_key)
            for clue in round_clues:
                content += clue_page(clue, round_prefix=f"第{r}回合线索") + PAGE_BREAK

        write_text(clue_dir / "线索卡_按回合排序_打印版.txt", content)
        return

    raise ValueError("mode must be 'number' or 'round'")

# -----------------------------
# 复盘手册 普通版 + 打印版（类型自适应）
# -----------------------------
def export_review_books(data: dict, out_dir: pathlib.Path) -> None:
    meta = data.get("meta", {}) or {}
    tc = data.get("truth_core", {}) or {}
    genre = meta.get("genre", "")
    structure = data.get("structure", {}) or {}
    mech = structure.get("mechanics", "")
    phase_design = structure.get("phase_design", "")

    # 普通版
    lines = []
    lines.append(header_block(data).strip())
    lines.append("")
    lines.append("【真相核心】")
    if tc.get("real_story"):
        lines.append("真实故事：")
        lines.append(tc.get("real_story", ""))
        lines.append("")
    if tc.get("killer"):
        lines.append(f"关键人物：{tc.get('killer')}")
    if tc.get("crime_method"):
        lines.append("")
        lines.append("关键手法：")
        lines.append(tc.get("crime_method", ""))
    if tc.get("motive_structure"):
        lines.append("")
        lines.append("动机结构：")
        lines.append(tc.get("motive_structure", ""))
    if tc.get("hidden_twist"):
        lines.append("")
        lines.append("隐藏反转：")
        lines.append(tc.get("hidden_twist", ""))

    tl = tc.get("timeline", []) or []
    if tl:
        lines.append("")
        lines.append("【时间线】")
        for t in tl:
            lines.append(str(t))

    # 类型差异化
    if genre == "mechanism":
        lines.append("")
        lines.append("【阵营机制与结算】")
        if isinstance(mech, dict):
            lines.append(json.dumps(mech, ensure_ascii=False, indent=2))
        else:
            lines.append(str(mech))
    elif genre == "emotional":
        lines.append("")
        lines.append("【情绪曲线与爆点】")
        if isinstance(phase_design, dict):
            lines.append(json.dumps(phase_design, ensure_ascii=False, indent=2))
        else:
            lines.append(str(phase_design))
    elif genre == "horror":
        lines.append("")
        lines.append("【恐怖还原说明】")
        lines.append("建议复盘顺序：先怪谈总述，再证据解释，最后现实原因与动机揭示。")

    write_text(out_dir / "复盘手册.txt", "\n".join(lines))

    # 打印版：分页
    p = header_block(data) + PAGE_BREAK
    p += "【真相核心】\n"
    if tc.get("real_story"):
        p += "真实故事：\n" + tc.get("real_story", "") + PAGE_BREAK
    if tc.get("killer"):
        p += f"关键人物：{tc.get('killer')}\n" + PAGE_BREAK
    if tc.get("crime_method"):
        p += "关键手法：\n" + tc.get("crime_method", "") + PAGE_BREAK
    if tc.get("motive_structure"):
        p += "动机结构：\n" + tc.get("motive_structure", "") + PAGE_BREAK
    if tc.get("hidden_twist"):
        p += "隐藏反转：\n" + tc.get("hidden_twist", "") + PAGE_BREAK

    if tl:
        p += "【时间线】\n" + "\n".join([str(x) for x in tl]) + PAGE_BREAK

    if genre == "mechanism":
        p += "【阵营机制与结算】\n"
        p += (json.dumps(mech, ensure_ascii=False, indent=2) if isinstance(mech, dict) else str(mech)) + PAGE_BREAK
    elif genre == "emotional":
        p += "【情绪曲线与爆点】\n"
        p += (json.dumps(phase_design, ensure_ascii=False, indent=2) if isinstance(phase_design, dict) else str(phase_design)) + PAGE_BREAK
    elif genre == "horror":
        p += "【恐怖还原说明】\n建议复盘顺序：先怪谈总述，再证据解释，最后现实原因与动机揭示。\n" + PAGE_BREAK

    write_text(out_dir / "复盘手册_打印版.txt", p)

# -----------------------------
# 导出总入口
# -----------------------------
def export_all(json_path: str) -> pathlib.Path:
    data = read_json(pathlib.Path(json_path))
    out_dir = build_export_dir(data)

    export_host_books(data, out_dir)
    export_character_books(data, out_dir)

    # 两种线索模式都输出
    export_clue_cards(data, out_dir, mode="number")
    export_clue_cards(data, out_dir, mode="round")

    export_review_books(data, out_dir)
    return out_dir

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python readable_universal_v3_1.py path_to_json")
        sys.exit(1)

    out_dir = export_all(sys.argv[1])
    print("导出完成：", out_dir)
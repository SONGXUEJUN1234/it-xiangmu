function createUserRepository({ users, seq, persistUser }) {
  return {
    findByPhoneRole(phone, role) {
      return users.find((u) => u.phone === phone && u.role === role) || null;
    },
    findByID(id) {
      return users.find((u) => u.id === id) || null;
    },
    async create({ phone, role, nickname, shopID }) {
      const user = {
        id: ++seq.user,
        phone,
        role,
        nickname,
        full_name: "",
        buyer_address: "",
        shop_id: shopID || null,
      };
      users.push(user);
      await persistUser(user);
      return user;
    },
  };
}

module.exports = { createUserRepository };

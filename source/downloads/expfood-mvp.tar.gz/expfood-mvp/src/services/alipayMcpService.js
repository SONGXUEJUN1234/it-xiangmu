function withTimeout(ms) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  return { controller, timer };
}

function normalizeBaseUrl(url) {
  return String(url || "").trim().replace(/\/+$/, "");
}

function buildMockTradeNo(prefix) {
  return `${prefix}${Date.now()}${String(Math.floor(Math.random() * 10000)).padStart(4, "0")}`;
}

function extractQrUrl(data) {
  if (!data || typeof data !== "object") return "";
  const candidate =
    data.qr_url ||
    data.qrcode_url ||
    data.qrCodeUrl ||
    data.code_url ||
    data.payment_url ||
    data.pay_url ||
    data.checkout_url ||
    "";
  return String(candidate || "").trim();
}

function createAlipayMcpService(config) {
  const enabled = Boolean(config && config.enabled);
  const mode = String((config && config.mode) || "mock").trim().toLowerCase() === "live" ? "live" : "mock";
  const baseUrl = normalizeBaseUrl(config && config.baseUrl);
  const apiKey = String((config && config.apiKey) || "").trim();
  const timeoutMs = Math.max(500, Number((config && config.timeoutMs) || 6000));
  const retryMax = Math.max(0, Math.min(2, Number((config && config.retryMax) || 1)));
  function getConfigCheck() {
    const missingFields = [];
    if (!baseUrl) missingFields.push("ALIPAY_MCP_BASE_URL");
    if (!apiKey) missingFields.push("ALIPAY_MCP_API_KEY");
    const isLive = mode === "live";
    const liveReady = !isLive || missingFields.length === 0;
    return {
      enabled,
      mode,
      has_base_url: Boolean(baseUrl),
      has_api_key: Boolean(apiKey),
      timeout_ms: timeoutMs,
      retry_max: retryMax,
      live_ready: liveReady,
      missing_fields: missingFields,
    };
  }

  function isTransientError(result) {
    if (!result || result.ok) return false;
    if (result.error_code === "ALIPAY_MCP_TIMEOUT" || result.error_code === "ALIPAY_MCP_NETWORK_ERROR") return true;
    const status = Number(result.http_status || 0);
    return status >= 500 && status <= 599;
  }

  async function postJson(path, payload, options = {}) {
    if (!baseUrl) {
      return { ok: false, error_code: "ALIPAY_MCP_BASE_URL_MISSING", message: "alipay mcp base url missing" };
    }
    if (!apiKey) {
      return { ok: false, error_code: "ALIPAY_MCP_API_KEY_MISSING", message: "alipay mcp api key missing" };
    }

    let attempt = 0;
    let lastResult = null;
    while (attempt <= retryMax) {
      const { controller, timer } = withTimeout(timeoutMs);
      try {
        const res = await fetch(`${baseUrl}${path}`, {
          method: "POST",
          signal: controller.signal,
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${apiKey}`,
            ...(options.idempotencyKey ? { "Idempotency-Key": String(options.idempotencyKey) } : {}),
          },
          body: JSON.stringify(payload),
        });

        const text = await res.text();
        let data = null;
        try {
          data = text ? JSON.parse(text) : null;
        } catch (_err) {
          return {
            ok: false,
            error_code: "ALIPAY_MCP_INVALID_JSON",
            message: "alipay mcp invalid json response",
            detail: text,
          };
        }

        if (!res.ok) {
          lastResult = {
            ok: false,
            error_code: "ALIPAY_MCP_HTTP_ERROR",
            message: (data && (data.message || data.error || data.error_message)) || `alipay mcp http ${res.status}`,
            http_status: res.status,
            detail: data,
          };
        } else {
          return { ok: true, data };
        }
      } catch (err) {
        const aborted = err && err.name === "AbortError";
        lastResult = {
          ok: false,
          error_code: aborted ? "ALIPAY_MCP_TIMEOUT" : "ALIPAY_MCP_NETWORK_ERROR",
          message: aborted ? "alipay mcp request timeout" : String((err && err.message) || err || "unknown"),
        };
      } finally {
        clearTimeout(timer);
      }
      if (!isTransientError(lastResult) || attempt >= retryMax) return lastResult;
      attempt += 1;
    }
    return lastResult || { ok: false, error_code: "ALIPAY_MCP_UNKNOWN", message: "unknown error" };
  }

  async function collectBuyerPayment({ order, buyer, idempotencyKey, requireQr = false }) {
    if (!enabled || mode === "mock") {
      const tradeNo = buildMockTradeNo("ALP");
      return {
        ok: true,
        channel: "alipay_mcp",
        trade_no: tradeNo,
        mode: "mock",
        qr_url: `alipay://mock/pay?trade_no=${encodeURIComponent(tradeNo)}&order_no=${encodeURIComponent(String(order.order_no || ""))}`,
      };
    }

    const res = await postJson("/payments/collect", {
      channel: "alipay",
      biz_order_no: String(order.order_no || ""),
      amount: Number(order.total_amount || 0),
      currency: "CNY",
      subject: `ExpFood订单 ${order.order_no}`,
      buyer: {
        id: Number(buyer.id),
        phone: String(buyer.phone || ""),
      },
    }, { idempotencyKey });
    if (!res.ok) return res;

    const data = res.data || {};
    const qrUrl = extractQrUrl(data);
    const tradeNo = String(data.trade_no || data.payment_no || data.transaction_id || "").trim();
    if (!tradeNo && !(requireQr && qrUrl)) {
      return {
        ok: false,
        error_code: "ALIPAY_MCP_COLLECT_INVALID",
        message: "collect payment success but trade_no missing",
        detail: data,
      };
    }

    return {
      ok: true,
      channel: "alipay_mcp",
      trade_no: tradeNo,
      mode: "live",
      qr_url: qrUrl,
      raw: data,
    };
  }

  async function transferToMerchant({ order, merchant, idempotencyKey, requireQr = false }) {
    if (!enabled || mode === "mock") {
      const tradeNo = buildMockTradeNo("ALS");
      return {
        ok: true,
        channel: "alipay_mcp",
        trade_no: tradeNo,
        mode: "mock",
        qr_url: `alipay://mock/collect?trade_no=${encodeURIComponent(tradeNo)}&order_no=${encodeURIComponent(String(order.order_no || ""))}`,
      };
    }

    const payeeAccount = String(merchant.alipay_account || merchant.contact_phone || merchant.phone || "").trim();
    if (!payeeAccount) {
      return {
        ok: false,
        error_code: "ALIPAY_MCP_PAYEE_MISSING",
        message: "merchant payee account missing",
      };
    }

    const res = await postJson("/payments/transfer", {
      channel: "alipay",
      biz_order_no: String(order.order_no || ""),
      amount: Number(order.total_amount || 0),
      currency: "CNY",
      payee: {
        account: payeeAccount,
        account_type: "phone",
        merchant_id: Number(merchant.id || 0),
      },
      remark: `ExpFood结算 ${order.order_no}`,
    }, { idempotencyKey });
    if (!res.ok) return res;

    const data = res.data || {};
    const qrUrl = extractQrUrl(data);
    const tradeNo = String(data.trade_no || data.settle_no || data.transaction_id || "").trim();
    if (!tradeNo && !(requireQr && qrUrl)) {
      return {
        ok: false,
        error_code: "ALIPAY_MCP_TRANSFER_INVALID",
        message: "transfer success but trade_no missing",
        detail: data,
      };
    }

    return {
      ok: true,
      channel: "alipay_mcp",
      trade_no: tradeNo,
      mode: "live",
      qr_url: qrUrl,
      raw: data,
    };
  }

  async function refundBuyerPayment({ order, buyer, merchant, reason, idempotencyKey }) {
    if (!enabled || mode === "mock") {
      return {
        ok: true,
        channel: "alipay_mcp",
        trade_no: buildMockTradeNo("ALR"),
        mode: "mock",
      };
    }

    const res = await postJson(
      "/payments/refund",
      {
        channel: "alipay",
        biz_order_no: String(order.order_no || ""),
        payment_no: String(order.payment_no || "").trim(),
        amount: Number(order.total_amount || 0),
        currency: "CNY",
        reason: String(reason || "订单退款"),
        buyer: {
          id: Number((buyer && buyer.id) || 0),
          phone: String((buyer && buyer.phone) || ""),
        },
        merchant: {
          id: Number((merchant && merchant.id) || 0),
          phone: String((merchant && merchant.phone) || ""),
        },
      },
      { idempotencyKey }
    );
    if (!res.ok) return res;

    const data = res.data || {};
    const tradeNo = String(data.trade_no || data.refund_no || data.transaction_id || "").trim();
    if (!tradeNo) {
      return {
        ok: false,
        error_code: "ALIPAY_MCP_REFUND_INVALID",
        message: "refund success but trade_no missing",
        detail: data,
      };
    }

    return {
      ok: true,
      channel: "alipay_mcp",
      trade_no: tradeNo,
      mode: "live",
      raw: data,
    };
  }

  function getPublicConfig() {
    return getConfigCheck();
  }

  return {
    collectBuyerPayment,
    transferToMerchant,
    refundBuyerPayment,
    getPublicConfig,
    getConfigCheck,
  };
}

module.exports = { createAlipayMcpService };

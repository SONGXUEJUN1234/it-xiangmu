import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  X,
  ArrowUpRight,
  ShoppingBag,
  MapPin,
  Info,
  Flag,
  ChevronDown,
  ExternalLink,
  Download,
  Upload,
  Save,
  RotateCcw,
} from "lucide-react";
import { BrandImage } from "./Art";
import {
  CATEGORIES,
  CORRECTION_KEY,
  REGISTRY_URL,
  downloadFile,
  errorMessage,
  exportCsv,
  importCsv,
  validateBrands,
  type Brand,
  type Correction,
  type Region,
} from "./model";

export function Modal({
  title,
  onClose,
  children,
  className = "",
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  className?: string;
}) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const dialog = dialogRef.current!;
    dialog.showModal();
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      dialog.close();
      document.body.style.overflow = oldOverflow;
      previous?.focus();
    };
  }, []);
  return (
    <dialog
      ref={dialogRef}
      className={`modal ${className}`}
      aria-label={title}
      onCancel={(e) => {
        e.preventDefault();
        onClose();
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="modal-inner">
        <button
          className="close-button"
          aria-label="关闭弹窗"
          onClick={onClose}
        >
          <X size={20} />
        </button>
        {children}
      </div>
    </dialog>
  );
}

export function BrandDetail({
  brand,
  onClose,
  onLocate,
  onCorrection,
}: {
  brand: Brand;
  onClose: () => void;
  onLocate: () => void;
  onCorrection: (brand: Brand) => void;
}) {
  return (
    <Modal
      title={`${brand.name}品牌详情`}
      onClose={onClose}
      className="brand-modal"
    >
      <BrandImage brand={brand} />
      <div className="detail-body">
        <div className="eyebrow">地方风物 · 老字号档案</div>
        <div className="detail-title">
          <h2>{brand.name}</h2>
          <span className="detail-seal">
            传承
            <br />
            有迹
          </span>
        </div>
        <p className="detail-location">
          <MapPin size={14} />
          {brand.city === brand.province
            ? brand.province
            : `${brand.province} · ${brand.city}`}{" "}
          <span>品牌归属地</span>
        </p>
        <div className="tags">
          {brand.categories.map((c) => (
            <span key={c}>{CATEGORIES.find((cat) => cat.id === c)?.label}</span>
          ))}
        </div>
        <p className="detail-description">{brand.description}</p>
        <div className="specialty-box">
          <span>招牌与特色</span>
          <p>{brand.specialties.join(" / ") || "资料整理中"}</p>
        </div>
        {brand.categories.includes("medicine") && (
          <p className="notice medicine-notice">
            <Info size={15} />{" "}
            仅介绍品牌，不提供诊疗或用药建议。购药请遵医嘱，并核对商家资质与购买要求。
          </p>
        )}
        <section className="shopping-section">
          <h3>
            <ShoppingBag size={17} /> 把喜欢的带回家
          </h3>
          {brand.shop ? (
            <>
              <a
                className="shop-link"
                href={brand.shop.url}
                target="_blank"
                rel="noopener noreferrer"
              >
                <span>
                  <strong>{brand.shop.label}</strong>
                  <small>
                    {brand.shop.verification === "platform"
                      ? `店铺页自证 · ${brand.checkedAt} 平台核验`
                      : `品牌来源指向 · ${brand.checkedAt} 核验`}
                  </small>
                </span>
                <ArrowUpRight size={21} />
              </a>
              <p className="muted small">
                {brand.shop.verification === "platform"
                  ? "已核对店铺页品牌标识，主体授权未逐一复核；请以店铺资质为准。"
                  : ""}{" "}
                在第三方平台完成交易，可能需要登录。价格、库存、配送及售后以店铺为准。
              </p>
            </>
          ) : (
            <div className="no-shop">
              <ShoppingBag size={20} />
              <span>
                暂未核实网购渠道
                <small>保留品牌资料，不推荐来源不明的店铺。</small>
              </span>
            </div>
          )}
          <div className="detail-actions">
            {brand.website && (
              <a href={brand.website} target="_blank" rel="noopener noreferrer">
                <ExternalLink size={14} /> 品牌官网（非购买入口）
              </a>
            )}
            <button onClick={onLocate}>
              <MapPin size={14} /> 在地图上查看归属地
            </button>
          </div>
        </section>
        <details className="source-details">
          <summary>
            资料来源与核验说明 <ChevronDown size={15} />
          </summary>
          <p>{brand.recognitionEvidence}</p>
          <p>
            资料整理日期：{brand.checkedAt}
            。历史认定资料不等于已完成最新一轮复核，请以商务部最新公告为准。
          </p>
          <ul>
            {brand.sources.map((source, index) => (
              <li key={`${source.url}${index}`}>
                <a href={source.url} target="_blank" rel="noopener noreferrer">
                  {source.title}
                  <ArrowUpRight size={12} />
                </a>
              </li>
            ))}
          </ul>
          {brand.shop && (
            <a
              href={brand.shop.evidenceUrl}
              target="_blank"
              rel="noopener noreferrer"
            >
              查看网购渠道依据 <ArrowUpRight size={12} />
            </a>
          )}
          {brand.image ? (
            <p>
              图片许可：{brand.image.license} ·{" "}
              <a
                href={brand.image.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
              >
                图片来源
              </a>
            </p>
          ) : (
            <p>
              当前图片为本项目原创品类插画，不是品牌产品或门店实拍；待获得授权后替换。
            </p>
          )}
        </details>
        <button className="correction-link" onClick={() => onCorrection(brand)}>
          <Flag size={13} /> 信息有误？记录纠错
        </button>
      </div>
    </Modal>
  );
}

export function About({
  brands,
  onClose,
}: {
  brands: Brand[];
  onClose: () => void;
}) {
  const shopping = brands.filter((b) => b.shop).length;
  return (
    <Modal title="收录与使用说明" onClose={onClose} className="about-modal">
      <div className="eyebrow">关于这张地图</div>
      <h2>让老字号，更容易被发现。</h2>
      <p>
        这是一个独立整理的品牌导航原型，不是商务部或任何品牌的官方平台，也不在本站交易。
      </p>
      <div className="about-stats">
        <div>
          <strong>{brands.length}</strong>
          <span>名录在册品牌</span>
        </div>
        <div>
          <strong>{shopping}</strong>
          <span>已核验网购入口</span>
        </div>
        <div>
          <strong>{brands.filter((b) => b.image).length}</strong>
          <span>已填写许可的品牌图片</span>
        </div>
      </div>
      <h3>收录范围</h3>
      <p>
        品牌名录依据商务部《中华老字号名单》（2025年12月版，共{" "}
        {brands.length} 项）全量收录，每条注明名录项次；少数条目为整理较详的精选档案。名录按地区排序、区内不分先后，历史认定不代表已完成最新复核。部分条目按企业名称初步归类品类、按省份归属展示，待逐条核实。
      </p>
      <a
        className="text-link"
        href={REGISTRY_URL}
        target="_blank"
        rel="noopener noreferrer"
      >
        查阅商务部中华老字号名录 <ArrowUpRight size={14} />
      </a>
      <h3>地图与图片</h3>
      <p>
        全国视角按省级聚合，选中省份后按城市展示。坐标来自 DataV
        行政区中心数据，仅用于归属地示意，不是门店地址，不提供到店导航。全部边界要素随源数据展示。
      </p>
      <p>
        底图来自 DataV
        GeoAtlas，当前只用于开发预览；正式公开部署前须完成地图来源许可、边界时效与审图要求核查，或替换为合规地图服务。未取得品牌图片授权的条目使用明确标注的原创品类插画。
      </p>
      <h3>购买链接</h3>
      <p>
        网购入口分两类核验：品牌来源指向（官网等权威页面外链的店铺）与店铺页自证（已核对店铺页品牌标识的天猫旗舰店）。未核实的店铺不作推荐，未验证下单、库存和配送。医药类仅作品牌信息索引，正式上线前须另行核查医药推广及跳转要求。
      </p>
      <h3>本地数据工作台</h3>
      <p>
        数据修改和纠错草稿仅保存在当前浏览器，不会同步给其他人或写入服务器。支持导出备份。正式多人维护需要另建身份验证、数据库和审核流程。
      </p>
    </Modal>
  );
}

export function CorrectionDialog({
  brand,
  onClose,
  onSaved,
}: {
  brand: Brand;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [text, setText] = useState("");
  const [error, setError] = useState("");
  return (
    <Modal title="记录纠错" onClose={onClose}>
      <div className="eyebrow">一起补全这张地图</div>
      <h2>更正「{brand.name}」</h2>
      <p className="muted">
        请描述有误的信息，最好附上依据链接。不需要填写个人联系方式。
      </p>
      <label className="field">
        纠错内容
        <textarea
          value={text}
          maxLength={2000}
          rows={5}
          onChange={(e) => setText(e.target.value)}
          placeholder="例如：原店铺链接已失效，品牌官网公布的新入口是……"
        />
      </label>
      <p className="notice">
        <Info size={15} />{" "}
        这是本地草稿，不会自动提交给维护者。保存后可在数据工作台导出。
      </p>
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      <button
        className="primary-button"
        disabled={!text.trim()}
        onClick={() => {
          try {
            const raw = JSON.parse(
              localStorage.getItem(CORRECTION_KEY) || "[]",
            );
            if (!Array.isArray(raw))
              throw new Error("旧草稿格式有误，请先导出检查");
            const next: Correction = {
              id: crypto.randomUUID(),
              brandId: brand.id,
              brandName: brand.name,
              text: text.trim(),
              createdAt: new Date().toISOString(),
            };
            localStorage.setItem(
              CORRECTION_KEY,
              JSON.stringify([...raw, next]),
            );
            onSaved();
          } catch (error) {
            setError(errorMessage(error));
          }
        }}
      >
        <Save size={16} /> 保存本地纠错草稿
      </button>
    </Modal>
  );
}

export function DataManager({
  brands,
  regions,
  onSave,
  onReset,
  onClose,
}: {
  brands: Brand[];
  regions: Region[];
  onSave: (b: Brand[]) => void;
  onReset: () => void;
  onClose: () => void;
}) {
  const [editingId, setEditingId] = useState(brands[0]?.id || "");
  const [draft, setDraft] = useState(JSON.stringify(brands[0], null, 2));
  const [pending, setPending] = useState<Brand[] | null>(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [resetConfirm, setResetConfirm] = useState(false);
  const [corrections, setCorrections] = useState<Correction[]>([]);
  useEffect(() => {
    try {
      const list = JSON.parse(localStorage.getItem(CORRECTION_KEY) || "[]");
      if (Array.isArray(list))
        setCorrections(
          list.filter(
            (c) =>
              typeof c?.id === "string" &&
              typeof c?.text === "string" &&
              typeof c?.brandName === "string",
          ),
        );
    } catch {
      setError("纠错草稿读取失败，其他数据不受影响。");
    }
  }, []);
  async function handleImport(file?: File) {
    if (!file) return;
    setError("");
    setMessage("");
    setPending(null);
    try {
      if (file.size > 8 * 1024 * 1024) throw new Error("文件不能超过 8MB");
      const text = await file.text();
      const parsed = file.name.toLowerCase().endsWith(".csv")
        ? importCsv(text, regions)
        : validateBrands(JSON.parse(text), regions);
      setPending(parsed);
    } catch (error) {
      setError(errorMessage(error));
    }
  }
  function selectBrand(id: string) {
    setEditingId(id);
    setDraft(
      JSON.stringify(
        brands.find((b) => b.id === id),
        null,
        2,
      ),
    );
    setMessage("");
    setError("");
  }
  return (
    <Modal title="本地数据工作台" onClose={onClose} className="manager-modal">
      <div className="eyebrow">内容维护 · 本机预览</div>
      <h2>本地数据工作台</h2>
      <p className="notice">
        <Info size={16} />{" "}
        修改只保存到当前浏览器。导出文件后，才能备份或交给其他维护者；这不是线上管理后台。
      </p>
      <div className="manager-tools">
        <button
          onClick={() =>
            downloadFile(
              "laozihao-brands.json",
              JSON.stringify(brands, null, 2),
            )
          }
        >
          <Download size={16} /> 导出 JSON
        </button>
        <button
          onClick={() =>
            downloadFile(
              "laozihao-brands.csv",
              exportCsv(brands),
              "text/csv;charset=utf-8",
            )
          }
        >
          <Download size={16} /> 导出 CSV
        </button>
        <label className="upload-button">
          <Upload size={16} /> 导入 CSV / JSON
          <input
            type="file"
            accept=".json,.csv"
            onChange={(e) => {
              void handleImport(e.target.files?.[0]);
              e.target.value = "";
            }}
          />
        </label>
        <button
          onClick={() =>
            downloadFile(
              "brand-template.csv",
              exportCsv(brands.slice(0, 1)),
              "text/csv;charset=utf-8",
            )
          }
        >
          下载表格模板
        </button>
      </div>
      <p className="small muted">
        CSV 列名与模板一致；categories、specialties 用 |
        分隔，sources、shop、image 使用 JSON。导入前校验网址、日期、地区和重复
        ID，不会自动认证新链接。
      </p>
      {pending && (
        <div className="import-preview">
          <strong>已通过格式校验：{pending.length} 个品牌</strong>
          <p>
            将替换当前浏览器中的 {brands.length}{" "}
            个品牌，不与旧数据合并。请先备份并人工核实资料、图片许可和店铺主体。
          </p>
          <button
            className="primary-button"
            onClick={() => {
              try {
                onSave(pending);
                setEditingId(pending[0].id);
                setDraft(JSON.stringify(pending[0], null, 2));
                setPending(null);
                setMessage("导入已保存到本地。");
              } catch (error) {
                setError(errorMessage(error));
              }
            }}
          >
            确认替换本地数据
          </button>
          <button className="text-button" onClick={() => setPending(null)}>
            取消导入
          </button>
        </div>
      )}
      <hr />
      <h3>修改品牌档案</h3>
      <label className="field">
        选择品牌
        <select value={editingId} onChange={(e) => selectBrand(e.target.value)}>
          {brands.map((b) => (
            <option key={b.id} value={b.id}>
              {b.name} · {b.city}
            </option>
          ))}
        </select>
      </label>
      <label className="field">
        品牌数据（JSON）
        <textarea
          className="json-editor"
          spellCheck={false}
          value={draft}
          rows={13}
          onChange={(e) => setDraft(e.target.value)}
        />
      </label>
      <button
        className="primary-button"
        onClick={() => {
          setError("");
          setMessage("");
          try {
            const parsed = JSON.parse(draft);
            if (parsed.id !== editingId)
              throw new Error(
                "单条编辑不能修改 ID；新增或调整 ID 请通过表格导入",
              );
            const next = validateBrands(
              brands.map((b) => (b.id === editingId ? parsed : b)),
              regions,
            );
            onSave(next);
            setMessage("品牌档案已保存到本地。");
          } catch (error) {
            setError(errorMessage(error));
          }
        }}
      >
        <Save size={16} /> 校验并保存品牌
      </button>
      {message && (
        <p className="success" role="status">
          {message}
        </p>
      )}
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      <hr />
      <div className="section-title">
        <h3>
          纠错草稿 <span className="count-pill">{corrections.length}</span>
        </h3>
        <button
          disabled={!corrections.length}
          className="text-button"
          onClick={() =>
            downloadFile(
              "laozihao-corrections.json",
              JSON.stringify(corrections, null, 2),
            )
          }
        >
          <Download size={14} /> 导出草稿
        </button>
      </div>
      {!corrections.length ? (
        <p className="muted small">暂无草稿。可在品牌详情中记录问题。</p>
      ) : (
        <ul className="correction-list">
          {corrections.map((c) => (
            <li key={c.id}>
              <strong>{c.brandName}</strong>
              <p>{c.text}</p>
              <button
                className="text-button"
                onClick={() => {
                  try {
                    const next = corrections.filter((item) => item.id !== c.id);
                    localStorage.setItem(CORRECTION_KEY, JSON.stringify(next));
                    setCorrections(next);
                  } catch (error) {
                    setError(errorMessage(error));
                  }
                }}
              >
                标记已处理并移除草稿
              </button>
            </li>
          ))}
        </ul>
      )}
      <hr />
      <button
        className="text-button danger"
        onClick={() => setResetConfirm(true)}
      >
        <RotateCcw size={14} /> 恢复内置数据
      </button>
      {resetConfirm && (
        <div className="import-preview">
          <p>
            将清除本地品牌修改并恢复随项目附带的数据。纠错草稿不受影响，请先导出备份。
          </p>
          <button
            className="primary-button"
            onClick={() => {
              try {
                onReset();
                onClose();
              } catch (error) {
                setError(errorMessage(error));
              }
            }}
          >
            确认恢复
          </button>
          <button
            className="text-button"
            onClick={() => setResetConfirm(false)}
          >
            取消
          </button>
        </div>
      )}
    </Modal>
  );
}

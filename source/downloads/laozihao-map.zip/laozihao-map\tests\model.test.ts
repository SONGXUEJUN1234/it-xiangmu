import { describe, it, expect, vi } from "vitest";
import seeds from "../public/data/brands.json";
import rawRegions from "../public/data/regions.json";
import {
  brandSchema,
  validateBrands,
  filterBrands,
  EMPTY_FILTERS,
  readFilters,
  writeFilters,
  importCsv,
  exportCsv,
  shortRegion,
  type Brand,
  type Region,
} from "../src/model";

const regions = rawRegions as Region[];
const brands = validateBrands(seeds, regions);
const fixture = () => structuredClone(brands[0]);

describe("curated seed integrity", () => {
  it("contains the full 2025-12 MOFCOM registry: 1450 unique brands", () => {
    expect(brands).toHaveLength(1450);
    expect(new Set(brands.map((b) => b.id)).size).toBe(1450);
    expect(new Set(brands.map((b) => b.province)).size).toBeGreaterThanOrEqual(
      30,
    );
  });
  it("keeps the 30 hand-curated records with their original ids", () => {
    const curatedIds = [
      "quanjude",
      "xiaguan-tuocha",
      "wufangzhai-jiaxing",
      "beijing-tongrentang",
      "guanshengyuan-shanghai",
      "huogongdian",
    ];
    for (const id of curatedIds)
      expect(brands.some((b) => b.id === id)).toBe(true);
  });
  it("only lists shop links with evidence and a verification tier", () => {
    const shops = brands.filter((b) => b.shop);
    expect(shops.length).toBeGreaterThanOrEqual(4);
    expect(
      shops.every(
        (b) =>
          b.shop!.evidenceUrl &&
          b.shop!.label &&
          ["official", "platform"].includes(b.shop!.verification!),
      ),
    ).toBe(true);
  });
  it("never presents illustrative art as a real brand photograph", () =>
    expect(brands.every((b) => !b.image)).toBe(true));
  it("has independently linked government recognition evidence for every brand", () => {
    for (const b of brands)
      expect(
        b.sources.some((s) =>
          /(^|\.)(mofcom\.gov\.cn|gov\.cn)$/.test(new URL(s.url).hostname),
        ),
      ).toBe(true);
  });
  it("places every brand in a city of its province or at province level", () => {
    for (const b of brands) {
      const region = regions.find((r) => r.name === b.province)!;
      expect(
        b.city === region.name ||
          region.cities.some((c) => c.name === b.city),
      ).toBe(true);
    }
  });
});

describe("combined filtering", () => {
  it("shows the full registry with no filters", () =>
    expect(filterBrands(brands, EMPTY_FILTERS)).toHaveLength(1450));
  it("filters categories", () =>
    expect(
      filterBrands(brands, { ...EMPTY_FILTERS, category: "tea" }).length,
    ).toBeGreaterThan(4));
  it("combines province and category", () =>
    expect(
      filterBrands(brands, {
        ...EMPTY_FILTERS,
        province: "浙江省",
        category: "food",
      }).map((b) => b.name),
    ).toContain("五芳斋"));
  it("combines shop, province and category without conflating corporate websites", () => {
    const hits = filterBrands(brands, {
      ...EMPTY_FILTERS,
      province: "北京市",
      category: "medicine",
      shopping: true,
    });
    expect(hits.map((b) => b.name)).toContain("北京同仁堂");
    expect(
      hits.every((b) => b.shop !== null && b.categories.includes("medicine")),
    ).toBe(true);
  });
  it("searches representative products", () =>
    expect(
      filterBrands(brands, { ...EMPTY_FILTERS, query: "香醋" }).map(
        (b) => b.name,
      ),
    ).toEqual(["恒顺"]));
  it("matches whitespace-separated terms with AND semantics", () =>
    expect(
      filterBrands(brands, { ...EMPTY_FILTERS, query: "  浙江   粽子  " }).map(
        (b) => b.name,
      ),
    ).toEqual(["五芳斋"]));
  it("does not mix Beijing 同仁堂 into a Tianjin search", () => {
    const hits = filterBrands(brands, {
      ...EMPTY_FILTERS,
      query: "同仁堂",
      province: "天津市",
    });
    expect(hits.some((b) => b.name.includes("同仁堂"))).toBe(false);
    expect(hits.some((b) => b.name === "太阳")).toBe(true);
  });
  it("covers Xinjiang registry entries after the full import", () =>
    expect(
      filterBrands(brands, { ...EMPTY_FILTERS, province: "新疆维吾尔自治区" }),
    ).toHaveLength(4));
  it("does not mutate the underlying seed array", () => {
    const before = JSON.stringify(brands);
    filterBrands(brands, { ...EMPTY_FILTERS, shopping: true });
    expect(JSON.stringify(brands)).toBe(before);
  });
});

describe("import validation and security", () => {
  it("round-trips quoted and multiline CSV text", () => {
    const b = fixture();
    b.description = '第一段，含有逗号和"引号"。\n第二段。';
    expect(importCsv(exportCsv([b]), regions)).toEqual([b]);
  });
  it("round-trips the full dataset", () =>
    expect(importCsv(exportCsv(brands), regions)).toEqual(brands));
  it.each([
    "javascript:alert(1)",
    "data:text/html,test",
    "file:///etc/passwd",
    "ftp://example.com",
  ])("rejects unsafe link protocol %s", (value) => {
    const b = fixture();
    b.website = value;
    expect(() => brandSchema.parse(b)).toThrow();
  });
  it("requires independent link evidence for a shop", () => {
    const b = {
      ...fixture(),
      shop: { label: "未经核实商店", url: "https://example.com/" },
    };
    expect(() => validateBrands([b])).toThrow();
  });
  it("rejects a duplicate ID", () =>
    expect(() => validateBrands([fixture(), fixture()])).toThrow("重复"));
  it("rejects mismatched provinces and cities", () => {
    const b = fixture();
    b.city = "杭州市";
    expect(() => validateBrands([b], regions)).toThrow("不匹配");
  });
  it("requires a source for all brands", () => {
    const b = fixture();
    b.sources = [];
    expect(() => validateBrands([b])).toThrow();
  });
  it("requires image licensing metadata", () => {
    const b = {
      ...fixture(),
      image: { url: "https://example.com/photo.jpg", alt: "图片" },
    };
    expect(() => validateBrands([b])).toThrow();
  });
  it("rejects empty datasets", () =>
    expect(() => validateBrands([])).toThrow());
  it("rejects impossible calendar dates", () => {
    const b = fixture();
    b.checkedAt = "2026-02-31";
    expect(() => validateBrands([b])).toThrow();
  });
  it("escapes spreadsheet formula injection on export", () => {
    const b = fixture();
    b.name = "=1+1";
    expect(exportCsv([b])).toContain("'=1+1");
  });
  it("rejects broken CSV rows instead of silently importing partial values", () =>
    expect(() => importCsv('id,name\n"unclosed')).toThrow());
});

describe("shareable filter state", () => {
  it("round-trips category, province, city, search and shop filter in URL", () => {
    const f = {
      query: "粽子",
      category: "food",
      province: "浙江省",
      city: "嘉兴市",
      shopping: true,
    };
    expect(readFilters(writeFilters(f, "wufangzhai-jiaxing"))).toEqual(f);
  });
  it("ignores an unknown category", () =>
    expect(readFilters("?category=evil").category).toBe("all"));
  it("caps a query at 100 characters", () =>
    expect(readFilters("?q=" + "a".repeat(1000)).query).toHaveLength(100));
  it("clears empty query strings", () => {
    vi.stubGlobal("window", { location: { pathname: "/" } });
    expect(writeFilters(EMPTY_FILTERS)).toBe("/");
    vi.unstubAllGlobals();
  });
  it("keeps Guangxi, Inner Mongolia and Hong Kong short names legible", () => {
    expect(shortRegion("广西壮族自治区")).toBe("广西");
    expect(shortRegion("内蒙古自治区")).toBe("内蒙古");
    expect(shortRegion("香港特别行政区")).toBe("香港");
  });
});

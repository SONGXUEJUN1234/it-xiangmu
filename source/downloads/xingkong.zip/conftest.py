# 使 pytest 将项目根加入 sys.path，tests/ 内可直接 import star_data 等

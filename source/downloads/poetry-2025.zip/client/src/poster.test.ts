import { describe, expect, it } from "vitest";
import { createPosterSvg } from "@shared/poster";

describe("poem poster", () => {
  it("renders a shareable poster with poem and interpretation summary", () => {
    const svg = createPosterSvg({ id: 3, title: "标签", body: "我们为了记录运动\n创造了时间", form: "现代诗" }, "AI 认为，这首诗讨论了命名与被命名。");
    expect(svg).toContain('width="1080" height="1600"');
    expect(svg).toContain("标签");
    expect(svg).toContain("我们为了记录运动");
    expect(svg).toContain("AI 认为，这首诗讨论了命名与被命名。");
    expect(svg).toContain("AI 赏析摘要");
  });
});

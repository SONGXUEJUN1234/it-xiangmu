# ExpFood MVP (Standalone)

这是一个独立项目目录，不依赖 `expfood-app` 原有结构。

## 快速续接

- 项目状态快照：`PROJECT_STATUS.md`
- 任务清单（含完成标记）：`TASKS.md`

## 最新进度（2026-02-13）

- 前端流程重构：`注册商家`、`登录商家`、`修改商家` 已拆分为独立操作区。
  - 注册商家：先点“注册商家（清空表单）”，填资料后点“保存商家资料”；保存成功后仅提示，不自动登录。
  - 登录商家：仅建立商家会话，不与注册表单联动。
  - 修改商家：登录成功后自动带出资料到“修改商家”表单，点“修改保存”提交。
- 商家注册前端增强：
  - 默认带一张示例资质图（避免每次手动选择）。
  - 增加必填提示条与缺失字段明细提示（`missing_fields`）。
- 地图/附近商家排查结论：
  - 若 `AMAP_JS_KEY` 为空，地图标记不会渲染，但附近商家接口仍可返回列表数据。
  - 附近商家按半径过滤（`radius_km`），超半径商家不会显示。
- 测试状态：`npm test`、`npm run test:api` 均通过。

## 运行

```bash
cd /home/erp17/expfood-mvp
npm install
npm run dev
```

浏览器访问：

```text
http://localhost:8088
```

API 文档：

```text
http://localhost:8088/api-docs.html
http://localhost:8088/openapi.json
```

## 部署

### Docker Compose

```bash
cd /home/erp17/expfood-mvp
docker compose up -d --build
docker compose logs -f
```

停止：

```bash
docker compose down
```

说明：
- 编排文件：`docker-compose.yml`
- 镜像构建：`Dockerfile`
- 数据持久化目录：`./database`（映射到容器 `/app/database`）

### systemd

服务模板：

```text
deploy/expfood-mvp.service
```

安装步骤（Ubuntu）：

```bash
sudo cp /home/erp17/expfood-mvp/deploy/expfood-mvp.service /etc/systemd/system/expfood-mvp.service
sudo systemctl daemon-reload
sudo systemctl enable --now expfood-mvp
sudo systemctl status expfood-mvp
```

## 当前功能

- 登录（买家/商家）
- 买家注册与资料编辑（姓名、常用地址）
- 商家注册（店铺名称、地址、联系人、营业时间、资质图）
- 商家营业状态开关（营业中/打烊）
- 买家附近商店搜索（按经纬度 + 半径，返回折扣信息）
- 商品发布与管理（编辑、上下架、分页筛选、图片必填、多图详情字段）
- 买家下单、订单详情、取消订单、分页筛选
- 商家订单列表、订单详情、核销、分页筛选
- 支付与结算通道（Alipay MCP，支持买家支付与商家结算打款）
- 超时自动取消（15 分钟）
- 退款占位接口
- 内存库存一致性锁（防并发超卖）

## 说明

- 默认是内存模式（重启会清空数据）。
- 推荐使用 SQLite 持久化模式（本地文件，无需单独安装数据库服务）：

```bash
cp .env.example .env
# 默认 SQLITE_ENABLED=true，可按需修改 SQLITE_PATH
npm install
npm run dev
```

启动日志会显示：
- `[STORAGE] memory`：内存模式
- `[STORAGE] sqlite`：SQLite 模式

## 环境分层

- 开发环境模板：`.env.example`
- 测试环境模板：`.env.test.example`
- 生产环境模板：`.env.production.example`

关键配置项：
- `NODE_ENV`：`development` / `test` / `production`
- `HOST`、`PORT`：服务监听地址和端口
- `ACCESS_TOKEN_TTL_MS`：访问 token 有效期（毫秒）
- `REFRESH_TOKEN_TTL_MS`：刷新 token 有效期（毫秒）
- `ORDER_TIMEOUT_MS`：订单超时自动取消时长（毫秒）
- `SQLITE_ENABLED`：是否启用 SQLite 持久化
- `SQLITE_PATH`：SQLite 数据文件路径
- `AMAP_WEB_KEY`：高德 Web 服务 Key（用于地址转经纬度）
- `AMAP_JS_KEY`：高德 Web JS Key（用于前端地图展示；未配置时默认回退 `AMAP_WEB_KEY`）
  - 地址转经纬度优先使用 `AMAP_WEB_KEY`，若未配置则自动回退 `AMAP_JS_KEY`
- `AMAP_SECURITY_JS_CODE`：高德 JS 安全密钥（前端加载地图时自动注入 `_AMapSecurityConfig.securityJsCode`）
- `AMAP_GEOCODE_ENDPOINT`：高德地理编码接口地址
- `AMAP_TIMEOUT_MS`：高德接口超时（毫秒）
- `ALIPAY_MCP_ENABLED`：是否启用支付宝 MCP 支付通道
- `ALIPAY_MCP_MODE`：`mock` / `live`
- `ALIPAY_MCP_BASE_URL`：支付宝 MCP 服务地址（`live` 必填）
- `ALIPAY_MCP_API_KEY`：支付宝 MCP 鉴权密钥（`live` 必填）
- `ALIPAY_MCP_TIMEOUT_MS`：支付宝 MCP 请求超时（毫秒）
- `ALIPAY_MCP_RETRY_MAX`：支付宝 MCP 瞬时故障重试次数（建议 `0~2`，默认 `1`）

商品发布字段（当前）：
- 必填：`name`、`category_id`、`original_price`、`discount_price`、`stock`、`images[]`、`production_date`、`best_before_date`
- 可选：`detail_images[]`、`ingredients`、`allergen_info`、`pickup_start_time`、`pickup_end_time`
- 图片限制：
  - `images` 最多 6 张，`detail_images` 最多 12 张
  - 单个图片引用长度 <= 2048
  - `data:image` 单张 <= 2MB，单次请求合计 <= 8MB

商家注册字段（当前）：
- 必填：`phone`、`shop_name`、`shop_address`、`contact_name`、`contact_phone`、`shop_lat`、`shop_lng`、`business_hours`、`license_images[]`
- 资料编辑：`PUT /api/v1/merchant/profile`（需商家 token；地址变更可自动重算坐标）
- 营业状态：`PUT /api/v1/merchant/open-status`（`is_open=true|false`）

买家注册字段（当前）：
- 必填：`phone`、`full_name`
- 可选：`buyer_address`
- 资料编辑：`PUT /api/v1/buyer/profile`（需买家 token）

地图接入（当前）：
- 后端地址转坐标接口：`GET /api/v1/map/geocode?address=...`
- 前端地图配置接口：`GET /api/v1/map/config`（前端自动读取 JS Key）
- 商家注册可手填 `shop_lat/shop_lng`，也可先通过地址转坐标自动填充
- 附近商家接口：`GET /api/v1/shops/nearby?lat=...&lng=...&radius_km=...&sort_by=distance|discount|price`
  - 返回包含：`business_hours`、`active_product_count`、`featured_product`
  - 仅返回“营业中”的商家（`is_open=true`）

支付与结算（Alipay MCP）：
- 买家支付：`POST /api/v1/orders/{id}/pay`（可传 `{"channel":"alipay_mcp"}`）
- 买家批量支付：`POST /api/v1/orders/batch-pay`（`order_ids[]` + 可选 `channel`）
- 商家单笔结算：`POST /api/v1/merchant/orders/{id}/settle`（可传 `channel`）
- 商家批量结算：`POST /api/v1/merchant/orders/settle/batch`（`order_ids[]` + 可选 `channel`）
- 配置联调：`GET /api/v1/payments/config`（需登录，返回启用状态、模式、配置完整性）
- 模式说明：
  - `ALIPAY_MCP_MODE=mock`：本地模拟打款/收款（默认）
  - `ALIPAY_MCP_MODE=live`：调用你部署的 Alipay MCP 网关（建议按官方文档部署 `@alipay/mcp-server-alipay` 后接入）
  - 启动校验：当 `ALIPAY_MCP_ENABLED=true` 且 `ALIPAY_MCP_MODE=live` 时，若缺少 `ALIPAY_MCP_BASE_URL` 或 `ALIPAY_MCP_API_KEY`，服务会启动失败并打印缺失项。
- 幂等建议：
  - 对支付/结算/退款接口传 `Idempotency-Key` 请求头（或 body 字段 `idempotency_key`）
  - 同一 key + 同一请求体会返回同一结果；同一 key + 不同请求体会返回 `409 IDEMPOTENCY_KEY_REUSED`
  - 服务会将幂等键透传到上游支付网关（批量场景按订单派生子键）

## 测试命令

- `npm test`：快速回归（仓储层）
- `npm run test:api`：API 集成链路（登录→发布→下单→核销→分页）
- `npm run test:all`：运行全部测试

## 开发规则（必须执行）

- 每次代码改动后必须运行测试。
- 最小要求：
  1. `npm test`
  2. `npm run test:api`
- 如有失败，先修复再继续下一步开发。

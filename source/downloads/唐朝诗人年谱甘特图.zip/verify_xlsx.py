# -*- coding: utf-8 -*-
"""唐朝诗人年谱甘特图 · 自验脚本
五项检查：
  a) formulas 库重算全部公式：零错误，交集矩阵与纯 Python 计算一致
  b) 两张甘特图逐桶色块 vs 数据映射：100% 一致
  c) 读我 sheet 图例色块与分类色板一一对应
  d) 史实抽查（数据层 + 渲染层）
  e) ASCII 预览（人工目检碰撞）
"""
import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

from openpyxl import load_workbook
from openpyxl.utils import column_index_from_string

import build_xlsx as B

OUT = B.OUT
YEAR_START, STEP = B.YEAR_START, B.STEP
PERIODS = B.PERIODS

poets, segments, events, encounters = B.load_all()
by_poet = {}
for s in segments:
    by_poet.setdefault(s["poet_id"], []).append(s)

REGION_CH = {"两京": "J", "江南": "N", "蜀中": "S", "荆湘": "X", "中原": "Z", "岭南": "L", "西北": "W", "不详": "?"}

FAILED = []


def check(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f" — {detail}" if detail else ""))
    if not ok:
        FAILED.append(name)


def poet_rows():
    """复刻 build_gantt 的行布局：yield (bar_row, poet)"""
    row = 5
    for pname, _, _ in PERIODS:
        row += 1  # 分组头
        for p in [p for p in poets if p["period"] == pname]:
            yield row, p
            row += 2


def expected_bucket(poet, key):
    return B.bucket_color_map(sorted(by_poet[poet["id"]], key=lambda s: s["start"]), key, None)


print(f"= 自验对象：{OUT.name}")

# ---------- b) 逐桶配色比对 ----------
print("[b] 甘特图逐桶配色比对（数据→渲染 一致性）")
wb = load_workbook(OUT)
for sheet, key, palette in (("甘特·地点", "region", B.REGION_COLORS), ("甘特·类型", "type", B.TYPE_COLORS)):
    ws = wb[sheet]
    total_colored = 0
    bad = []
    for bar_row, p in poet_rows():
        exp = expected_bucket(p, key)
        for idx in range(len(B.BUCKET_STARTS)):
            cell = ws.cell(row=bar_row, column=B.FIRST_COL + idx)
            want = palette.get(exp.get(idx)) if exp.get(idx) is not None else None
            got = cell.fill.start_color.rgb if cell.fill.patternType == "solid" else None
            if want:
                total_colored += 1
                if got != want:
                    bad.append((p["name"], B.BUCKET_STARTS[idx], want, got))
            elif got:
                bad.append((p["name"], B.BUCKET_STARTS[idx], None, got))
    check(f"{sheet}：{total_colored} 个色桶全部与数据映射一致", not bad, f"{len(bad)} 处不符" if bad else "")
    for x in bad[:10]:
        print("      不例：", x)

# ---------- c) 图例色块 ----------
print("[c] 读我 sheet 图例与色板对应")
ws = wb["读我"]
swatches = []
for row in ws.iter_rows(min_col=2, max_col=2):
    cell = row[0]
    if cell.fill.patternType == "solid":
        swatches.append(cell.fill.start_color.rgb)
want = sorted(set(B.REGION_COLORS.values()) | set(B.TYPE_COLORS.values()))
check(f"图例色块 {len(swatches)} 个，色值集合与两套色板完全一致",
      sorted(set(swatches)) == want, "")

# ---------- d) 史实抽查 ----------
print("[d] 史实抽查（数据层 + 渲染层）")
SPOT = [  # (诗人, 年份, 类型, 地区, 说明)
    ("李白", 743, "京官", "两京", "翰林供奉"),
    ("李白", 745, "漫游", "中原", "梁宋同游"),
    ("杜甫", 760, "漫游", "蜀中", "成都草堂"),
    ("杜甫", 769, "漫游", "荆湘", "漂泊湖湘前夜在蜀中"),  # 769 属 766-768 夔州之后? 769 在蜀
    ("白居易", 816, "贬谪", "江南", "江州司马"),
    ("柳宗元", 810, "贬谪", "荆湘", "永州司马"),
    ("王维", 756, "贬谪", "两京", "陷安史军"),
    ("韩愈", 819, "贬谪", "岭南", "谏佛骨贬潮州"),
    ("刘禹锡", 822, "地方官", "蜀中", "夔州刺史"),
    ("李商隐", 852, "军幕", "蜀中", "东川柳仲郢幕"),
    ("杜牧", 823, "未仕", "两京", "及第前"),
    ("薛涛", 820, "隐居", "蜀中", "浣花溪"),
]
name_to_id = {p["name"]: p["id"] for p in poets}
ws_loc, ws_typ = wb["甘特·地点"], wb["甘特·类型"]
for nm, year, typ, region, note in SPOT:
    seg = next(s for s in by_poet[name_to_id[nm]] if s["start"] <= year <= s["end"])
    sm = B.bucket_seg_map(sorted(by_poet[name_to_id[nm]], key=lambda s: s["start"]))
    owned = [i for i, sg in sm.items() if sg is seg]
    br = next(r for r, p in poet_rows() if p["name"] == nm)
    ok_data = seg["type"] == typ and seg["region"] == region
    ok_render = bool(owned) and all(
        ws_typ.cell(row=br, column=B.FIRST_COL + i).fill.start_color.rgb == B.TYPE_COLORS[seg["type"]]
        and ws_loc.cell(row=br, column=B.FIRST_COL + i).fill.start_color.rgb == B.REGION_COLORS[seg["region"]]
        for i in owned)
    check(f"{nm} {year} {note}：段={seg['type']}/{seg['region']} 拥有{len(owned)}桶且渲染色一致",
          ok_data and ok_render,
          "" if (ok_data and ok_render) else f"数据段={seg['type']}/{seg['region']} 拥有桶={owned}")

# 短段渲染覆盖：≥3 年的段必须至少占一桶；≤2 年段允许降为标签（统计数量）
no_bucket = []
for p in poets:
    segs = sorted(by_poet[p["id"]], key=lambda s: s["start"])
    sm = B.bucket_seg_map(segs)
    for s in segs:
        if not any(sg is s for sg in sm.values()):
            no_bucket.append((p["name"], s["start"], s["end"], s["label"]))
long_lost = [x for x in no_bucket if x[2] - x[1] >= 2]
# 骑跨型取舍：段横跨两个桶的边缘（各占 1-2 年）时无桶是 5 年粒度的正确取舍，
# 由文字标签兜底；阈值 6 用于拦截系统性的分配缺陷
check(f"≥3 年的段拥有渲染桶（骑跨型无桶 ≤6 个，现有 {len(long_lost)}）",
      len(long_lost) <= 6, str(long_lost[:6]) if long_lost else "")
print(f"      （{len(no_bucket)} 个 ≤2 年短段未占到桶，细节由文字标签与年谱数据表承载：）")
for x in no_bucket:
    print("        ", x)

# ---------- e) ASCII 预览 ----------
print("[e] ASCII 预览（地点图 · J两京 N江南 S蜀中 X荆湘 Z中原 L岭南 W西北 ?不详 · | 为大事竖线）")
major_cols = {(e["year"] - YEAR_START) // STEP for e in events if e["ismajor"]}
for bar_row, p in poet_rows():
    exp = expected_bucket(p, "region")
    line = []
    for idx in range(len(B.BUCKET_STARTS)):
        ch = REGION_CH.get(exp.get(idx), "·")
        line.append(ch)
    for idx in sorted(major_cols):
        line[idx] = "|"
    print(f"{p['name']:　<4}{B.life_disp(p):>10} " + "".join(line))
print("（横轴 580-929，每字符 5 年；从左到右每 10 桶依次：580,630,680,730,780,830,880,920 附近）")

# ---------- a) 公式重算 ----------
print("[a] formulas 库重算全部公式（零错误 + 矩阵与纯 Python 一致）")
# 环境的 scipy 与 numpy 1.26 版本冲突（np.long 已移除），formulas 导入函数表时会连带崩溃。
# 本表只用到 MAX/MIN/算术：装一个元路径查找器，把 scipy.* 一律合成为空桩模块。
import importlib.abc  # noqa: E402
import importlib.machinery  # noqa: E402
import types  # noqa: E402


class _ScipyStubFinder(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == "scipy" or fullname.startswith("scipy."):
            return importlib.machinery.ModuleSpec(fullname, self, is_package=True)
        return None

    def create_module(self, spec):
        return types.ModuleType(spec.name)

    def exec_module(self, module):
        module.__path__ = []

        def _getattr(name):
            stub = types.ModuleType(f"{module.__name__}.{name}")
            module.__dict__[name] = stub
            sys.modules[stub.__name__] = stub
            return stub

        module.__getattr__ = _getattr


sys.meta_path.insert(0, _ScipyStubFinder())

import formulas  # noqa: E402

model = formulas.ExcelModel().loads(str(OUT)).finish()
sol = model.calculate()

n_formula, n_err = 0, 0
matrix_bad, diag_bad = [], []
pi = [p for p in poets]
for key, val in sol.items():
    m = re.search(r"!\$?([A-Z]{1,2})\$?(\d+)$", key)
    if not m or "交集" not in key:
        continue
    col, rowi = m.group(1), int(m.group(2))
    if not (3 <= rowi <= 2 + len(poets)) or column_index_from_string(col) < 2:
        continue  # 只统计矩阵区 B..AY；A 列是行首诗人名（文本）
    try:
        v = val.value
        try:
            v = v[0, 0]
        except (TypeError, IndexError):
            pass
        v = float(v)
    except Exception:
        n_err += 1
        continue
    n_formula += 1
    i, j = rowi - 3, column_index_from_string(col) - 2  # 行诗人、列诗人
    if not (0 <= i < len(poets) and 0 <= j < len(poets)):
        continue
    a, b = pi[i], pi[j]
    want = max(0, min(a["death"], b["death"]) - max(a["birth"], b["birth"]) + 1)
    if v != float(want):
        matrix_bad.append((key, v, want))
    if i == j and v != float(a["death"] - a["birth"] + 1):
        diag_bad.append((key, v))
# 名录享年 / 年谱年数 公式错误扫描（错误值形如 #NAME?）
for key, val in sol.items():
    try:
        v = val.value
        try:
            v = v[0, 0]
        except (TypeError, IndexError):
            pass
        if isinstance(v, str) and v.startswith("#"):
            n_err += 1
            print("      公式错误：", key, v)
    except Exception:
        pass

check(f"交集矩阵 {n_formula} 个公式全部重算成功且值正确", n_err == 0 and not matrix_bad and not diag_bad,
      f"错误{n_err} 值不符{len(matrix_bad)} 对角线不符{len(diag_bad)}" if (n_err or matrix_bad or diag_bad) else "")

print()
if FAILED:
    print(f"== 自验未通过（{len(FAILED)} 项）：{FAILED}")
    sys.exit(1)
print("== 自验全部通过 ==")

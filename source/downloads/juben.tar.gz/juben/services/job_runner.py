import json
import os
import subprocess
import tempfile
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List


ROOT = Path(__file__).resolve().parents[1]
REPORT_DIR = ROOT / "pipeline_reports"
JOB_DIR = REPORT_DIR / "ui_jobs"


def _is_writable_dir(path: Path) -> bool:
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".write_probe.tmp"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink(missing_ok=True)
        return True
    except Exception:
        return False


def _resolve_job_dir() -> Path:
    env_dir = os.environ.get("JUBEN_UI_JOB_DIR", "").strip()
    candidates: List[Path] = []
    if env_dir:
        candidates.append(Path(env_dir))
    candidates.append(REPORT_DIR / "ui_jobs")
    candidates.append(ROOT / "out" / "ui_jobs")
    candidates.append(Path(tempfile.gettempdir()) / "juben_ui_jobs")

    for c in candidates:
        if _is_writable_dir(c):
            return c
    raise PermissionError("No writable directory available for UI job data.")


def _ensure_dirs() -> None:
    global JOB_DIR
    JOB_DIR = _resolve_job_dir()
    JOB_DIR.mkdir(parents=True, exist_ok=True)


def _now_ts() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _job_paths(job_id: str) -> Dict[str, Path]:
    return {
        "dir": JOB_DIR / job_id,
        "status": JOB_DIR / job_id / "status.json",
        "log": JOB_DIR / job_id / "run.log",
    }


def _write_status(status_path: Path, payload: Dict[str, Any]) -> None:
    status_path.parent.mkdir(parents=True, exist_ok=True)
    status_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _append_log(log_path: Path, line: str) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8") as f:
        f.write(line.rstrip("\n") + "\n")


def _run_job(job_id: str, cmd: List[str], params: Dict[str, Any]) -> None:
    paths = _job_paths(job_id)
    status_path = paths["status"]
    log_path = paths["log"]

    _write_status(
        status_path,
        {
            "job_id": job_id,
            "status": "running",
            "created_at": _now_ts(),
            "updated_at": _now_ts(),
            "command": cmd,
            "params": params,
            "returncode": None,
            "job_dir": str(JOB_DIR),
        },
    )

    _append_log(log_path, f"[{_now_ts()}] START {' '.join(cmd)}")
    returncode = 1
    try:
        p = subprocess.Popen(
            cmd,
            cwd=str(ROOT),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        assert p.stdout is not None
        for line in p.stdout:
            _append_log(log_path, line.rstrip("\n"))
        returncode = p.wait()
    except Exception as e:
        _append_log(log_path, f"[{_now_ts()}] ERROR {type(e).__name__}: {e}")
        returncode = 1

    status = "success" if returncode == 0 else "failed"
    _append_log(log_path, f"[{_now_ts()}] END returncode={returncode}")
    _write_status(
        status_path,
        {
            "job_id": job_id,
            "status": status,
            "created_at": json.loads(status_path.read_text(encoding='utf-8')).get("created_at"),
            "updated_at": _now_ts(),
            "command": cmd,
            "params": params,
            "returncode": returncode,
            "job_dir": str(JOB_DIR),
        },
    )


def start_factory_job(params: Dict[str, Any]) -> str:
    _ensure_dirs()
    job_id = time.strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:8]

    cmd: List[str] = [
        "python",
        "factory.py",
        "--genre",
        str(params.get("genre", "hardcore")),
        "--count",
        str(params.get("count", 5)),
        "--top",
        str(params.get("top", 1)),
        "--pass",
        str(params.get("base_pass", 80)),
        "--player-count",
        str(params.get("player_count", 6)),
        "--difficulty",
        str(params.get("difficulty", "hard")),
    ]

    duration = str(params.get("duration", "")).strip()
    tags = str(params.get("tags", "")).strip()
    setting_hint = str(params.get("setting_hint", "")).strip()
    retries = params.get("retries")
    timeout = params.get("timeout")
    no_pack = bool(params.get("no_pack", False))

    if duration:
        cmd += ["--duration", duration]
    if tags:
        cmd += ["--tags", tags]
    if setting_hint:
        cmd += ["--setting-hint", setting_hint]
    if retries is not None:
        cmd += ["--retries", str(retries)]
    if timeout is not None:
        cmd += ["--timeout", str(timeout)]
    if no_pack:
        cmd += ["--no-pack"]

    paths = _job_paths(job_id)
    paths["dir"].mkdir(parents=True, exist_ok=True)
    _write_status(
        paths["status"],
        {
            "job_id": job_id,
            "status": "queued",
            "created_at": _now_ts(),
            "updated_at": _now_ts(),
            "command": cmd,
            "params": params,
            "returncode": None,
            "job_dir": str(JOB_DIR),
        },
    )

    t = threading.Thread(target=_run_job, args=(job_id, cmd, params), daemon=True)
    t.start()
    return job_id


def read_job_status(job_id: str) -> Dict[str, Any]:
    _ensure_dirs()
    status_path = _job_paths(job_id)["status"]
    if not status_path.exists():
        return {"job_id": job_id, "status": "not_found"}
    return json.loads(status_path.read_text(encoding="utf-8"))


def read_job_log(job_id: str, max_lines: int = 300) -> str:
    _ensure_dirs()
    log_path = _job_paths(job_id)["log"]
    if not log_path.exists():
        return ""
    lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
    if max_lines > 0:
        lines = lines[-max_lines:]
    return "\n".join(lines)


def list_recent_jobs(limit: int = 20) -> List[Dict[str, Any]]:
    _ensure_dirs()
    jobs: List[Dict[str, Any]] = []
    for d in JOB_DIR.iterdir():
        if not d.is_dir():
            continue
        status_path = d / "status.json"
        if status_path.exists():
            try:
                jobs.append(json.loads(status_path.read_text(encoding="utf-8")))
            except Exception:
                continue
    jobs.sort(key=lambda x: x.get("updated_at", ""), reverse=True)
    return jobs[:limit]

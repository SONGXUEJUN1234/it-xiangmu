import { useEffect, useMemo, useRef, useState } from "react";
import { Compass, Minus, Plus, RotateCcw, MapPin, Move } from "lucide-react";
import type { Brand, Region } from "./model";
import { shortRegion } from "./model";
import { clusterPlaces, type MapPlace, type PlaceCluster } from "./mapUtils";

type Point = [number, number];
type Feature = {
  properties: {
    name: string;
    adcode: string | number;
    center?: Point;
    centroid?: Point;
  };
  geometry: { type: string; coordinates: unknown };
};
export type Geography = { features: Feature[] };
const W = 1000,
  H = 720;
function flatten(value: unknown): Point[] {
  if (!Array.isArray(value)) return [];
  if (typeof value[0] === "number") return [value as Point];
  return value.flatMap(flatten);
}
function mercator([lng, lat]: Point): Point {
  return [
    (lng * Math.PI) / 180,
    -Math.log(Math.tan(Math.PI / 4 + (lat * Math.PI) / 360)),
  ];
}
function pointsBounds(points: Point[]) {
  return {
    minX: Math.min(...points.map((p) => p[0])),
    maxX: Math.max(...points.map((p) => p[0])),
    minY: Math.min(...points.map((p) => p[1])),
    maxY: Math.max(...points.map((p) => p[1])),
  };
}
function geometryPath(value: unknown, project: (p: Point) => Point): string {
  if (!Array.isArray(value) || value.length === 0) return "";
  if (Array.isArray(value[0]) && typeof value[0][0] === "number")
    return (
      (value as Point[])
        .map(
          (p, i) =>
            `${i === 0 ? "M" : "L"}${project(p)
              .map((v) => v.toFixed(2))
              .join(",")}`,
        )
        .join("") + "Z"
    );
  return value.map((part) => geometryPath(part, project)).join("");
}
export function HeritageMap({
  geography,
  regions,
  brands,
  province,
  city,
  selectedId,
  onProvince,
  onCity,
  onBrand,
  onReset,
}: {
  geography: Geography;
  regions: Region[];
  brands: Brand[];
  province: string;
  city: string;
  selectedId?: string;
  onProvince: (p: string) => void;
  onCity: (c: string) => void;
  onBrand: (b: Brand) => void;
  onReset: () => void;
}) {
  const svgRef = useRef<SVGSVGElement>(null);
  const dragRef = useRef<{
    x: number;
    y: number;
    startX: number;
    startY: number;
  } | null>(null);
  const dragged = useRef(false);
  const [view, setView] = useState({ x: 0, y: 0, scale: 1 });
  const [dragging, setDragging] = useState(false);
  const [hover, setHover] = useState("");
  const [pixelScale, setPixelScale] = useState(1);
  useEffect(() => {
    const svg = svgRef.current;
    if (!svg) return;
    const observer = new ResizeObserver(() => {
      const rect = svg.getBoundingClientRect();
      if (rect.width && rect.height)
        setPixelScale(Math.min(rect.width / W, rect.height / H));
    });
    observer.observe(svg);
    return () => observer.disconnect();
  }, []);
  const { project, paths, centers } = useMemo(() => {
    const coords = geography.features
      .flatMap((f) => flatten(f.geometry.coordinates))
      .map(mercator);
    const b = pointsBounds(coords);
    const scale = Math.min(
      (W - 76) / (b.maxX - b.minX),
      (H - 60) / (b.maxY - b.minY),
    );
    const project = (point: Point): Point => {
      const [x, y] = mercator(point);
      return [
        (x - (b.minX + b.maxX) / 2) * scale + W / 2,
        (y - (b.minY + b.maxY) / 2) * scale + H / 2,
      ];
    };
    return {
      project,
      paths: geography.features.map((f) => ({
        feature: f,
        path: geometryPath(f.geometry.coordinates, project),
        bounds: pointsBounds(flatten(f.geometry.coordinates).map(project)),
      })),
      centers: new Map(
        geography.features
          .filter((f) => f.properties.center)
          .map((f) => [
            f.properties.name,
            project(f.properties.centroid || f.properties.center!),
          ]),
      ),
    };
  }, [geography]);
  useEffect(() => {
    const feature = province
      ? paths.find((p) => p.feature.properties.name === province)
      : undefined;
    if (!feature) {
      setView({ x: 0, y: 0, scale: 1 });
      return;
    }
    const b = feature.bounds;
    const scale = Math.min(
      6,
      Math.max(
        1.5,
        Math.min(
          650 / Math.max(20, b.maxX - b.minX),
          500 / Math.max(20, b.maxY - b.minY),
        ),
      ),
    );
    setView({
      scale,
      x: W / 2 - ((b.minX + b.maxX) / 2) * scale,
      y: H / 2 - ((b.minY + b.maxY) / 2) * scale,
    });
  }, [province, paths]);
  const groups = useMemo(() => {
    const map = new Map<string, Brand[]>();
    brands.forEach((b) => {
      const key = province ? b.city : b.province;
      map.set(key, [...(map.get(key) || []), b]);
    });
    return [...map.entries()]
      .map(([name, members]) => {
        const region = regions.find((r) => r.name === members[0].province);
        const location = province
          ? region?.cities.find((c) => c.name === name)?.center ||
            region?.center
          : null;
        const point = location ? project(location) : centers.get(name);
        return { name, members, point };
      })
      .filter((g): g is MapPlace => !!g.point);
  }, [brands, province, regions, project, centers]);
  const clusters = useMemo(
    () => clusterPlaces(groups, view.scale * pixelScale),
    [groups, view.scale, pixelScale],
  );
  function chooseCluster(cluster: PlaceCluster) {
    if (cluster.places.length > 1) {
      setView((v) => {
        const scale = Math.min(10, v.scale * 2);
        return {
          scale,
          x: W / 2 - cluster.point[0] * scale,
          y: H / 2 - cluster.point[1] * scale,
        };
      });
    } else if (!province) onProvince(cluster.name);
    else if (cluster.members.length === 1) onBrand(cluster.members[0]);
    else onCity(cluster.name);
  }
  const zoom = (factor: number) =>
    setView((v) => {
      const scale = Math.min(10, Math.max(0.8, v.scale * factor));
      const ratio = scale / v.scale;
      return {
        scale,
        x: W / 2 - (W / 2 - v.x) * ratio,
        y: H / 2 - (H / 2 - v.y) * ratio,
      };
    });
  const svgPoint = (x: number, y: number) => {
    const matrix = svgRef.current?.getScreenCTM()?.inverse();
    return matrix
      ? new DOMPoint(x, y).matrixTransform(matrix)
      : new DOMPoint(x, y);
  };
  return (
    <section className="map-panel" aria-label="老字号分布地图">
      <div className="map-heading">
        <span className="eyebrow">
          <span className="live-dot" /> 风物坐标
        </span>
        <span className="map-mode">
          {province ? shortRegion(province) : "全国"} ·{" "}
          {province ? "城市级分布" : "省级聚合"}
        </span>
      </div>
      <div className="map-stage">
        <div className="map-caption">
          <h3>
            {province
              ? `${shortRegion(province)}的老字号`
              : "一方风土，一份传承"}
          </h3>
          <p>
            {province
              ? "点击城市标记，发现当地品牌"
              : "点击省份或圆点，走近地方风物"}
          </p>
        </div>
        <svg
          ref={svgRef}
          viewBox={`0 0 ${W} ${H}`}
          className={`china-map ${dragging ? "dragging" : ""}`}
          aria-label="全国省级分布示意地图，位置并非实际门店地址"
          onPointerDown={(e) => {
            if (e.button !== 0) return;
            const p = svgPoint(e.clientX, e.clientY);
            dragRef.current = {
              x: p.x,
              y: p.y,
              startX: view.x,
              startY: view.y,
            };
            dragged.current = false;
          }}
          onPointerMove={(e) => {
            if (!dragRef.current) return;
            const p = svgPoint(e.clientX, e.clientY);
            const d = dragRef.current;
            if (Math.abs(p.x - d.x) + Math.abs(p.y - d.y) > 4) {
              dragged.current = true;
              setDragging(true);
              if (!e.currentTarget.hasPointerCapture(e.pointerId))
                e.currentTarget.setPointerCapture(e.pointerId);
              setView((v) => ({
                ...v,
                x: d.startX + p.x - d.x,
                y: d.startY + p.y - d.y,
              }));
            }
          }}
          onPointerUp={(e) => {
            dragRef.current = null;
            setDragging(false);
            if (e.currentTarget.hasPointerCapture(e.pointerId))
              e.currentTarget.releasePointerCapture(e.pointerId);
          }}
          onPointerCancel={() => {
            dragRef.current = null;
            dragged.current = false;
            setDragging(false);
          }}
        >
          <defs>
            <pattern
              id="map-grid"
              width="28"
              height="28"
              patternUnits="userSpaceOnUse"
            >
              <circle cx="1" cy="1" r=".7" fill="#789188" opacity=".14" />
            </pattern>
            <filter
              id="marker-shadow"
              x="-70%"
              y="-70%"
              width="240%"
              height="240%"
            >
              <feDropShadow
                dx="0"
                dy="3"
                stdDeviation="4"
                floodColor="#5c3924"
                floodOpacity=".2"
              />
            </filter>
          </defs>
          <rect width={W} height={H} fill="url(#map-grid)" />
          <g
            transform={`translate(${view.x} ${view.y}) scale(${view.scale})`}
            className={!dragging ? "map-transform" : ""}
          >
            {paths.map(({ feature: f, path }) => (
              <path
                key={f.properties.adcode}
                d={path}
                fillRule="evenodd"
                className={`province ${f.properties.name === province ? "selected" : ""} ${province && f.properties.name !== province ? "muted" : ""}`}
                strokeWidth={0.85 / view.scale}
                role={f.properties.name ? "button" : undefined}
                tabIndex={f.properties.name ? 0 : undefined}
                aria-label={
                  f.properties.name ? `选择${f.properties.name}` : undefined
                }
                onPointerEnter={() => setHover(f.properties.name)}
                onPointerLeave={() => setHover("")}
                onClick={() => {
                  if (!dragged.current && f.properties.name)
                    onProvince(f.properties.name);
                }}
                onKeyDown={(e) => {
                  if (
                    (e.key === "Enter" || e.key === " ") &&
                    f.properties.name
                  ) {
                    e.preventDefault();
                    onProvince(f.properties.name);
                  }
                }}
              >
                <title>{f.properties.name || "地图边界要素"}</title>
              </path>
            ))}
            {geography.features
              .filter(
                (f) =>
                  f.properties.name &&
                  (!province ||
                    f.properties.name === province ||
                    f.properties.name === hover),
              )
              .map((f) => {
                const p = centers.get(f.properties.name);
                return (
                  p && (
                    <text
                      key={f.properties.name}
                      x={p[0]}
                      y={p[1]}
                      className="province-label"
                      fontSize={12 / view.scale}
                      dy={-20 / view.scale}
                    >
                      {shortRegion(f.properties.name)}
                    </text>
                  )
                );
              })}
            {clusters.map((cluster) => {
              const { name, members, point, places } = cluster;
              const active =
                members.some((b) => b.id === selectedId) || name === city;
              return (
                <g
                  key={name}
                  className={`map-marker ${active ? "active" : ""}`}
                  role="button"
                  tabIndex={0}
                  aria-label={`${name}，${members.length}个品牌${places.length > 1 ? "，点击展开" : ""}`}
                  transform={`translate(${point[0]},${point[1]}) scale(${1 / (view.scale * pixelScale)})`}
                  onClick={(e) => {
                    e.stopPropagation();
                    if (!dragged.current) chooseCluster(cluster);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      chooseCluster(cluster);
                    }
                  }}
                >
                  <circle r="20" fill="transparent" />
                  <circle r="16" className="marker-halo" />
                  <circle
                    r={members.length > 3 ? 12 : 10}
                    className="marker-core"
                    filter="url(#marker-shadow)"
                  />
                  <text textAnchor="middle" dy="3.5" className="marker-number">
                    {members.length}
                  </text>
                  {province && places.length === 1 && (
                    <>
                      <rect
                        x={-Math.max(32, name.length * 6)}
                        y="19"
                        width={Math.max(64, name.length * 12)}
                        height="20"
                        rx="5"
                        fill="#fffdf6"
                        opacity=".95"
                      />
                      <text y="33" textAnchor="middle" className="city-label">
                        {shortRegion(name)}
                      </text>
                    </>
                  )}
                  <title>
                    {name}：{members.map((b) => b.name).join("、")}
                  </title>
                </g>
              );
            })}
          </g>
        </svg>
        <div className="map-compass" aria-hidden="true">
          <span>N</span>
          <Compass size={26} strokeWidth={1} />
        </div>
        <div className="map-controls">
          <button aria-label="放大地图" onClick={() => zoom(1.35)}>
            <Plus size={18} />
          </button>
          <button aria-label="缩小地图" onClick={() => zoom(1 / 1.35)}>
            <Minus size={18} />
          </button>
          <button
            aria-label="回到全国地图"
            onClick={() => {
              setView({ x: 0, y: 0, scale: 1 });
              onReset();
            }}
          >
            <RotateCcw size={17} />
          </button>
        </div>
        <div className="map-legend">
          <span>
            <i className="legend-dot" /> 已收录品牌
          </span>
          <span>
            <i className="legend-empty" /> 资料待补充
          </span>
        </div>
        <span className="map-drag-hint">
          <Move size={12} /> 拖动平移 · 按钮缩放
        </span>
      </div>
      <div className="map-attribution">
        <span>
          <MapPin size={12} /> 省市级示意，不是门店定位
        </span>
        <a
          href="https://datav.aliyun.com/portal/school/atlas/area_generator"
          target="_blank"
          rel="noopener noreferrer"
        >
          预览底图 © DataV GeoAtlas
        </a>
      </div>
    </section>
  );
}

from pathlib import Path
from typing import Any, Dict, List

from services.job_runner import list_recent_jobs, read_job_log, read_job_status, start_factory_job


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "out"
RELEASE_DIR = ROOT / "release"
ZIP_DIR = ROOT / "release_zips"


def submit_pipeline(params: Dict[str, Any]) -> str:
    return start_factory_job(params)


def get_job(job_id: str) -> Dict[str, Any]:
    return read_job_status(job_id)


def get_job_log(job_id: str, max_lines: int = 300) -> str:
    return read_job_log(job_id, max_lines=max_lines)


def recent_jobs(limit: int = 20) -> List[Dict[str, Any]]:
    return list_recent_jobs(limit=limit)


def list_outputs(limit: int = 80) -> List[Dict[str, Any]]:
    files: List[Path] = []
    for d in [ZIP_DIR, RELEASE_DIR, OUT_DIR]:
        if d.exists():
            files.extend([p for p in d.rglob("*") if p.is_file()])
    files.sort(key=lambda p: p.stat().st_mtime, reverse=True)

    out: List[Dict[str, Any]] = []
    for p in files[:limit]:
        out.append(
            {
                "name": p.name,
                "path": str(p),
                "size": p.stat().st_size,
                "mtime": p.stat().st_mtime,
                "relative": str(p.relative_to(ROOT)),
            }
        )
    return out

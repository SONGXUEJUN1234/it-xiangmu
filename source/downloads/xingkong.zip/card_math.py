"""球面坐标 -> 纸板孔位（毫米）。纯函数，无 IO。

约定（正确性命门，改动前先读）：
- angular_sep: 大圆角距，atan2 抗小角度精度损失写法。
- position_angle: 天文位置角 PA，自北向东（+RA 方向），0=北, 90=东。
- hole_positions 的手性见其 docstring。
"""
from math import atan2, cos, degrees, hypot, radians, sin, tan


def angular_sep(ra1, dec1, ra2, dec2):
    """两星角距（度）。输入赤经赤纬均为度。"""
    ra1, dec1, ra2, dec2 = map(radians, (ra1, dec1, ra2, dec2))
    dra = ra2 - ra1
    cos_rho = sin(dec1) * sin(dec2) + cos(dec1) * cos(dec2) * cos(dra)
    return degrees(atan2(
        hypot(
            cos(dec2) * sin(dra),
            cos(dec1) * sin(dec2) - sin(dec1) * cos(dec2) * cos(dra),
        ),
        cos_rho,
    ))


def position_angle(ra1, dec1, ra2, dec2):
    """星2 相对星1 的位置角（度，自北向东，返回 0-360）。"""
    ra1, dec1, ra2, dec2 = map(radians, (ra1, dec1, ra2, dec2))
    dra = ra2 - ra1
    pa = degrees(atan2(
        sin(dra) * cos(dec2),
        cos(dec1) * sin(dec2) - sin(dec1) * cos(dec2) * cos(dra),
    ))
    return pa % 360.0


def hole_positions(star_list, anchor_name, distance_mm):
    """以锚点星为原点计算每星孔位（毫米）。

    star_list: star_data.STARS[...]['stars'] 结构；anchor_name 指定锚点星。
    返回 [{'name', 'x', 'y'}...]，x 印刷面向右为正、y 向上为正，锚点在原点。

    手性（关键）：印刷面朝向眼睛时，图案必须与"仰视真实天空"同手性
    （北在上时天东在左，即活动星图的星空视角），否则图案与天空呈镜像，
    无论如何旋转卡片都套不上。故 x = -d*tan(rho)*sin(PA)。
    检验：以参宿四为锚点时，参宿七应落在印刷图右下方（冬夜面南实景）。
    """
    anchor = next(s for s in star_list if s["name"] == anchor_name)
    out = []
    for s in star_list:
        rho = radians(angular_sep(anchor["ra"], anchor["dec"], s["ra"], s["dec"]))
        pa = radians(position_angle(anchor["ra"], anchor["dec"], s["ra"], s["dec"]))
        out.append({
            "name": s["name"],
            "x": -distance_mm * tan(rho) * sin(pa),
            "y": distance_mm * tan(rho) * cos(pa),
        })
    return out

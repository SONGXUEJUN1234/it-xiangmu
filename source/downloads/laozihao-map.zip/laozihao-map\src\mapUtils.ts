import type { Brand } from "./model";
export type MapPlace = {
  name: string;
  members: Brand[];
  point: [number, number];
};
export type PlaceCluster = MapPlace & { places: MapPlace[] };

export function clusterPlaces(
  places: MapPlace[],
  unitsToPixels: number,
  radius = 29,
): PlaceCluster[] {
  const clusters: PlaceCluster[] = [];
  for (const place of places) {
    const existing = clusters.find(
      (c) =>
        Math.hypot(c.point[0] - place.point[0], c.point[1] - place.point[1]) *
          unitsToPixels <
        radius,
    );
    if (!existing) {
      clusters.push({ ...place, places: [place], members: [...place.members] });
      continue;
    }
    existing.places.push(place);
    existing.members.push(...place.members);
    existing.name = existing.places.map((p) => p.name).join("、");
    existing.point = [
      existing.places.reduce((sum, p) => sum + p.point[0], 0) /
        existing.places.length,
      existing.places.reduce((sum, p) => sum + p.point[1], 0) /
        existing.places.length,
    ];
  }
  return clusters;
}

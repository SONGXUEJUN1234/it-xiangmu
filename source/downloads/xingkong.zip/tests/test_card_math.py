"""card_math 单元测试：用合成星表测数学逻辑，不测真实星数据。"""
import math

from card_math import angular_sep, position_angle


def test_sep_equator_ten_deg():
    assert abs(angular_sep(0, 0, 10, 0) - 10.0) < 1e-6


def test_sep_zero_for_same_point():
    assert angular_sep(123.4, -56.7, 123.4, -56.7) < 1e-9


def test_sep_same_ra_dec_diff():
    assert abs(angular_sep(100, 10, 100, 40) - 30.0) < 1e-6


def test_sep_near_pole():
    # 两星 Dec=89.9 度、RA 相差 180 度 -> 角距约 0.2 度（球面特性）
    assert abs(angular_sep(0, 89.9, 180, 89.9) - 0.2) < 1e-3


def test_pa_east_on_equator():
    # 星2 在星1 正东（RA 更大、同 Dec）-> PA=90
    assert abs(position_angle(0, 0, 10, 0) - 90.0) < 1e-6


def test_pa_north_same_ra():
    assert abs(position_angle(0, 0, 0, 20) - 0.0) < 1e-6


def test_pa_west_on_equator():
    # 星2 在星1 正西（RA 更小、同 Dec）-> PA=270（覆盖 % 360 西向环绕分支）
    assert abs(position_angle(10, 0, 0, 0) - 270.0) < 1e-6


def test_pa_symmetry():
    # 往返位置角相差 180 仅在同子午圈（或赤道）上成立，一般球面位置不成立
    pa_ab = position_angle(100, 20, 100, -30)
    pa_ba = position_angle(100, -30, 100, 20)
    assert abs((pa_ab - pa_ba) % 360.0 - 180.0) < 1e-6


from card_math import hole_positions
from star_data import STARS

D = 100.0
STARS3 = [
    {"name": "A", "ra": 0, "dec": 0, "mag": 1.0},
    {"name": "B", "ra": 10, "dec": 0, "mag": 2.0},
    {"name": "C", "ra": 0, "dec": 20, "mag": 3.0},
]


def test_anchor_at_origin():
    pos = hole_positions(STARS3, "A", D)
    a = next(p for p in pos if p["name"] == "A")
    assert a["x"] == 0.0 and a["y"] == 0.0


def test_hole_radius_matches_tan_of_sep():
    pos = hole_positions(STARS3, "A", D)
    b = next(p for p in pos if p["name"] == "B")
    r = math.hypot(b["x"], b["y"])
    assert math.isclose(r, D * math.tan(math.radians(10.0)), abs_tol=1e-9)


def test_scale_linear_in_distance():
    p1 = hole_positions(STARS3, "A", D)
    p2 = hole_positions(STARS3, "A", 2 * D)
    b1 = next(p for p in p1 if p["name"] == "B")
    b2 = next(p for p in p2 if p["name"] == "B")
    assert abs(b2["x"] - 2 * b1["x"]) < 1e-9
    assert abs(b2["y"] - 2 * b1["y"]) < 1e-9


def test_print_chirality_matches_sky_view():
    """手性约定回归测试：印刷面朝眼时，参宿七必须在参宿四的右下方——
    与冬夜面南所见的真实猎户（红参宿四左上、蓝参宿七右下）一致。
    断言相对方向（约定逻辑），不断言毫米（数据）。"""
    pos = hole_positions(STARS["猎户座"]["stars"], "参宿四", D)
    rigel = next(p for p in pos if p["name"] == "参宿七")
    assert rigel["x"] > 0 and rigel["y"] < 0

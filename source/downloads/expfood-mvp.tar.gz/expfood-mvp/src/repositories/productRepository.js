const { paginate } = require("./paginate");

function createProductRepository({ products, seq, persistProduct, withProductLock }) {
  return {
    getByID(id) {
      return products.find((p) => p.id === id) || null;
    },
    listPublic({ keyword, page, pageSize, shopFilter }) {
      let list = products.filter((p) => p.status === 1);
      if (typeof shopFilter === "function") {
        list = list.filter((p) => shopFilter(p.shop_id));
      }
      if (keyword) {
        const kw = keyword.toLowerCase();
        list = list.filter((p) => String(p.name).toLowerCase().includes(kw));
      }
      list.sort((a, b) => b.id - a.id);
      return paginate(list, page, pageSize);
    },
    listByShop({ shopID, keyword, status, page, pageSize }) {
      let list = products.filter((p) => p.shop_id === shopID);
      if (status !== null && status !== undefined && status !== "") {
        list = list.filter((p) => p.status === Number(status));
      }
      if (keyword) {
        const kw = keyword.toLowerCase();
        list = list.filter((p) => String(p.name).toLowerCase().includes(kw));
      }
      list.sort((a, b) => b.id - a.id);
      return paginate(list, page, pageSize);
    },
    async create(payload) {
      const record = {
        id: seq.product++,
        ...payload,
      };
      products.push(record);
      await persistProduct(record);
      return record;
    },
    async updateByShop({ shopID, productID, patch }) {
      let updated = null;
      await withProductLock(productID, async () => {
        const p = products.find((item) => item.id === productID && item.shop_id === shopID);
        if (!p) return;

        if (patch.name !== undefined) p.name = String(patch.name || "").trim();
        if (patch.category_id !== undefined) p.category_id = Number(patch.category_id);
        if (patch.description !== undefined) p.description = String(patch.description || "");
        if (patch.images !== undefined && Array.isArray(patch.images)) p.images = patch.images;
        if (patch.detail_images !== undefined && Array.isArray(patch.detail_images)) p.detail_images = patch.detail_images;
        if (patch.ingredients !== undefined) p.ingredients = String(patch.ingredients || "");
        if (patch.allergen_info !== undefined) p.allergen_info = String(patch.allergen_info || "");
        if (patch.production_date !== undefined) p.production_date = String(patch.production_date || "");
        if (patch.best_before_date !== undefined) p.best_before_date = String(patch.best_before_date || "");
        if (patch.pickup_start_time !== undefined) p.pickup_start_time = String(patch.pickup_start_time || "");
        if (patch.pickup_end_time !== undefined) p.pickup_end_time = String(patch.pickup_end_time || "");
        if (patch.original_price !== undefined) p.original_price = Number(patch.original_price);
        if (patch.discount_price !== undefined) p.discount_price = Number(patch.discount_price);
        if (patch.discount !== undefined) p.discount = Number(patch.discount);
        if (patch.stock !== undefined) p.stock = Math.max(0, Number(patch.stock));
        if (patch.expire_time !== undefined) p.expire_time = String(patch.expire_time);
        if (patch.status !== undefined) {
          const nextStatus = Number(patch.status);
          if ([0, 1].includes(nextStatus)) p.status = nextStatus;
        }
        p.updated_at = new Date().toISOString();
        await persistProduct(p);
        updated = p;
      });
      return updated;
    },
    async setStatusByShop({ shopID, productID, status }) {
      const p = products.find((item) => item.id === productID && item.shop_id === shopID);
      if (!p) return null;
      p.status = Number(status);
      p.updated_at = new Date().toISOString();
      await persistProduct(p);
      return p;
    },
    async reserveStock({ productID, quantity }) {
      let product = null;
      let err = null;
      await withProductLock(productID, async () => {
        const p = products.find((item) => item.id === productID);
        if (!p || p.status !== 1) {
          err = { code: 404, message: "product not found", error_code: "PRODUCT_NOT_FOUND" };
          return;
        }
        if (p.stock < quantity) {
          err = { code: 409, message: "stock not enough", error_code: "ORDER_STOCK_NOT_ENOUGH" };
          return;
        }
        p.stock -= quantity;
        await persistProduct(p);
        product = p;
      });
      return { product, err };
    },
    async restoreStock({ productID, quantity }) {
      await withProductLock(productID, async () => {
        const p = products.find((item) => item.id === productID);
        if (!p) return;
        p.stock += quantity;
        await persistProduct(p);
      });
    },
  };
}

module.exports = { createProductRepository };

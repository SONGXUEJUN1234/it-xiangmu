import { asc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertPoem, InsertUser, poems, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
  values.lastSignedIn = user.lastSignedIn ?? new Date();
  updateSet.lastSignedIn = values.lastSignedIn;
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function listPoems() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(poems).orderBy(asc(poems.id));
}

export async function getPoemById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(poems).where(eq(poems.id, id)).limit(1);
  return result[0];
}

export async function upsertPoem(poem: InsertPoem) {
  const db = await getDb();
  if (!db) return;
  await db.insert(poems).values(poem).onDuplicateKeyUpdate({
    set: { title: poem.title, body: poem.body, form: poem.form, note: poem.note },
  });
}

export async function cacheInterpretation(id: number, interpretation: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(poems).set({ interpretation, interpretationUpdatedAt: new Date() }).where(eq(poems.id, id));
}

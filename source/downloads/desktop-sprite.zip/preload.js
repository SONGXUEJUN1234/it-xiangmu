const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('spriteAPI', {
  getConfig: () => ipcRenderer.invoke('get-config'),
  saveConfig: (config) => ipcRenderer.invoke('save-config', config),
  hide: () => ipcRenderer.send('hide-window'),
  onSayNow: (callback) => ipcRenderer.on('say-now', callback)
});

"""星表数据不变量：测结构规则，不测具体坐标数值。"""
from star_data import STARS


def test_every_constellation_has_valid_anchor():
    for name, c in STARS.items():
        names = [s["name"] for s in c["stars"]]
        assert c["anchor"] in names, f"{name} 的锚点不在星表内"


def test_coord_ranges_valid():
    for name, c in STARS.items():
        for s in c["stars"]:
            assert 0 <= s["ra"] < 360, (name, s["name"], "ra")
            assert -90 <= s["dec"] <= 90, (name, s["name"], "dec")
            assert 0 <= s["mag"] < 6, (name, s["name"], "mag")  # 城市裸眼可见上限


def test_star_names_unique_within_constellation():
    for name, c in STARS.items():
        names = [s["name"] for s in c["stars"]]
        assert len(names) == len(set(names)), name


def test_two_star_lock_feasible():
    """两星锁定法：锚点之外至少还有 1 颗星。"""
    for name, c in STARS.items():
        others = [s for s in c["stars"] if s["name"] != c["anchor"]]
        assert len(others) >= 1, name


def test_first_batch_constellations_present():
    """首批五个星座齐全（spec 第 3 节）。"""
    assert set(STARS) == {"猎户座", "北斗七星", "仙后座", "天鹅座", "天琴座"}

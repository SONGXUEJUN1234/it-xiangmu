# juben_release.py
# 一键发行包导出器：JSON -> DOCX + PDF + ZIP
# 输出：主持人本、角色本、线索卡（按编号/按回合+编号两份）、复盘手册、快速开本说明、商品文案草稿、原始JSON备份
#
# 依赖：
#   python -m pip install python-docx reportlab
#
# 用法：
#   python juben_release.py export <path_to_json>
#   python juben_release.py pack   <path_to_json>

import json
import re
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional

from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_BREAK
from docx.oxml.ns import qn

# ---- ReportLab（PDF）可选依赖：缺失时仍可导出DOCX和ZIP ----
_REPORTLAB_OK = True
try:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from reportlab.lib.units import mm
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.pdfbase.pdfmetrics import stringWidth
except Exception:
    _REPORTLAB_OK = False


# =========================
# 通用工具
# =========================

def safe_filename(name: str) -> str:
    name = (name or "").strip()
    name = re.sub(r'[\\/:*?"<>|]+', "_", name)
    return name[:80] if name else "untitled"

def load_json(p: Path) -> Dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))

def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)

def guess_title(data: Dict[str, Any]) -> str:
    return (data.get("meta", {}) or {}).get("title") or "剧本"

def guess_genre(data: Dict[str, Any]) -> str:
    return (data.get("meta", {}) or {}).get("genre") or "unknown"

def header_lines(data: Dict[str, Any]) -> List[str]:
    meta = data.get("meta", {}) or {}
    tags = meta.get("tags") or []
    out = [
        f"标题：{meta.get('title','')}",
        f"类型：{meta.get('genre','')}",
        f"人数：{meta.get('player_count','')}",
        f"时长：{meta.get('duration','')}",
        f"难度：{meta.get('difficulty','')}",
    ]
    if tags:
        out.append("标签：" + "，".join([str(x) for x in tags]))
    return out

def clue_num_key(clue: Dict[str, Any]) -> Tuple[int, str]:
    cid = str(clue.get("id", ""))
    digits = "".join([c for c in cid if c.isdigit()])
    try:
        n = int(digits) if digits else 0
    except Exception:
        n = 0
    return (n, cid)

def group_clues_by_round(data: Dict[str, Any]) -> Dict[int, List[Dict[str, Any]]]:
    grouped: Dict[int, List[Dict[str, Any]]] = {}
    for c in (data.get("clues") or []):
        r = c.get("appear_round", 1)
        try:
            r = int(r)
        except Exception:
            r = 1
        grouped.setdefault(r, []).append(c)
    for r in grouped:
        grouped[r] = sorted(grouped[r], key=clue_num_key)
    return dict(sorted(grouped.items(), key=lambda x: x[0]))


# =========================
# DOCX 导出（可装订）
# =========================

def docx_set_default_font(doc: Document, font_name: str = "Microsoft YaHei", font_size_pt: int = 12) -> None:
    style = doc.styles["Normal"]
    style.font.name = font_name
    style._element.rPr.rFonts.set(qn("w:eastAsia"), font_name)
    style.font.size = Pt(font_size_pt)

def docx_add_heading(doc: Document, text: str, level: int = 1) -> None:
    doc.add_heading(text, level=level)

def docx_add_paras(doc: Document, lines: List[str]) -> None:
    for line in lines:
        doc.add_paragraph(str(line))

def docx_page_break(doc: Document) -> None:
    p = doc.add_paragraph()
    run = p.add_run()
    run.add_break(WD_BREAK.PAGE)

def export_docx_host(data: Dict[str, Any], out_path: Path) -> None:
    doc = Document()
    docx_set_default_font(doc)

    docx_add_heading(doc, "主持人本（打印版）", 0)
    docx_add_paras(doc, header_lines(data))
    docx_page_break(doc)

    hs = data.get("host_script", {}) or {}
    structure = data.get("structure", {}) or {}
    rounds = structure.get("rounds") or []

    docx_add_heading(doc, "开场", 1)
    doc.add_paragraph(str(hs.get("opening", "")))
    docx_page_break(doc)

    docx_add_heading(doc, "回合结构", 1)
    if isinstance(rounds, list) and rounds:
        for i, r in enumerate(rounds, 1):
            docx_add_heading(doc, f"第{i}回合：{r.get('theme','')}", 2)
            if r.get("unlock_condition"):
                doc.add_paragraph("触发条件：" + str(r.get("unlock_condition")))
            if r.get("script_event"):
                doc.add_paragraph("剧情事件：" + str(r.get("script_event")))
            if r.get("actions"):
                doc.add_paragraph("行动：" + str(r.get("actions")))
            docx_page_break(doc)
    else:
        doc.add_paragraph("未提供 structure.rounds，本次线索将依赖 appear_round 分回合。")
        docx_page_break(doc)

    rg = hs.get("round_guidance") or []
    if rg:
        docx_add_heading(doc, "回合引导", 1)
        for i, g in enumerate(rg, 1):
            docx_add_heading(doc, f"第{i}轮引导", 2)
            doc.add_paragraph(str(g))
            docx_page_break(doc)

    docx_add_heading(doc, "结尾", 1)
    doc.add_paragraph(str(hs.get("ending", "")))

    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out_path))

def export_docx_roles(data: Dict[str, Any], out_dir: Path) -> None:
    chars = data.get("characters") or []
    ensure_dir(out_dir)

    for c in chars:
        name = c.get("name") or "角色"
        doc = Document()
        docx_set_default_font(doc)

        docx_add_heading(doc, f"角色本（打印版）：{name}", 0)
        docx_add_paras(doc, header_lines(data))
        docx_page_break(doc)

        docx_add_heading(doc, "公开背景", 1)
        doc.add_paragraph(str(c.get("public_background", "")))
        docx_page_break(doc)

        docx_add_heading(doc, "你的秘密", 1)
        doc.add_paragraph(str(c.get("secret", "")))
        docx_page_break(doc)

        docx_add_heading(doc, "你的目标", 1)
        doc.add_paragraph(str(c.get("goal", "")))
        docx_page_break(doc)

        rm = c.get("relationship_map") or {}
        if isinstance(rm, dict) and rm:
            docx_add_heading(doc, "关系", 1)
            for k, v in rm.items():
                doc.add_paragraph(f"{k}：{v}")
            docx_page_break(doc)

        ke = c.get("key_evidence") or []
        if isinstance(ke, list) and ke:
            docx_add_heading(doc, "你掌握的关键物件或信息", 1)
            for item in ke:
                doc.add_paragraph(f"- {item}")
            docx_page_break(doc)

        doc.save(str(out_dir / f"{safe_filename(name)}_打印版.docx"))

def export_docx_clues(data: Dict[str, Any], out_dir: Path, mode: str) -> Path:
    ensure_dir(out_dir)
    doc = Document()
    docx_set_default_font(doc)

    title = "线索卡（按编号排序 打印版）" if mode == "number" else "线索卡（按回合+编号排序 打印版）"
    docx_add_heading(doc, title, 0)
    docx_add_paras(doc, header_lines(data))
    docx_page_break(doc)

    clues = data.get("clues") or []

    if mode == "number":
        ordered = sorted(clues, key=clue_num_key)
        for clue in ordered:
            docx_add_heading(doc, f"线索 {clue.get('id','')}", 1)
            doc.add_paragraph(f"类型：{clue.get('type','')}")
            doc.add_paragraph(f"出现回合：{clue.get('appear_round','')}")
            doc.add_paragraph(f"强度：{clue.get('strength','')}")
            doc.add_paragraph(f"误导：{clue.get('misleading', False)}")
            doc.add_paragraph("内容：")
            doc.add_paragraph(str(clue.get("content", "")))
            docx_page_break(doc)
        out_path = out_dir / "线索卡_按编号排序_打印版.docx"
        doc.save(str(out_path))
        return out_path

    grouped = group_clues_by_round(data)
    for r, items in grouped.items():
        for clue in items:
            docx_add_heading(doc, f"第{r}回合 线索 {clue.get('id','')}", 1)
            doc.add_paragraph(f"类型：{clue.get('type','')}")
            doc.add_paragraph(f"强度：{clue.get('strength','')}")
            doc.add_paragraph(f"误导：{clue.get('misleading', False)}")
            doc.add_paragraph("内容：")
            doc.add_paragraph(str(clue.get("content", "")))
            docx_page_break(doc)

    out_path = out_dir / "线索卡_按回合排序_打印版.docx"
    doc.save(str(out_path))
    return out_path

def export_docx_review(data: Dict[str, Any], out_path: Path) -> None:
    doc = Document()
    docx_set_default_font(doc)

    docx_add_heading(doc, "复盘手册（打印版）", 0)
    docx_add_paras(doc, header_lines(data))
    docx_page_break(doc)

    meta = data.get("meta", {}) or {}
    genre = meta.get("genre", "")
    tc = data.get("truth_core", {}) or {}
    structure = data.get("structure", {}) or {}
    mech = structure.get("mechanics", "")
    phase = structure.get("phase_design", "")

    docx_add_heading(doc, "真相核心", 1)
    if tc.get("real_story"):
        doc.add_paragraph("真实故事：")
        doc.add_paragraph(str(tc.get("real_story")))
        docx_page_break(doc)
    if tc.get("killer"):
        doc.add_paragraph("关键人物：" + str(tc.get("killer")))
    if tc.get("crime_method"):
        doc.add_paragraph("关键手法：")
        doc.add_paragraph(str(tc.get("crime_method")))
        docx_page_break(doc)
    if tc.get("motive_structure"):
        doc.add_paragraph("动机结构：")
        doc.add_paragraph(str(tc.get("motive_structure")))
        docx_page_break(doc)
    if tc.get("hidden_twist"):
        doc.add_paragraph("隐藏反转：")
        doc.add_paragraph(str(tc.get("hidden_twist")))
        docx_page_break(doc)

    tl = tc.get("timeline") or []
    if tl:
        docx_add_heading(doc, "时间线", 1)
        for t in tl:
            doc.add_paragraph(str(t))
        docx_page_break(doc)

    if genre == "mechanism":
        docx_add_heading(doc, "阵营机制与结算", 1)
        if isinstance(mech, dict):
            doc.add_paragraph(json.dumps(mech, ensure_ascii=False, indent=2))
        else:
            doc.add_paragraph(str(mech))
        docx_page_break(doc)

    if genre == "emotional":
        docx_add_heading(doc, "情绪曲线与爆点", 1)
        if isinstance(phase, dict):
            doc.add_paragraph(json.dumps(phase, ensure_ascii=False, indent=2))
        else:
            doc.add_paragraph(str(phase))
        docx_page_break(doc)

    if genre == "horror":
        docx_add_heading(doc, "恐怖还原复盘话术建议", 1)
        doc.add_paragraph("建议顺序：怪谈总述 → 证据拆解 → 现实原因与动机揭示。")
        docx_page_break(doc)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out_path))

def export_docx_quickstart_and_listing(data: Dict[str, Any], out_dir: Path) -> None:
    ensure_dir(out_dir)
    meta = data.get("meta", {}) or {}
    title = meta.get("title", "")
    genre = meta.get("genre", "")
    players = meta.get("player_count", "")
    duration = meta.get("duration", "")
    difficulty = meta.get("difficulty", "")
    tags = meta.get("tags") or []

    doc = Document()
    docx_set_default_font(doc)
    docx_add_heading(doc, "快速开本说明（给主持人）", 0)
    doc.add_paragraph(f"标题：{title}")
    doc.add_paragraph(f"类型：{genre}    人数：{players}    时长：{duration}    难度：{difficulty}")
    if tags:
        doc.add_paragraph("标签：" + "，".join([str(x) for x in tags]))
    docx_page_break(doc)

    docx_add_heading(doc, "你需要准备", 1)
    doc.add_paragraph("1 打印：主持人本_打印版、每人一份角色本_打印版、线索卡_打印版（按编号或按回合二选一）。")
    doc.add_paragraph("2 现场：笔、纸、计时器，建议准备投票纸。")
    doc.add_paragraph("3 节奏：第1回合铺设设定与怀疑，第2回合推证据闭环，第3回合收束与复盘。")
    docx_page_break(doc)

    docx_add_heading(doc, "常见卡点提示策略", 1)
    doc.add_paragraph("轻提示：提醒玩家回看时间线与关键物证。")
    doc.add_paragraph("中提示：引导玩家把两条线索做组合验证。")
    doc.add_paragraph("重提示：由主持人复述关键事实并明确冲突点。")
    doc.save(str(out_dir / "快速开本说明.docx"))

    doc2 = Document()
    docx_set_default_font(doc2)
    docx_add_heading(doc2, "商品文案草稿", 0)
    doc2.add_paragraph(f"《{title}》")
    doc2.add_paragraph(f"{genre}｜{players}人｜{duration}｜难度{difficulty}")
    if tags:
        doc2.add_paragraph("关键词：" + " / ".join([str(x) for x in tags]))
    doc2.add_paragraph("")
    doc2.add_paragraph("一句话卖点：")
    doc2.add_paragraph("把你最独特的机制或反转浓缩成一句话。")
    doc2.add_paragraph("")
    doc2.add_paragraph("亮点：")
    doc2.add_paragraph("1 线索闭环与推理爽感")
    doc2.add_paragraph("2 分回合节奏清晰，主持易上手")
    doc2.add_paragraph("3 复盘层次分明，结尾有回响")
    doc2.add_paragraph("")
    doc2.add_paragraph("内容构成：主持人本、角色本、线索卡、复盘手册、开本说明。")
    doc2.save(str(out_dir / "商品文案草稿.docx"))


# =========================
# PDF 导出（中文字体 + 自动换行）
# =========================

def register_cjk_font(prefer: str = "msyh") -> str:
    """
    Windows中文字体注册：优先微软雅黑，其次宋体/黑体。
    返回可用字体名，失败则回退 Helvetica（中文会方块）。
    """
    if not _REPORTLAB_OK:
        return "Helvetica"

    candidates = [
        ("CJK_MSYH", r"C:\Windows\Fonts\msyh.ttc", 0),     # 微软雅黑
        ("CJK_MSYH_UI", r"C:\Windows\Fonts\msyh.ttc", 1),
        ("CJK_SIMSUN", r"C:\Windows\Fonts\simsun.ttc", 0), # 宋体
        ("CJK_SIMHEI", r"C:\Windows\Fonts\simhei.ttf", 0), # 黑体
        ("CJK_YAHEI", r"C:\Windows\Fonts\msyh.ttf", 0),
    ]

    prefer = (prefer or "").lower().strip()
    if prefer == "simsun":
        candidates = [candidates[2]] + [c for i, c in enumerate(candidates) if i != 2]
    if prefer == "simhei":
        candidates = [candidates[3]] + [c for i, c in enumerate(candidates) if i != 3]

    for font_name, font_path, sub_idx in candidates:
        try:
            if Path(font_path).exists():
                pdfmetrics.registerFont(TTFont(font_name, font_path, subfontIndex=sub_idx))
                return font_name
        except Exception:
            continue

    return "Helvetica"

@dataclass
class PdfStyle:
    page_size: Tuple[int, int] = (0, 0)
    left: float = 0.0
    right: float = 0.0
    top: float = 0.0
    bottom: float = 0.0
    font: str = "Helvetica"
    font_size: int = 11
    leading: int = 15

def _wrap_line(text: str, font: str, font_size: int, max_width: float) -> List[str]:
    """
    用 reportlab 的 stringWidth 按实际宽度切行，兼容中文。
    """
    if not text:
        return [""]

    out: List[str] = []
    cur = ""
    for ch in text:
        candidate = cur + ch
        w = stringWidth(candidate, font, font_size) if _REPORTLAB_OK else len(candidate) * font_size
        if w <= max_width or not cur:
            cur = candidate
        else:
            out.append(cur)
            cur = ch
    if cur:
        out.append(cur)
    return out

def pdf_draw_sections(out_path: Path, sections: List[Tuple[str, List[str]]], prefer_font: str = "msyh") -> None:
    if not _REPORTLAB_OK:
        return

    cjk_font = register_cjk_font(prefer_font)
    page_w, page_h = A4
    style = PdfStyle(
        page_size=A4,
        left=18 * mm,
        right=18 * mm,
        top=18 * mm,
        bottom=18 * mm,
        font=cjk_font,
        font_size=11,
        leading=15
    )

    out_path.parent.mkdir(parents=True, exist_ok=True)
    c = canvas.Canvas(str(out_path), pagesize=style.page_size)
    c.setTitle(out_path.stem)

    def new_page():
        c.showPage()
        c.setFont(style.font, style.font_size)

    c.setFont(style.font, style.font_size)
    first_section = True

    for sec_title, lines in sections:
        if not first_section:
            new_page()
        first_section = False

        x = style.left
        y = page_h - style.top
        max_width = page_w - style.left - style.right

        # 标题
        c.setFont(style.font, style.font_size + 3)
        for tline in _wrap_line(sec_title, style.font, style.font_size + 3, max_width):
            c.drawString(x, y, tline)
            y -= style.leading * 1.2
            if y < style.bottom:
                new_page()
                y = page_h - style.top
        y -= style.leading * 0.6
        c.setFont(style.font, style.font_size)

        # 正文
        for raw in lines:
            text = "" if raw is None else str(raw)

            if text == "__PAGE__":
                new_page()
                y = page_h - style.top
                continue

            # 段落内换行
            for para in text.splitlines() if text else [""]:
                wrapped = _wrap_line(para, style.font, style.font_size, max_width)
                for wline in wrapped:
                    c.drawString(x, y, wline)
                    y -= style.leading
                    if y < style.bottom:
                        new_page()
                        y = page_h - style.top
                # 段落间空行
                y -= style.leading * 0.3
                if y < style.bottom:
                    new_page()
                    y = page_h - style.top

    c.save()

def build_pdf_sections_host(data: Dict[str, Any]) -> List[Tuple[str, List[str]]]:
    hs = data.get("host_script", {}) or {}
    structure = data.get("structure", {}) or {}
    rounds = structure.get("rounds") or []
    rg = hs.get("round_guidance") or []

    sections: List[Tuple[str, List[str]]] = []
    sections.append(("主持人本（打印版）", header_lines(data)))
    sections.append(("开场", [str(hs.get("opening",""))]))

    if isinstance(rounds, list) and rounds:
        for i, r in enumerate(rounds, 1):
            lines = []
            if r.get("unlock_condition"):
                lines.append("触发条件：" + str(r.get("unlock_condition")))
            if r.get("script_event"):
                lines.append("剧情事件：" + str(r.get("script_event")))
            if r.get("actions"):
                lines.append("行动：" + str(r.get("actions")))
            sections.append((f"第{i}回合：{r.get('theme','')}", lines or ["（无）"]))
    else:
        sections.append(("回合结构", ["未提供 structure.rounds，线索将按 appear_round 分组。"]))

    if rg:
        for i, g in enumerate(rg, 1):
            sections.append((f"第{i}轮引导", [str(g)]))

    sections.append(("结尾", [str(hs.get("ending",""))]))
    return sections

def build_pdf_sections_review(data: Dict[str, Any]) -> List[Tuple[str, List[str]]]:
    meta = data.get("meta", {}) or {}
    genre = meta.get("genre","")
    tc = data.get("truth_core", {}) or {}
    structure = data.get("structure", {}) or {}
    mech = structure.get("mechanics", "")
    phase = structure.get("phase_design", "")

    sections: List[Tuple[str, List[str]]] = []
    sections.append(("复盘手册（打印版）", header_lines(data)))

    core: List[str] = []
    if tc.get("real_story"):
        core += ["真实故事：", str(tc.get("real_story")), ""]
    if tc.get("killer"):
        core += ["关键人物：" + str(tc.get("killer")), ""]
    if tc.get("crime_method"):
        core += ["关键手法：", str(tc.get("crime_method")), ""]
    if tc.get("motive_structure"):
        core += ["动机结构：", str(tc.get("motive_structure")), ""]
    if tc.get("hidden_twist"):
        core += ["隐藏反转：", str(tc.get("hidden_twist")), ""]
    sections.append(("真相核心", core or ["（空）"]))

    tl = tc.get("timeline") or []
    if tl:
        sections.append(("时间线", [str(x) for x in tl]))

    if genre == "mechanism":
        body = json.dumps(mech, ensure_ascii=False, indent=2) if isinstance(mech, dict) else str(mech)
        sections.append(("阵营机制与结算", [body]))

    if genre == "emotional":
        body = json.dumps(phase, ensure_ascii=False, indent=2) if isinstance(phase, dict) else str(phase)
        sections.append(("情绪曲线与爆点", [body]))

    if genre == "horror":
        sections.append(("恐怖还原复盘话术建议", ["建议顺序：怪谈总述 → 证据拆解 → 现实原因与动机揭示。"]))

    return sections

def build_pdf_sections_role(data: Dict[str, Any], c: Dict[str, Any]) -> List[Tuple[str, List[str]]]:
    name = c.get("name") or "角色"
    sections: List[Tuple[str, List[str]]] = []
    sections.append((f"角色本（打印版）：{name}", header_lines(data)))
    sections.append(("公开背景", [str(c.get("public_background",""))]))
    sections.append(("你的秘密", [str(c.get("secret",""))]))
    sections.append(("你的目标", [str(c.get("goal",""))]))

    rm = c.get("relationship_map") or {}
    if isinstance(rm, dict) and rm:
        lines = [f"{k}：{v}" for k, v in rm.items()]
        sections.append(("关系", lines))

    ke = c.get("key_evidence") or []
    if isinstance(ke, list) and ke:
        sections.append(("你掌握的关键物件或信息", [f"- {x}" for x in ke]))

    return sections

def build_pdf_sections_clues(data: Dict[str, Any], mode: str) -> List[Tuple[str, List[str]]]:
    clues = data.get("clues") or []
    sections: List[Tuple[str, List[str]]] = []
    title = "线索卡（按编号排序 打印版）" if mode == "number" else "线索卡（按回合+编号排序 打印版）"
    sections.append((title, header_lines(data)))

    if mode == "number":
        ordered = sorted(clues, key=clue_num_key)
        for clue in ordered:
            lines = [
                f"类型：{clue.get('type','')}",
                f"出现回合：{clue.get('appear_round','')}",
                f"强度：{clue.get('strength','')}",
                f"误导：{clue.get('misleading', False)}",
                "",
                "内容：",
                str(clue.get("content","")),
            ]
            sections.append((f"线索 {clue.get('id','')}", lines))
        return sections

    grouped = group_clues_by_round(data)
    for r, items in grouped.items():
        for clue in items:
            lines = [
                f"回合：{r}",
                f"类型：{clue.get('type','')}",
                f"强度：{clue.get('strength','')}",
                f"误导：{clue.get('misleading', False)}",
                "",
                "内容：",
                str(clue.get("content","")),
            ]
            sections.append((f"第{r}回合 线索 {clue.get('id','')}", lines))
    return sections


# =========================
# ZIP 打包
# =========================

def zip_dir(src_dir: Path, zip_path: Path) -> None:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(str(zip_path), "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in src_dir.rglob("*"):
            if p.is_file():
                zf.write(str(p), str(p.relative_to(src_dir)))


# =========================
# 主命令
# =========================

def cmd_export(json_path: Path) -> Path:
    data = load_json(json_path)
    title = safe_filename(guess_title(data))
    genre = safe_filename(guess_genre(data))

    base_dir = Path("release") / f"{title}_{genre}"
    ensure_dir(base_dir)

    # DOCX
    export_docx_host(data, base_dir / "主持人本_打印版.docx")
    export_docx_roles(data, base_dir / "角色本_打印版")
    export_docx_clues(data, base_dir / "线索卡_打印版", mode="number")
    export_docx_clues(data, base_dir / "线索卡_打印版", mode="round")
    export_docx_review(data, base_dir / "复盘手册_打印版.docx")
    export_docx_quickstart_and_listing(data, base_dir)

    # PDF（含中文字体）
    if _REPORTLAB_OK:
        pdf_draw_sections(base_dir / "主持人本_打印版.pdf", build_pdf_sections_host(data), prefer_font="msyh")
        pdf_draw_sections(base_dir / "复盘手册_打印版.pdf", build_pdf_sections_review(data), prefer_font="msyh")
        pdf_draw_sections(base_dir / "线索卡_按编号排序_打印版.pdf", build_pdf_sections_clues(data, "number"), prefer_font="msyh")
        pdf_draw_sections(base_dir / "线索卡_按回合排序_打印版.pdf", build_pdf_sections_clues(data, "round"), prefer_font="msyh")

        role_pdf_dir = base_dir / "角色本_打印版_PDF"
        ensure_dir(role_pdf_dir)
        for c in (data.get("characters") or []):
            name = safe_filename(c.get("name") or "角色")
            pdf_draw_sections(role_pdf_dir / f"{name}_打印版.pdf", build_pdf_sections_role(data, c), prefer_font="msyh")
    else:
        # 没装reportlab时：保留导出目录结构，方便你后续补装再生成PDF
        (base_dir / "PDF未生成_请安装reportlab.txt").write_text(
            "当前环境缺少 reportlab，已跳过PDF导出。\n运行：python -m pip install reportlab\n然后重新执行 pack/export。\n",
            encoding="utf-8"
        )

    # 原始 JSON 备份
    (base_dir / "原始JSON").mkdir(exist_ok=True)
    (base_dir / "原始JSON" / json_path.name).write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

    return base_dir

def cmd_pack(json_path: Path) -> Path:
    base_dir = cmd_export(json_path)
    zip_name = safe_filename(base_dir.name) + "_发行包.zip"
    zip_path = Path("release_zips") / zip_name
    zip_dir(base_dir, zip_path)
    return zip_path

def main():
    if len(sys.argv) < 3:
        print("用法：")
        print("  python juben_release.py export <path_to_json>")
        print("  python juben_release.py pack   <path_to_json>")
        sys.exit(1)

    action = sys.argv[1].strip().lower()
    json_path = Path(sys.argv[2])

    if not json_path.exists():
        print("找不到文件：", json_path)
        sys.exit(1)

    if action == "export":
        out_dir = cmd_export(json_path)
        print("导出完成：", out_dir)
        return

    if action == "pack":
        zip_path = cmd_pack(json_path)
        print("发行包已生成：", zip_path)
        return

    print("未知命令：", action)
    sys.exit(1)

if __name__ == "__main__":
    main()
/* 设计提醒：车窗里的歌——纸质歌单、铁路双轨、信号橙仅作为播放动作；以外链式正版试听替代盗链音频。 */
import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { ExternalLink, Search, TrainFront, Volume2, X } from "lucide-react";

type Track = {
  no: string;
  title: string;
  artist: string;
  album: string;
  bookClue: string;
  verification: "书内明示" | "书内线索 · 已交叉核验";
  platform: string;
  href: string;
};

const tracks: Track[] = [
  { no: "01", title: "恩惠", artist: "左小祖咒", album: "我不能悲伤地坐在你身旁", bookClue: "第二篇篇名直接写作〈左小祖咒的《恩惠》〉。", verification: "书内明示", platform: "Apple Music 试听", href: "https://music.apple.com/tw/song/%E6%81%A9%E6%83%A0/1508469517" },
  { no: "02", title: "米店", artist: "张玮玮", album: "白银饭店", bookClue: "第二篇〈白银米店〉的正文线索；周云蓬公开文章明确提及此曲。", verification: "书内线索 · 已交叉核验", platform: "官方平台搜索", href: "https://y.qq.com/n/ryqq/search?w=%E5%BC%A0%E7%8E%AE%E7%8E%AE%20%E7%B1%B3%E5%BA%97" },
  { no: "03", title: "小牛和小燕子 Donna Donna", artist: "周云蓬、Anais Martane 安娜", album: "同名单曲", bookClue: "第四篇含〈小牛和小燕子〉篇目；公开单曲页显示合作演唱。", verification: "书内线索 · 已交叉核验", platform: "Apple Music 试听", href: "https://music.apple.com/us/album/%E5%B0%8F%E7%89%9B%E5%92%8C%E5%B0%8F%E7%87%95%E5%AD%90-donna-donna-single/1778215649" },
  { no: "04", title: "余秀华之歌", artist: "周云蓬", album: "同名单曲", bookClue: "第四篇含同名篇目；公开单曲页可核对演唱者。", verification: "书内线索 · 已交叉核验", platform: "Apple Music 试听", href: "https://music.apple.com/cn/album/%E4%BD%99%E7%A7%80%E8%8F%AF%E4%B9%8B%E6%AD%8C-single/1763584546" },
  { no: "05", title: "闪念", artist: "周云蓬、图灵音乐实验室", album: "同名单曲", bookClue: "第四篇含同名篇目；公开单曲页显示合作音乐人。", verification: "书内线索 · 已交叉核验", platform: "Apple Music 试听", href: "https://music.apple.com/us/album/%E9%96%83%E5%BF%B5-single/1742914637" },
  { no: "06", title: "瓦尔登湖", artist: "周云蓬", album: "瓦尔登湖", bookClue: "第四篇含同名篇目；官方专辑页列为曲目。", verification: "书内线索 · 已交叉核验", platform: "Apple Music 试听", href: "https://music.apple.com/us/album/%E7%93%A6%E7%88%BE%E7%99%BB%E6%B9%96/1648653838" },
  { no: "07", title: "失明的城市", artist: "周云蓬", album: "瓦尔登湖", bookClue: "第四篇含同名篇目；官方专辑页列为曲目。", verification: "书内线索 · 已交叉核验", platform: "Apple Music 试听", href: "https://music.apple.com/us/album/%E7%93%A6%E7%88%BE%E7%99%BB%E6%B9%96/1648653838" },
  { no: "08", title: "小王子", artist: "周云蓬", album: "瓦尔登湖", bookClue: "第四篇含同名篇目；官方专辑页列为曲目。", verification: "书内线索 · 已交叉核验", platform: "Apple Music 试听", href: "https://music.apple.com/us/album/%E7%93%A6%E7%88%BE%E7%99%BB%E6%B9%96/1648653838" },
  { no: "09", title: "盲人影院", artist: "周云蓬", album: "沉默如谜的呼吸", bookClue: "第四篇含同名篇目；公开曲目资料可核对。", verification: "书内线索 · 已交叉核验", platform: "Spotify 试听", href: "https://open.spotify.com/track/0C7m0AAXSkGHbQnhm9WOhf" },
  { no: "10", title: "沉默如谜的呼吸", artist: "周云蓬", album: "沉默如谜的呼吸", bookClue: "第四篇含同名篇目；同名专辑公开发行资料可核对。", verification: "书内线索 · 已交叉核验", platform: "官方平台搜索", href: "https://y.qq.com/n/ryqq/search?w=%E5%91%A8%E4%BA%91%E8%93%AC%20%E6%B2%89%E9%BB%98%E5%A6%82%E8%B0%9C%E7%9A%84%E5%91%BC%E5%90%B8" },
  { no: "11", title: "幻觉支撑我们活下去", artist: "周云蓬", album: "沉默如谜的呼吸", bookClue: "第四篇含同名篇目；公开曲目资料可核对。", verification: "书内线索 · 已交叉核验", platform: "Spotify 试听", href: "https://open.spotify.com/track/6LRo9AlBdHMr9tRdn1YXqm" },
  { no: "12", title: "空水杯", artist: "周云蓬", album: "清炒苦瓜", bookClue: "第四篇含同名篇目；公开单曲页可核对演唱者与专辑。", verification: "书内线索 · 已交叉核验", platform: "Apple Music 试听", href: "https://music.apple.com/tw/song/%E7%A9%BA%E6%B0%B4%E6%9D%AF/1648654927" },
  { no: "13", title: "鱼相忘于江湖", artist: "周云蓬", album: "清炒苦瓜", bookClue: "第四篇含同名篇目；公开单曲页可核对演唱者与专辑。", verification: "书内线索 · 已交叉核验", platform: "Apple Music 试听", href: "https://music.apple.com/cn/song/%E9%B1%BC%E7%9B%B8%E5%BF%98%E4%BA%8E%E6%B1%9F%E6%B9%96/1648654930" },
  { no: "14", title: "山鬼", artist: "周云蓬", album: "清炒苦瓜", bookClue: "第四篇含同名篇目；公开单曲页可核对演唱者与专辑。", verification: "书内线索 · 已交叉核验", platform: "Apple Music 试听", href: "https://music.apple.com/tw/song/%E5%B1%B1%E9%AC%BC/1648654931" },
  { no: "15", title: "吹不散的烟", artist: "周云蓬", album: "现场版本", bookClue: "第四篇含同名篇目；公开演出视频可核对曲名与演唱者。", verification: "书内线索 · 已交叉核验", platform: "YouTube 演出视频", href: "https://www.youtube.com/watch?v=8y7GKNyrGP0" },
  { no: "16", title: "北京三次", artist: "周云蓬", album: "现场曲目", bookClue: "第四篇含同名篇目；公开电台现场曲目单可核对。", verification: "书内线索 · 已交叉核验", platform: "官方平台搜索", href: "https://y.qq.com/n/ryqq/search?w=%E5%91%A8%E4%BA%91%E8%93%AC%20%E5%8C%97%E4%BA%AC%E4%B8%89%E6%AC%A1" },
  { no: "17", title: "不会说话的爱情", artist: "周云蓬", album: "牛羊下山", bookClue: "第四篇含同名篇目；公开曲目资料归于《牛羊下山》。", verification: "书内线索 · 已交叉核验", platform: "Apple Music 试听", href: "https://music.apple.com/cn/song/%E4%B8%8D%E4%BC%9A%E8%AF%B4%E8%AF%9D%E7%9A%84%E7%88%B1%E6%83%85/1649724200" },
  { no: "18", title: "随心所欲", artist: "周云蓬", album: "四月旧州", bookClue: "第四篇含同名篇目；并与第二篇〈《四月旧州》记〉相互印证。", verification: "书内线索 · 已交叉核验", platform: "Apple Music 试听", href: "https://music.apple.com/us/album/%E5%9B%9B%E6%9C%88%E8%88%8A%E5%B7%9E/1648109772?l=zh-Hans-CN" },
  { no: "19", title: "北极光", artist: "周云蓬", album: "四月旧州", bookClue: "第四篇含同名篇目；官方专辑页可核对。", verification: "书内线索 · 已交叉核验", platform: "Apple Music 试听", href: "https://music.apple.com/us/album/%E5%9B%9B%E6%9C%88%E8%88%8A%E5%B7%9E/1648109772?l=zh-Hans-CN" },
  { no: "20", title: "散场曲", artist: "周云蓬", album: "四月旧州", bookClue: "第四篇含同名篇目；官方专辑页可核对。", verification: "书内线索 · 已交叉核验", platform: "Apple Music 试听", href: "https://music.apple.com/us/album/%E5%9B%9B%E6%9C%88%E8%88%8A%E5%B7%9E/1648109772?l=zh-Hans-CN" },
  { no: "21", title: "黄河谣 (Live)", artist: "野孩子", album: "黄河谣", bookClue: "第三篇含〈野孩子：大河之上〉篇目；用户指定补入，官方专辑页可核对。", verification: "书内线索 · 已交叉核验", platform: "Apple Music 试听", href: "https://music.apple.com/cn/song/%E9%BB%84%E6%B2%B3%E8%B0%A3-live/1718666015" },
  { no: "22", title: "九月 (Live)", artist: "周云蓬", album: "我们民谣2022 第3期 (Live)", bookClue: "用户指定补入；周云蓬公开现场录音与书中民谣路线相连。", verification: "书内线索 · 已交叉核验", platform: "Apple Music 试听", href: "https://music.apple.com/cl/song/%E4%B9%9D%E6%9C%88-live/1852185222" },
  { no: "23", title: "倒淌河", artist: "张浅潜", album: "游吟者1997", bookClue: "第三篇含〈想念一条倒淌河〉篇目；用户指定补入，公开单曲页可核对。", verification: "书内线索 · 已交叉核验", platform: "Apple Music 试听", href: "https://music.apple.com/us/song/%E5%80%92%E6%B7%8C%E6%B2%B3/1808905953" },
];

const stationNotes = [
  { title: "01 · 雨落在车窗上", text: "有些歌不急着抵达，它们只是陪你把夜色坐长一点。" },
  { title: "02 · 远方站台", text: "火车停靠的时候，风会替我们把没说完的话带走。" },
  { title: "03 · 山路微亮", text: "在民谣里，孤独不是终点，是人和世界重新相认的方式。" },
  { title: "04 · 黎明前一站", text: "把最后一首歌留给天色，留给仍在行走的人。" },
];

function TrainMark({ decorative = false, className = "" }: { decorative?: boolean; className?: string }) {
  return <span className={`train-mark ${className}`} role={decorative ? undefined : "img"} aria-label={decorative ? undefined : "圆角车窗、双轨与信号声波组成的品牌标志"} aria-hidden={decorative ? true : undefined}><span className="train-mark__rail" /><span className="train-mark__rail--right" /><span className="train-mark__signal" /></span>;
}

export default function Home() {
  const [query, setQuery] = useState("");
  const [activeTrack, setActiveTrack] = useState<Track | null>(null);
  const filteredTracks = useMemo(() => {
    const keyword = query.trim().toLowerCase();
    if (!keyword) return tracks;
    return tracks.filter((track) => `${track.title} ${track.artist} ${track.album} ${track.bookClue}`.toLowerCase().includes(keyword));
  }, [query]);

  const openSource = (track: Track) => {
    setActiveTrack(track);
    window.open(track.href, "_blank", "noopener,noreferrer");
  };

  return (
    <div className="min-h-screen overflow-x-hidden bg-[#f4f0e6] text-[#18372e]">
      <header className="relative overflow-hidden bg-[#18372e] text-[#f8f3e8]">
        <div className="absolute inset-0 bg-[linear-gradient(110deg,rgba(17,42,37,.98)_5%,rgba(20,50,44,.84)_47%,rgba(89,50,53,.36)_77%,rgba(241,153,121,.18)_100%)]" />
        <div className="absolute -right-20 top-16 h-72 w-72 rounded-full bg-[#e05a33]/15 blur-3xl" />
        <img src="/manus-storage/green-train-hero_6b40adfe.jpg" alt="深夜绿皮火车窗外的站台" className="absolute inset-0 h-full w-full object-cover object-center opacity-80" />
        <div className="relative mx-auto flex min-h-[510px] max-w-7xl flex-col px-5 pb-10 pt-6 sm:px-8 lg:px-12">
          <nav className="flex items-center justify-between border-b border-[#f8f3e8]/30 pb-4" aria-label="主导航">
            <div className="flex items-center gap-4">
              <TrainMark />
              <div className="leading-tight"><p className="font-mono text-[10px] tracking-[.22em] text-[#f2a179]">夜行线路 · 手写民谣索引</p><p className="mt-1 font-serif text-xl font-semibold tracking-[.08em]">绿皮火车·民谣歌单</p></div>
            </div>
            <a href="#playlist" className="font-mono text-xs tracking-[.12em] text-[#f8f3e8] transition hover:text-[#f2a179]">曲目索引 ↓</a>
          </nav>
          <div className="mt-auto max-w-3xl pt-28 sm:pt-32">
            <div className="mb-5 flex items-center gap-3 font-mono text-[11px] tracking-[.18em] text-[#f2a179]"><span className="h-px w-10 bg-[#f2a179]" />从书页到歌声 · 20 STOPS</div>
            <h1 className="font-serif text-5xl font-black leading-[1.1] tracking-tight sm:text-6xl lg:text-7xl">二十首歌。<br /><span className="text-[#f7b39a]">二十个夜色里的人。</span></h1>
            <p className="mt-6 max-w-2xl text-base leading-8 text-[#f8f3e8]/88 sm:text-lg">以周云蓬《绿皮火车：一直在路上》为起点，沿着书页里被写下、被唱起的名字，抵达那些仍能公开聆听的民谣现场。</p>
          </div>
          <div className="mt-10 grid gap-px overflow-hidden border border-[#f8f3e8]/25 bg-[#f8f3e8]/25 text-[#f8f3e8] sm:grid-cols-3">
            <div className="bg-[#18372e]/80 px-4 py-3"><p className="font-mono text-[10px] tracking-wider text-[#f2a179]">READING SOURCE</p><p className="mt-1 text-sm">微信读书 · 目录与正文线索</p></div>
            <div className="bg-[#18372e]/80 px-4 py-3"><p className="font-mono text-[10px] tracking-wider text-[#f2a179]">PLAYBACK MODE</p><p className="mt-1 text-sm">正版平台外链试听</p></div>
            <div className="bg-[#18372e]/80 px-4 py-3"><p className="font-mono text-[10px] tracking-wider text-[#f2a179]">CURRENT MANIFEST</p><p className="mt-1 text-sm">23 首 · 07 位音乐人</p></div>
          </div>
        </div>
      </header>

      <main id="playlist" className="paper-grain">
        <section className="mx-auto max-w-7xl px-5 py-14 sm:px-8 lg:px-12 lg:py-20">
          <div className="grid gap-8 lg:grid-cols-[minmax(0,1.5fr)_360px] lg:items-end">
            <div><p className="font-mono text-xs tracking-[.15em] text-[#e05a33]">NIGHT TRAIN / FOLK LOVE LETTERS</p><h2 className="mt-3 font-serif text-4xl font-bold leading-tight sm:text-5xl">把夜色调成一首，<br />可以慢慢听的歌。</h2></div>
            <div className="border-l-2 border-[#e05a33] pl-5 text-sm leading-7 text-[#456357]">二十首歌像二十张从车窗递出的便笺。每首都保留“书内明示”或“书内线索 · 已交叉核验”的边界；来源平台的播放权限仍以当时规则为准。</div>
          </div>
          <div className="mt-12 grid gap-4 lg:grid-cols-[minmax(0,1fr)_320px]">
            <label className="group flex h-14 items-center gap-3 border-b border-[#769083] bg-white/45 px-4 transition focus-within:border-[#e05a33]" aria-label="搜索曲目">
              <Search className="h-4 w-4 text-[#597468]" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="按歌名、演唱者或篇目检索" className="w-full bg-transparent text-sm outline-none placeholder:text-[#71877c]" />
              {query && <button onClick={() => setQuery("")} className="rounded p-1 text-[#597468] hover:bg-[#e6ded0]" aria-label="清除搜索"><X className="h-4 w-4" /></button>}
            </label>
            <div className="flex items-center justify-between border border-[#c9ba9f] bg-[#e8e1d4] px-4 text-sm"><span className="font-mono text-xs text-[#597468]">MANIFEST</span><span>{filteredTracks.length.toString().padStart(2, "0")} / {tracks.length.toString().padStart(2, "0")} 条</span></div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-5 pb-20 sm:px-8 lg:px-12">
          <div className="grid gap-12 lg:grid-cols-[minmax(0,1fr)_340px]">
            <div className="rail-line pl-14 sm:pl-16">
              <div className="mb-5 flex items-center justify-between border-b border-[#c9ba9f] pb-3 font-mono text-[10px] tracking-[.15em] text-[#597468]"><span>TRACK / ARTIST / BOOK CLUE</span><span>DEPARTURE →</span></div>
              <div className="space-y-3">
                {filteredTracks.map((track, index) => <div key={track.no}>
                  <article className={`track-item romantic-card ticket-notch relative border border-[#d9ccb5] px-5 py-5 shadow-[4px_4px_0_rgba(24,55,46,.08)] transition duration-200 hover:-translate-y-0.5 hover:border-[#e05a33] hover:shadow-[6px_6px_0_rgba(24,55,46,.12)] ${index % 3 === 0 ? "ticket-window" : index % 3 === 1 ? "field-note" : "ticket-stub"} ${index % 3 === 1 ? "sm:mr-8" : index % 3 === 2 ? "sm:mr-3" : ""}`} style={{ animationDelay: `${index * 42}ms`, marginLeft: `${[0, 28, 12][index % 3]}px` }}>
                    <span className="track-stub" aria-hidden="true" />
                    <div className="grid gap-4 sm:grid-cols-[56px_minmax(0,1fr)_auto] sm:items-center">
                      <p className="font-mono text-sm font-semibold text-[#e05a33]"><span className="block text-[9px] tracking-wider text-[#7f9488]">STOP</span>{track.no}</p>
                      <div><div className="flex flex-wrap items-baseline gap-x-3 gap-y-1"><h3 className="font-serif text-2xl font-bold">{track.title}</h3><p className="text-sm font-semibold text-[#456357]">{track.artist}</p></div><p className="mt-1 font-mono text-[10px] tracking-wide text-[#6a8075]">{track.album}</p><p className="mt-3 max-w-xl text-sm leading-6 text-[#456357]">{track.bookClue}</p><span className="mt-3 inline-flex border border-[#9eaf9f] px-2 py-1 font-mono text-[10px] tracking-wide text-[#456357]">{track.verification}</span></div>
                      <Button onClick={() => openSource(track)} className="h-11 rounded-none bg-[#18372e] px-4 text-[#fffaf0] hover:bg-[#e05a33] active:scale-[.97]" aria-label={`在${track.platform}打开《${track.title}》的原始试听页`}><Volume2 className="mr-2 h-4 w-4" /><span className="hidden xl:inline">继续这段路</span><span className="xl:hidden">原始试听页</span><ExternalLink className="ml-2 h-3.5 w-3.5" /></Button>
                    </div>
                  </article>
                  {(index + 1) % 5 === 0 && <div className="station-pause"><p className="font-mono text-[10px] tracking-[.16em] text-[#bb5c58]">{stationNotes[Math.min(3, Math.floor(index / 5))].title}</p><p className="mt-2 font-serif text-lg leading-7 text-[#415d51]">{stationNotes[Math.min(3, Math.floor(index / 5))].text}</p></div>}
                </div>)}
              </div>
              {filteredTracks.length === 0 && <div className="border border-dashed border-[#9eaf9f] py-12 text-center text-sm text-[#597468]">没有匹配曲目。试试“周云蓬”“左小祖咒”或“米店”。</div>}
            </div>
            <aside className="lg:sticky lg:top-6 lg:self-start">
              <div className="ticket-notch-dark overflow-hidden text-[#fffaf0] shadow-[7px_7px_0_rgba(24,55,46,.13)]">
                <div className="p-5"><div className="flex items-center justify-between font-mono text-[10px] tracking-[.15em] text-[#f2a179]"><span>车厢听音窗</span><TrainFront className="h-4 w-4" /></div><div className="window-player mt-4 flex flex-col justify-between p-5"><div className="flex items-start justify-between"><div className="h-2.5 w-2.5 rounded-full bg-[#e05a33] shadow-[0_0_0_4px_rgba(224,90,51,.14)]" /><TrainMark decorative className="h-10 w-10 scale-[.68] origin-top-right shadow-[3px_3px_0_#e05a33]" /></div><div className="flex items-end justify-between"><p className="font-mono text-[10px] tracking-[.18em] text-[#f2a179]">第三节 · 车窗微亮</p><div className="equalizer" aria-hidden="true">{Array.from({ length: 9 }).map((_, bar) => <span key={bar} style={{ height: `${8 + ((bar * 7) % 15)}px` }} />)}</div></div></div>
                  <div className="mt-5 min-h-[110px]">{activeTrack ? <><p className="font-serif text-2xl font-bold">{activeTrack.title}</p><p className="mt-1 text-sm text-[#e8dcc5]">{activeTrack.artist} · {activeTrack.album}</p><p className="mt-4 border-t border-[#f8f3e8]/20 pt-3 text-xs leading-5 text-[#e8dcc5]">站台已经为你点亮 {activeTrack.platform} 的原始试听页，继续这段路。</p></> : <><p className="font-serif text-2xl font-bold">车窗正对这一站</p><p className="mt-2 text-sm leading-6 text-[#e8dcc5]">选一首歌。车灯、月色和没说完的话，都在下一页等你。</p></>}</div>
                </div><div className="border-t border-[#f8f3e8]/20 px-5 py-4 font-mono text-[10px] tracking-[.12em] text-[#f2a179]">SOURCE-FIRST PLAYER · NO AUDIO MIRRORING</div>
              </div>
              <div className="mt-7 border-t border-[#c9ba9f] pt-5"><p className="font-mono text-[10px] tracking-[.15em] text-[#e05a33]">READING NOTE</p><p className="mt-3 font-serif text-xl font-semibold leading-8">“一直在路上”不只是书名，也是一种听歌的方向。</p><p className="mt-3 text-sm leading-6 text-[#597468]">歌单保留书内线索与核验边界：不把“篇目同名”误作正文逐字引文，也不把平台搜索页伪装成可下载的音频文件。</p></div>
            </aside>
          </div>
        </section>
      </main>
      <footer className="border-t border-[#c9ba9f] bg-[#ece4d4] px-5 py-10 sm:px-8 lg:px-12"><div className="mx-auto flex max-w-7xl flex-col justify-between gap-6 sm:flex-row"><p className="max-w-xl text-sm leading-6 text-[#597468]">资料范围：微信读书可访问书目目录与正文线索；QQ 音乐、网易云音乐、Apple Music、YouTube 等公开页面。本站仅做索引与跳转，不存储、不传播受版权保护的音频。</p><div className="flex items-center gap-3"><TrainMark decorative className="h-9 w-9 scale-[.65] origin-left shadow-[3px_3px_0_#e05a33]" /><p className="font-mono text-[10px] tracking-[.14em] text-[#597468]">绿皮火车·民谣歌单<br />手写夜行线路 · 2026</p></div></div></footer>
    </div>
  );
}

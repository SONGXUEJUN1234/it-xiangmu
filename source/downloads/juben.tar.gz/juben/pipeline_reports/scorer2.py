# scorer.py
# 剧本评分系统
# 使用方式：
# python scorer.py out\hardcore_out_plus.json

import json
import subprocess
import pathlib
import sys

PASS_THRESHOLD = 80  # 最终通过线

# -----------------------------
# 工具函数
# -----------------------------

def run_claude(prompt: str):
    return subprocess.run(
        ["cmd", "/c", "claude"],
        input=prompt,
        text=True,
        capture_output=True,
        encoding="utf-8"
    )

def extract_json(text):
    try:
        return json.loads(text)
    except:
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1:
            return json.loads(text[start:end+1])
    return None

# -----------------------------
# 第一层：结构硬评分
# -----------------------------

def structure_score(data):

    score = 0

    clues = data.get("clues", [])
    timeline = data.get("truth_core", {}).get("timeline", [])
    rounds = data.get("structure", {}).get("rounds", [])

    # 线索数量
    if 12 <= len(clues) <= 16:
        score += 15

    # 强线索数量
    strong = [c for c in clues if c.get("strength", 0) >= 7]
    if len(strong) >= 4:
        score += 15

    # 时间线完整度
    if len(timeline) >= 12:
        score += 15

    # 三回合结构
    if len(rounds) >= 3:
        score += 10

    # 动机存在
    if data.get("truth_core", {}).get("motive_structure"):
        score += 10

    # 角色数量合理
    if 5 <= len(data.get("characters", [])) <= 8:
        score += 10

    return min(score, 75)  # 结构层满分 75

# -----------------------------
# 第二层：逻辑评分（AI）
# -----------------------------

def logic_score(data):

    prompt = f"""
你是剧本杀逻辑评审专家。
请对以下JSON从0-10评分：

1 逻辑自洽
2 动机合理性
3 线索公平性
4 难度控制
5 结尾冲击力

输出严格JSON格式：
{{
  "logic": ,
  "motive": ,
  "clue_balance": ,
  "difficulty_control": ,
  "ending_impact": ,
  "total": 
}}

剧本JSON：
{json.dumps(data, ensure_ascii=False)}
"""

    p = run_claude(prompt)

    result = extract_json(p.stdout)
    if not result:
        return 0

    return result.get("total", 0) * 2  # 转成 0-100比例

# -----------------------------
# 第三层：商业评分（AI）
# -----------------------------

def market_score(data):

    prompt = f"""
你是剧本杀市场策划。
请从0-10评分：

1 标题吸引力
2 题材稀缺度
3 传播性
4 店家可操作性

输出JSON：
{{
  "title": ,
  "rarity": ,
  "spread": ,
  "operation": ,
  "total":
}}

剧本JSON：
{json.dumps(data, ensure_ascii=False)}
"""

    p = run_claude(prompt)

    result = extract_json(p.stdout)
    if not result:
        return 0

    return result.get("total", 0) * 2

# -----------------------------
# 主评分流程
# -----------------------------

def main():

    if len(sys.argv) < 2:
        print("Usage: python scorer.py path_to_json")
        return

    path = pathlib.Path(sys.argv[1])
    data = json.loads(path.read_text(encoding="utf-8"))

    print("结构评分中...")
    s1 = structure_score(data)

    print("逻辑评分中...")
    s2 = logic_score(data)

    print("商业评分中...")
    s3 = market_score(data)

    final_score = int(s1 * 0.4 + s2 * 0.4 + s3 * 0.2)

    result = {
        "structure_score": s1,
        "logic_score": s2,
        "market_score": s3,
        "final_score": final_score,
        "pass": final_score >= PASS_THRESHOLD
    }

    out_path = path.parent / (path.stem + "_score.json")
    out_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    print("最终评分:", final_score)
    print("是否通过:", result["pass"])
    print("评分文件:", out_path)

if __name__ == "__main__":
    main()
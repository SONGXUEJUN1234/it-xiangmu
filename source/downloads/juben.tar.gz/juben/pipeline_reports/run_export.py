import subprocess
import pathlib
import sys

def main():
    print("请选择类型：")
    print("1 硬核本格")
    print("2 机制阵营")
    print("3 情感沉浸")
    print("4 恐怖还原")

    choice = input("输入数字: ").strip()

    mapping = {
        "1": "hardcore",
        "2": "mechanism",
        "3": "emotional",
        "4": "horror"
    }

    if choice not in mapping:
        print("输入错误")
        return

    genre = mapping[choice]

    json_path = pathlib.Path("out") / f"{genre}_out_plus.json"

    if not json_path.exists():
        print(f"未找到文件: {json_path}")
        return

    print("开始导出...")

    subprocess.run(
        ["python", "readable_universal.py", str(json_path)],
        shell=True
    )

if __name__ == "__main__":
    main()
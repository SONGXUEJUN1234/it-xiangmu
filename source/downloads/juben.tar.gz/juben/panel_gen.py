# panel_gen.py
# 非交互批量生成器：一次默认生成 5 部（自动寻找 claude 可执行文件）
#
# 用法示例：
#   python panel_gen.py --genre hardcore
#   python panel_gen.py --genre hardcore --count 5 --player-count 6 --difficulty hard --tags "封闭空间,遗产纠纷" --setting-hint "海边豪宅生日宴发生命案"
#
# 输出：
#   out\<genre>_out_<timestamp>_<idx>.json   (每部一个文件)
#   out\<genre>_out.json                    (兼容旧流程，写入本次最后一部)

import argparse
import json
import pathlib
import re
import subprocess
import time
import shutil
from typing import Any, Dict, Optional, List

TEMPLATES = {
    "hardcore": "template_hardcore.txt",
    "mechanism": "template_mechanism.txt",
    "emotional": "template_emotional.txt",
    "horror": "template_horror.txt",
}

def _now_stamp() -> str:
    return time.strftime("%Y%m%d_%H%M%S")

def _extract_first_json(text: str) -> Optional[str]:
    if not text:
        return None
    start = text.find("{")
    if start == -1:
        return None
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(text)):
        ch = text[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return text[start:i+1]
    return None

def _validate_json(s: str) -> Optional[Dict[str, Any]]:
    try:
        obj = json.loads(s)
        return obj if isinstance(obj, dict) else None
    except Exception:
        return None

def _normalize_tags(tags: str) -> List[str]:
    if not tags:
        return []
    parts = re.split(r"[,\s，]+", tags.strip())
    return [p.strip() for p in parts if p.strip()]

def _find_claude_cmd() -> List[str]:
    """
    返回可执行的命令列表，如 ["claude"] 或 ["C:\\...\\claude.cmd"] 或 ["powershell","-ExecutionPolicy","Bypass","-File","...\\claude.ps1"]
    """
    # 1) 直接找 claude / claude.cmd / claude.exe
    for name in ["claude", "claude.cmd", "claude.exe"]:
        p = shutil.which(name)
        if p:
            return [p]

    # 2) 兼容 claude.ps1（用 powershell -File 调）
    p_ps1 = shutil.which("claude.ps1")
    if p_ps1:
        return ["powershell", "-ExecutionPolicy", "Bypass", "-File", p_ps1]

    # 3) 如果用户机器上能在 PowerShell 里运行 claude，但 python 找不到，
    #    这里给出明确提示
    return []

def _run_claude(prompt: str, timeout_sec: int = 3600) -> subprocess.CompletedProcess:
    cmd = _find_claude_cmd()
    if not cmd:
        raise FileNotFoundError(
            "找不到 Claude CLI（claude/claude.cmd/claude.ps1）。\n"
            "请在当前 PowerShell 执行：where.exe claude\n"
            "如果找不到，请把 Claude CLI 所在目录加入 PATH，或重新打开一个已加载 PATH 的终端。"
        )

    return subprocess.run(
        cmd,
        input=prompt,
        text=True,
        capture_output=True,
        encoding="utf-8",
        timeout=timeout_sec,
        shell=False
    )

def build_params(args) -> Dict[str, Any]:
    duration_default = "90-120" if args.genre == "hardcore" else "120-150"
    setting_default = "现代都市，封闭空间，禁止超自然" if args.genre == "hardcore" else "自定义题材提示"
    return {
        "genre": args.genre,
        "player_count": args.player_count,
        "duration": args.duration or duration_default,
        "difficulty": args.difficulty,
        "tags": _normalize_tags(args.tags),
        "setting_hint": args.setting_hint or setting_default,
    }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--genre", required=True, choices=list(TEMPLATES.keys()))
    parser.add_argument("--count", type=int, default=5, help="本次生成数量，默认 5")
    parser.add_argument("--player-count", type=int, default=6)
    parser.add_argument("--duration", default="", help="例如 90-120")
    parser.add_argument("--difficulty", default="hard")
    parser.add_argument("--tags", default="", help="逗号分隔")
    parser.add_argument("--setting-hint", default="", help="题材一句话提示")
    parser.add_argument("--retries", type=int, default=3, help="单部生成失败重试次数")
    parser.add_argument("--timeout", type=int, default=3600, help="单次调用超时秒数")
    parser.add_argument("--out-dir", default="out")
    args = parser.parse_args()

    tpl_path = pathlib.Path(TEMPLATES[args.genre])
    if not tpl_path.exists():
        raise SystemExit(f"Template file not found: {tpl_path}")

    template = tpl_path.read_text(encoding="utf-8")
    out_dir = pathlib.Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    run_id = _now_stamp()
    params = build_params(args)

    print(f"产线: {args.genre}  本次数量: {args.count}")
    print("参数:", json.dumps(params, ensure_ascii=False))

    last_saved_path = None

    for idx in range(1, args.count + 1):
        print(f"\n[{idx}/{args.count}] 正在调用 Claude...")
        prompt = template.replace("{PARAMS_JSON}", json.dumps(params, ensure_ascii=False, indent=2))

        ok_obj = None
        last_err = ""

        for attempt in range(1, args.retries + 1):
            try:
                p = _run_claude(prompt, timeout_sec=args.timeout)
            except Exception as e:
                last_err = str(e)
                print(f"调用失败 attempt {attempt}/{args.retries}: {last_err[:200]}")
                continue

            if p.returncode != 0:
                last_err = (p.stderr or p.stdout or "").strip()
                print(f"调用失败 attempt {attempt}/{args.retries}: {last_err[:200]}")
                continue

            raw = p.stdout or ""
            json_str = _extract_first_json(raw)
            if not json_str:
                last_err = "未抽取到JSON"
                print(f"输出非合法 JSON attempt {attempt}/{args.retries}: {last_err}")
                continue

            obj = _validate_json(json_str)
            if not obj:
                last_err = "JSON解析失败"
                print(f"输出非合法 JSON attempt {attempt}/{args.retries}: {last_err}")
                continue

            ok_obj = obj
            break

        if not ok_obj:
            raise SystemExit(f"本次生成失败：{args.genre} #{idx}，最后错误：{last_err}")

        fname = f"{args.genre}_out_{run_id}_{idx:02d}.json"
        save_path = out_dir / fname
        save_path.write_text(json.dumps(ok_obj, ensure_ascii=False, indent=2), encoding="utf-8")
        print("Saved:", save_path)
        last_saved_path = save_path

    if last_saved_path:
        compat_path = out_dir / f"{args.genre}_out.json"
        compat_path.write_text(last_saved_path.read_text(encoding="utf-8"), encoding="utf-8")
        print("\n兼容输出已更新:", compat_path)

if __name__ == "__main__":
    main()
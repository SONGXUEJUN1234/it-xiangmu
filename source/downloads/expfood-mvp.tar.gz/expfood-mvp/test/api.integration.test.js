const test = require("node:test");
const assert = require("node:assert/strict");
const { spawn } = require("node:child_process");
const fs = require("node:fs");
const path = require("node:path");

const BASE = "http://127.0.0.1:19088";
const TEST_DB_PATH = path.join("/tmp", `expfood-mvp-test-${process.pid}.db`);
let serverProc = null;

async function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function waitForHealth(timeoutMs = 15000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    try {
      const res = await fetch(`${BASE}/api/v1/health`);
      if (res.ok) return true;
    } catch (_err) {
      // ignore until timeout
    }
    await sleep(200);
  }
  return false;
}

async function call(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, options);
  return res.json();
}

test.before(async () => {
  try {
    fs.rmSync(TEST_DB_PATH, { force: true });
  } catch (_err) {
    // ignore
  }

  serverProc = spawn("node", ["server.js"], {
    cwd: "/home/erp17/expfood-mvp",
    env: {
      ...process.env,
      NODE_ENV: "test",
      HOST: "127.0.0.1",
      PORT: "19088",
      SQLITE_ENABLED: "true",
      SQLITE_PATH: TEST_DB_PATH,
      LOG_LEVEL: "warn",
      ACCESS_TOKEN_TTL_MS: "3000",
      REFRESH_TOKEN_TTL_MS: "120000",
    },
    stdio: "ignore",
  });

  const ok = await waitForHealth();
  assert.equal(ok, true, "server did not become healthy in time");
});

test.after(async () => {
  if (!serverProc) return;
  serverProc.kill("SIGTERM");
  try {
    fs.rmSync(TEST_DB_PATH, { force: true });
    fs.rmSync(`${TEST_DB_PATH}-wal`, { force: true });
    fs.rmSync(`${TEST_DB_PATH}-shm`, { force: true });
  } catch (_err) {
    // ignore
  }
});

test("API 集成链路：登录->发布->下单->核销->分页", async () => {
  const merchantLogin = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138001", role: "merchant" }),
  });
  assert.equal(merchantLogin.code, 200);
  const merchantToken = merchantLogin.data.token;

  const buyerLogin = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138000", role: "buyer" }),
  });
  assert.equal(buyerLogin.code, 200);
  const buyerToken = buyerLogin.data.token;

  const publish = await call("/api/v1/merchant/products", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
    body: JSON.stringify({
      name: "integration product",
      category_id: 1,
      original_price: 20,
      discount_price: 12,
      stock: 3,
      images: ["/assets/product-bread-main.svg", "/assets/product-bread-angle.svg"],
      detail_images: ["/assets/product-bread-detail.svg"],
      ingredients: "面粉, 黄油",
      allergen_info: "含麸质, 含乳",
      production_date: "2026-02-10",
      best_before_date: "2026-02-14",
      pickup_start_time: "09:00",
      pickup_end_time: "18:00",
    }),
  });
  assert.equal(publish.code, 200);
  const productID = publish.data.id;
  assert.equal(Array.isArray(publish.data.images), true);
  assert.equal(publish.data.images.length, 2);
  assert.equal(Array.isArray(publish.data.detail_images), true);
  assert.equal(publish.data.detail_images.length, 1);
  assert.equal(publish.data.ingredients, "面粉, 黄油");
  assert.equal(publish.data.allergen_info, "含麸质, 含乳");
  assert.equal(publish.data.production_date, "2026-02-10");
  assert.equal(publish.data.best_before_date, "2026-02-14");
  assert.equal(publish.data.pickup_start_time, "09:00");
  assert.equal(publish.data.pickup_end_time, "18:00");
  const order = await call("/api/v1/orders", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
    body: JSON.stringify({ product_id: productID, quantity: 1 }),
  });
  assert.equal(order.code, 200);
  const orderID = order.data.order_id;
  assert.equal(order.data.status, 0);

  const outOfStock = await call("/api/v1/orders", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
    body: JSON.stringify({ product_id: productID, quantity: 99 }),
  });
  assert.equal(outOfStock.code, 409);
  assert.equal(outOfStock.error_code, "ORDER_STOCK_NOT_ENOUGH");

  const detail = await call(`/api/v1/orders/${orderID}`, {
    headers: { Authorization: `Bearer ${buyerToken}` },
  });
  assert.equal(detail.code, 200);
  assert.equal(detail.data.status, 0);

  const pay = await call(`/api/v1/orders/${orderID}/pay`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
  });
  assert.equal(pay.code, 200);
  assert.equal(pay.data.status, 1);
  const verifyCode = pay.data.verify_code;

  const verify = await call(`/api/v1/merchant/orders/${orderID}/verify`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
    body: JSON.stringify({ verify_code: verifyCode }),
  });
  assert.equal(verify.code, 200);
  assert.equal(verify.data.status, 2);

  const buyerDetailAfterVerify = await call(`/api/v1/orders/${orderID}`, {
    headers: { Authorization: `Bearer ${buyerToken}` },
  });
  assert.equal(buyerDetailAfterVerify.code, 200);
  assert.equal(Array.isArray(buyerDetailAfterVerify.data.timeline), true);
  assert.equal(buyerDetailAfterVerify.data.timeline.some((e) => e.code === "ORDER_CREATED"), true);
  assert.equal(buyerDetailAfterVerify.data.timeline.some((e) => e.code === "PAYMENT_SUCCESS"), true);
  assert.equal(buyerDetailAfterVerify.data.timeline.some((e) => e.code === "ORDER_VERIFIED"), true);

  const merchantDetailAfterVerify = await call(`/api/v1/merchant/orders/${orderID}`, {
    headers: { Authorization: `Bearer ${merchantToken}` },
  });
  assert.equal(merchantDetailAfterVerify.code, 200);
  assert.equal(Array.isArray(merchantDetailAfterVerify.data.timeline), true);
  assert.equal(merchantDetailAfterVerify.data.timeline.some((e) => e.code === "ORDER_VERIFIED"), true);

  const buyerOrdersPage = await call("/api/v1/orders?page=1&page_size=1&status=2", {
    headers: { Authorization: `Bearer ${buyerToken}` },
  });
  assert.equal(buyerOrdersPage.code, 200);
  assert.equal(buyerOrdersPage.data.page, 1);
  assert.equal(buyerOrdersPage.data.page_size, 1);
  assert.equal(buyerOrdersPage.data.total >= 1, true);
  assert.equal(Array.isArray(buyerOrdersPage.data.orders), true);
});

test("商品发布校验：图片为必填", async () => {
  const merchantLogin = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138001", role: "merchant" }),
  });
  assert.equal(merchantLogin.code, 200);
  const merchantToken = merchantLogin.data.token;

  const publishWithoutImages = await call("/api/v1/merchant/products", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
    body: JSON.stringify({
      name: "invalid no image product",
      category_id: 1,
      original_price: 20,
      discount_price: 12,
      stock: 3,
      images: [],
      production_date: "2026-02-10",
      best_before_date: "2026-02-14",
    }),
  });
  assert.equal(publishWithoutImages.code, 400);
  assert.equal(publishWithoutImages.error_code, "PRODUCT_MISSING_FIELDS");

  const publishTooManyImages = await call("/api/v1/merchant/products", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
    body: JSON.stringify({
      name: "invalid too many images product",
      category_id: 1,
      original_price: 20,
      discount_price: 12,
      stock: 3,
      images: [
        "/assets/product-bread-main.svg",
        "/assets/product-bread-angle.svg",
        "/assets/product-bread-detail.svg",
        "/assets/product-salad-main.svg",
        "https://example.com/1.png",
        "https://example.com/2.png",
        "https://example.com/3.png"
      ],
      production_date: "2026-02-10",
      best_before_date: "2026-02-14",
    }),
  });
  assert.equal(publishTooManyImages.code, 400);
  assert.equal(publishTooManyImages.error_code, "PRODUCT_IMAGES_TOO_MANY");
});

test("鉴权生命周期：过期、刷新、登出", async () => {
  const login = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138000", role: "buyer" }),
  });
  assert.equal(login.code, 200);
  assert.equal(typeof login.data.token, "string");
  assert.equal(typeof login.data.refresh_token, "string");
  assert.equal(typeof login.data.expires_in, "number");

  const accessToken = login.data.token;
  const refreshToken = login.data.refresh_token;

  const beforeExpire = await call("/api/v1/cart/items", {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  assert.equal(beforeExpire.code, 200);

  await sleep(3200);

  const afterExpire = await call("/api/v1/cart/items", {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  assert.equal(afterExpire.code, 401);
  assert.equal(afterExpire.error_code, "AUTH_TOKEN_EXPIRED");

  const refreshed = await call("/api/v1/auth/refresh", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ refresh_token: refreshToken }),
  });
  assert.equal(refreshed.code, 200);
  assert.equal(typeof refreshed.data.token, "string");
  assert.equal(typeof refreshed.data.refresh_token, "string");
  assert.notEqual(refreshed.data.token, accessToken);
  assert.notEqual(refreshed.data.refresh_token, refreshToken);

  const oldRefreshRetry = await call("/api/v1/auth/refresh", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ refresh_token: refreshToken }),
  });
  assert.equal(oldRefreshRetry.code, 401);
  assert.equal(oldRefreshRetry.error_code, "AUTH_REFRESH_TOKEN_INVALID");

  const newAccessToken = refreshed.data.token;
  const afterRefresh = await call("/api/v1/cart/items", {
    headers: { Authorization: `Bearer ${newAccessToken}` },
  });
  assert.equal(afterRefresh.code, 200);

  const logout = await call("/api/v1/auth/logout", {
    method: "POST",
    headers: { Authorization: `Bearer ${newAccessToken}` },
  });
  assert.equal(logout.code, 200);
  assert.equal(logout.data.revoked, true);

  const afterLogout = await call("/api/v1/cart/items", {
    headers: { Authorization: `Bearer ${newAccessToken}` },
  });
  assert.equal(afterLogout.code, 401);
  assert.equal(afterLogout.error_code, "AUTH_TOKEN_INVALID");
});

test("OpenAPI 文档可访问且包含基础结构", async () => {
  const res = await fetch(`${BASE}/openapi.json`);
  assert.equal(res.status, 200);
  assert.equal(String(res.headers.get("content-type") || "").includes("application/json"), true);
  const doc = await res.json();
  assert.equal(doc.openapi, "3.0.3");
  assert.equal(!!doc.paths, true);
  assert.equal(!!doc.paths["/api/v1/auth/login"], true);
  assert.equal(!!doc.paths["/api/v1/auth/refresh"], true);
  assert.equal(!!doc.paths["/api/v1/auth/logout"], true);
  assert.equal(!!doc.paths["/api/v1/map/geocode"], true);
  assert.equal(!!doc.paths["/api/v1/merchant/settlement-summary"], true);
});

test("地图配置接口可访问", async () => {
  const configRes = await call("/api/v1/map/config");
  assert.equal(configRes.code, 200);
  assert.equal(typeof configRes.data.amap_js_key, "string");
  assert.equal(typeof configRes.data.has_amap_js_key, "boolean");
});

test("商家登录：未注册手机号不可直接登录", async () => {
  const login = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800139991", role: "merchant" }),
  });
  assert.equal(login.code, 404);
  assert.equal(login.error_code, "MERCHANT_NOT_REGISTERED");
});

test("买家注册：提交姓名后可登录并返回买家资料", async () => {
  const register = await call("/api/v1/buyer/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      phone: "13800138266",
      full_name: "赵六",
      buyer_address: "上海市静安区示例路66号",
    }),
  });
  assert.equal(register.code, 200);
  assert.equal(register.data.full_name, "赵六");
  assert.equal(register.data.buyer_address, "上海市静安区示例路66号");

  const buyerLogin = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138266", role: "buyer" }),
  });
  assert.equal(buyerLogin.code, 200);
  assert.equal(buyerLogin.data.full_name, "赵六");
  assert.equal(buyerLogin.data.buyer_address, "上海市静安区示例路66号");
});

test("买家资料编辑：登录后可更新姓名和常用地址", async () => {
  const buyerLogin = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138266", role: "buyer" }),
  });
  assert.equal(buyerLogin.code, 200);
  const buyerToken = buyerLogin.data.token;

  const update = await call("/api/v1/buyer/profile", {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
    body: JSON.stringify({
      full_name: "赵六-更新",
      buyer_address: "上海市徐汇区更新路88号",
    }),
  });
  assert.equal(update.code, 200);
  assert.equal(update.data.full_name, "赵六-更新");
  assert.equal(update.data.buyer_address, "上海市徐汇区更新路88号");

  const buyerLoginAgain = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138266", role: "buyer" }),
  });
  assert.equal(buyerLoginAgain.code, 200);
  assert.equal(buyerLoginAgain.data.full_name, "赵六-更新");
  assert.equal(buyerLoginAgain.data.buyer_address, "上海市徐汇区更新路88号");
});

test("商家注册：提交资料后可登录并返回店铺信息", async () => {
  const register = await call("/api/v1/merchant/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      phone: "13800138222",
      shop_name: "临期便当站",
      shop_address: "上海市徐汇区YY路66号",
      contact_name: "李四",
      contact_phone: "13800138222",
      shop_lat: 31.232,
      shop_lng: 121.48,
      business_hours: "09:30-21:00",
      license_images: ["/assets/product-salad-main.svg"],
    }),
  });
  assert.equal(register.code, 200);
  assert.equal(register.data.shop_name, "临期便当站");
  assert.equal(register.data.merchant_status, "approved");
  assert.equal(Array.isArray(register.data.license_images), true);
  assert.equal(register.data.license_images.length >= 1, true);

  const merchantLogin = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138222", role: "merchant" }),
  });
  assert.equal(merchantLogin.code, 200);
  assert.equal(merchantLogin.data.shop_name, "临期便当站");
  assert.equal(merchantLogin.data.shop_address, "上海市徐汇区YY路66号");
  assert.equal(merchantLogin.data.contact_name, "李四");
  assert.equal(merchantLogin.data.contact_phone, "13800138222");
  assert.equal(typeof merchantLogin.data.shop_lat, "number");
  assert.equal(typeof merchantLogin.data.shop_lng, "number");
  assert.equal(merchantLogin.data.business_hours, "09:30-21:00");
  assert.equal(merchantLogin.data.merchant_status, "approved");
});

test("商家资料编辑：登录后可更新店铺资料", async () => {
  const merchantLogin = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138222", role: "merchant" }),
  });
  assert.equal(merchantLogin.code, 200);
  const merchantToken = merchantLogin.data.token;

  const update = await call("/api/v1/merchant/profile", {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
    body: JSON.stringify({
      shop_name: "临期便当站-更新",
      shop_address: "上海市徐汇区YY路88号",
      contact_name: "李四-更新",
      contact_phone: "13800138222",
      shop_lat: 31.2325,
      shop_lng: 121.4802,
      business_hours: "10:00-22:00",
      license_images: ["/assets/product-bread-main.svg"],
    }),
  });
  assert.equal(update.code, 200);
  assert.equal(update.data.shop_name, "临期便当站-更新");
  assert.equal(update.data.shop_address, "上海市徐汇区YY路88号");
  assert.equal(update.data.contact_name, "李四-更新");
  assert.equal(update.data.business_hours, "10:00-22:00");
  assert.equal(typeof update.data.shop_lat, "number");
  assert.equal(typeof update.data.shop_lng, "number");
});

test("商家营业状态：打烊后附近搜索不可见，营业后恢复", async () => {
  const register = await call("/api/v1/merchant/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      phone: "13800138444",
      shop_name: "营业状态测试店",
      shop_address: "上海市黄浦区测试路18号",
      contact_name: "测试商家",
      contact_phone: "13800138444",
      shop_lat: 31.2306,
      shop_lng: 121.4739,
      business_hours: "10:00-22:00",
      license_images: ["/assets/product-bread-main.svg"],
    }),
  });
  assert.equal(register.code, 200);
  assert.equal(register.data.is_open, true);

  const merchantLogin = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138444", role: "merchant" }),
  });
  assert.equal(merchantLogin.code, 200);
  const merchantToken = merchantLogin.data.token;

  const publish = await call("/api/v1/merchant/products", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
    body: JSON.stringify({
      name: "营业状态测试商品",
      category_id: 1,
      original_price: 20,
      discount_price: 9,
      stock: 8,
      images: ["/assets/product-bread-main.svg"],
      production_date: "2026-02-10",
      best_before_date: "2026-02-14",
    }),
  });
  assert.equal(publish.code, 200);
  const productID = publish.data.id;

  const buyerLogin = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138000", role: "buyer" }),
  });
  assert.equal(buyerLogin.code, 200);
  const buyerToken = buyerLogin.data.token;

  const beforeClose = await call("/api/v1/shops/nearby?lat=31.2304&lng=121.4737&radius_km=3&sort_by=distance", {
    headers: {
      Authorization: `Bearer ${buyerToken}`,
    },
  });
  assert.equal(beforeClose.code, 200);
  assert.equal(beforeClose.data.shops.some((s) => s.shop_name === "营业状态测试店"), true);
  const publicBeforeClose = await call("/api/v1/products?keyword=营业状态测试商品", {
    headers: {
      Authorization: `Bearer ${buyerToken}`,
    },
  });
  assert.equal(publicBeforeClose.code, 200);
  assert.equal(publicBeforeClose.data.products.some((p) => p.id === productID), true);

  const close = await call("/api/v1/merchant/open-status", {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
    body: JSON.stringify({ is_open: false }),
  });
  assert.equal(close.code, 200);
  assert.equal(close.data.is_open, false);

  const afterClose = await call("/api/v1/shops/nearby?lat=31.2304&lng=121.4737&radius_km=3&sort_by=distance", {
    headers: {
      Authorization: `Bearer ${buyerToken}`,
    },
  });
  assert.equal(afterClose.code, 200);
  assert.equal(afterClose.data.shops.some((s) => s.shop_name === "营业状态测试店"), false);
  const publicAfterClose = await call("/api/v1/products?keyword=营业状态测试商品", {
    headers: {
      Authorization: `Bearer ${buyerToken}`,
    },
  });
  assert.equal(publicAfterClose.code, 200);
  assert.equal(publicAfterClose.data.products.some((p) => p.id === productID), false);

  const orderWhenClosed = await call("/api/v1/orders", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
    body: JSON.stringify({ product_id: productID, quantity: 1 }),
  });
  assert.equal(orderWhenClosed.code, 409);
  assert.equal(orderWhenClosed.error_code, "MERCHANT_CLOSED");

  const addCartWhenClosed = await call("/api/v1/cart/items", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
    body: JSON.stringify({ product_id: productID, quantity: 1 }),
  });
  assert.equal(addCartWhenClosed.code, 409);
  assert.equal(addCartWhenClosed.error_code, "MERCHANT_CLOSED");

  const reopen = await call("/api/v1/merchant/open-status", {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
    body: JSON.stringify({ is_open: true }),
  });
  assert.equal(reopen.code, 200);
  assert.equal(reopen.data.is_open, true);

  const addCartAfterReopen = await call("/api/v1/cart/items", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
    body: JSON.stringify({ product_id: productID, quantity: 1 }),
  });
  assert.equal(addCartAfterReopen.code, 200);
  const addedCartItemId = Number(addCartAfterReopen.data && addCartAfterReopen.data.id);

  const closeAgain = await call("/api/v1/merchant/open-status", {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
    body: JSON.stringify({ is_open: false }),
  });
  assert.equal(closeAgain.code, 200);
  assert.equal(closeAgain.data.is_open, false);

  const checkoutWhenClosed = await call("/api/v1/cart/checkout", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
  });
  assert.equal(checkoutWhenClosed.code, 409);
  assert.equal(checkoutWhenClosed.error_code, "MERCHANT_CLOSED");

  if (Number.isInteger(addedCartItemId) && addedCartItemId > 0) {
    const removeClosedCartItem = await call(`/api/v1/cart/items/${addedCartItemId}`, {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${buyerToken}`,
      },
    });
    assert.equal(removeClosedCartItem.code, 200);
  }

  const reopenAfterCloseAgain = await call("/api/v1/merchant/open-status", {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
    body: JSON.stringify({ is_open: true }),
  });
  assert.equal(reopenAfterCloseAgain.code, 200);
  assert.equal(reopenAfterCloseAgain.data.is_open, true);
});

test("买家可按坐标查询附近折扣商家", async () => {
  const register = await call("/api/v1/merchant/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      phone: "13800138333",
      shop_name: "附近折扣店",
      shop_address: "上海市黄浦区ZZ路9号",
      contact_name: "王五",
      contact_phone: "13800138333",
      shop_lat: 31.2305,
      shop_lng: 121.4738,
      business_hours: "10:00-22:00",
      license_images: ["/assets/product-bread-main.svg"],
    }),
  });
  assert.equal(register.code, 200);

  const merchantLogin = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138333", role: "merchant" }),
  });
  assert.equal(merchantLogin.code, 200);
  const merchantToken = merchantLogin.data.token;

  const publish = await call("/api/v1/merchant/products", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
    body: JSON.stringify({
      name: "nearby discount product",
      category_id: 1,
      original_price: 30,
      discount_price: 12,
      stock: 5,
      images: ["/assets/product-bread-main.svg"],
      production_date: "2026-02-10",
      best_before_date: "2026-02-14",
    }),
  });
  assert.equal(publish.code, 200);

  const buyerLogin = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138000", role: "buyer" }),
  });
  assert.equal(buyerLogin.code, 200);
  const buyerToken = buyerLogin.data.token;

  const nearby = await call("/api/v1/shops/nearby?lat=31.2304&lng=121.4737&radius_km=3&sort_by=discount", {
    headers: {
      Authorization: `Bearer ${buyerToken}`,
    },
  });
  assert.equal(nearby.code, 200);
  assert.equal(nearby.data.sort_by, "discount");
  assert.equal(nearby.data.total >= 1, true);
  const hit = nearby.data.shops.find((s) => s.shop_name === "附近折扣店");
  assert.equal(!!hit, true);
  assert.equal(hit.distance_km <= 3, true);
  assert.equal(hit.best_discount_percent > 0, true);
  assert.equal(!!hit.featured_product, true);
  assert.equal(Number(hit.featured_product.discount_price) > 0, true);
  assert.equal(typeof hit.business_hours, "string");

  const nearbyInvalidSort = await call("/api/v1/shops/nearby?lat=31.2304&lng=121.4737&radius_km=3&sort_by=unknown", {
    headers: {
      Authorization: `Bearer ${buyerToken}`,
    },
  });
  assert.equal(nearbyInvalidSort.code, 400);
  assert.equal(nearbyInvalidSort.error_code, "SHOP_NEARBY_INVALID_SORT");
});

test("退款规则：未核销自动退款，已核销需商家确认", async () => {
  const merchantLogin = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138001", role: "merchant" }),
  });
  assert.equal(merchantLogin.code, 200);
  const merchantToken = merchantLogin.data.token;

  const buyerLogin = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138000", role: "buyer" }),
  });
  assert.equal(buyerLogin.code, 200);
  const buyerToken = buyerLogin.data.token;

  const publish = await call("/api/v1/merchant/products", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
    body: JSON.stringify({
      name: "refund product",
      category_id: 1,
      original_price: 30,
      discount_price: 15,
      stock: 5,
      images: ["https://picsum.photos/200"],
      production_date: "2026-02-10",
      best_before_date: "2026-02-14",
    }),
  });
  assert.equal(publish.code, 200);
  const productID = publish.data.id;

  const orderA = await call("/api/v1/orders", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
    body: JSON.stringify({ product_id: productID, quantity: 1 }),
  });
  assert.equal(orderA.code, 200);
  const orderAID = orderA.data.order_id;

  const payA = await call(`/api/v1/orders/${orderAID}/pay`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
  });
  assert.equal(payA.code, 200);
  assert.equal(payA.data.status, 1);

  const refundA = await call(`/api/v1/orders/${orderAID}/refund`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
    body: JSON.stringify({ reason: "未取货退款" }),
  });
  assert.equal(refundA.code, 200);
  assert.equal(refundA.data.status, 5);
  assert.equal(refundA.data.refund_reason, "未取货退款");

  const orderB = await call("/api/v1/orders", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
    body: JSON.stringify({ product_id: productID, quantity: 1 }),
  });
  assert.equal(orderB.code, 200);
  const orderBID = orderB.data.order_id;

  const payB = await call(`/api/v1/orders/${orderBID}/pay`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
  });
  assert.equal(payB.code, 200);
  const verifyB = await call(`/api/v1/merchant/orders/${orderBID}/verify`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
    body: JSON.stringify({ verify_code: payB.data.verify_code }),
  });
  assert.equal(verifyB.code, 200);
  assert.equal(verifyB.data.status, 2);

  const refundB = await call(`/api/v1/orders/${orderBID}/refund`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
    body: JSON.stringify({ reason: "已核销退款申请" }),
  });
  assert.equal(refundB.code, 200);
  assert.equal(refundB.data.status, 5);

  const approveB = await call(`/api/v1/merchant/orders/${orderBID}/refund/approve`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
  });
  assert.equal(approveB.code, 200);
  assert.equal(approveB.data.status, 4);
});

test("购物车结算：单商家限制 + 结算生成订单 + 批量支付", async () => {
  const merchant1 = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138001", role: "merchant" }),
  });
  assert.equal(merchant1.code, 200);
  const merchant1Token = merchant1.data.token;

  const merchant2Register = await call("/api/v1/merchant/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      phone: "13800138011",
      shop_name: "购物车商家2",
      shop_address: "上海市黄浦区购物路11号",
      contact_name: "购物车商家2",
      contact_phone: "13800138011",
      shop_lat: 31.2312,
      shop_lng: 121.4743,
      business_hours: "10:00-22:00",
      license_images: ["/assets/product-bread-main.svg"],
    }),
  });
  assert.equal(merchant2Register.code, 200);

  const merchant2 = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138011", role: "merchant" }),
  });
  assert.equal(merchant2.code, 200);
  const merchant2Token = merchant2.data.token;

  const buyer = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138000", role: "buyer" }),
  });
  assert.equal(buyer.code, 200);
  const buyerToken = buyer.data.token;

  const p1 = await call("/api/v1/merchant/products", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchant1Token}`,
    },
    body: JSON.stringify({
      name: "cart product 1",
      category_id: 1,
      original_price: 22,
      discount_price: 11,
      stock: 5,
      images: ["https://picsum.photos/200"],
      production_date: "2026-02-10",
      best_before_date: "2026-02-14",
    }),
  });
  assert.equal(p1.code, 200);
  const p1b = await call("/api/v1/merchant/products", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchant1Token}`,
    },
    body: JSON.stringify({
      name: "cart product 1b",
      category_id: 1,
      original_price: 24,
      discount_price: 13,
      stock: 5,
      images: ["https://picsum.photos/200"],
      production_date: "2026-02-10",
      best_before_date: "2026-02-14",
    }),
  });
  assert.equal(p1b.code, 200);

  const p2 = await call("/api/v1/merchant/products", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchant2Token}`,
    },
    body: JSON.stringify({
      name: "cart product 2",
      category_id: 1,
      original_price: 30,
      discount_price: 16,
      stock: 5,
      images: ["https://picsum.photos/200"],
      production_date: "2026-02-10",
      best_before_date: "2026-02-14",
    }),
  });
  assert.equal(p2.code, 200);

  const add1 = await call("/api/v1/cart/items", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
    body: JSON.stringify({ product_id: p1.data.id, quantity: 1 }),
  });
  assert.equal(add1.code, 200);

  const add2 = await call("/api/v1/cart/items", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
    body: JSON.stringify({ product_id: p1b.data.id, quantity: 2 }),
  });
  assert.equal(add2.code, 200);
  assert.equal(add2.data.quantity, 2);

  const addCrossShop = await call("/api/v1/cart/items", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
    body: JSON.stringify({ product_id: p2.data.id, quantity: 1 }),
  });
  assert.equal(addCrossShop.code, 409);
  assert.equal(addCrossShop.error_code, "CART_MULTI_SHOP_NOT_ALLOWED");

  const checkout = await call("/api/v1/cart/checkout", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
  });
  assert.equal(checkout.code, 200);
  assert.equal(checkout.data.order_count, 2);
  assert.equal(checkout.data.orders[0].status, 0);
  assert.equal(checkout.data.orders[1].status, 0);
  const checkoutBatchNo = checkout.data.checkout_batch_no;

  const recordsAfterCheckout = await call("/api/v1/checkout-records", {
    headers: { Authorization: `Bearer ${buyerToken}` },
  });
  assert.equal(recordsAfterCheckout.code, 200);
  const currentRecord = recordsAfterCheckout.data.records.find((r) => r.checkout_batch_no === checkoutBatchNo);
  assert.equal(!!currentRecord, true);
  assert.equal(currentRecord.payment_status_text, "全部待支付");

  const orderIDs = checkout.data.orders.map((o) => o.order_id);
  const batchPay = await call("/api/v1/orders/batch-pay", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
    body: JSON.stringify({ order_ids: orderIDs }),
  });
  assert.equal(batchPay.code, 200);
  assert.equal(batchPay.data.count, 2);
  assert.equal(batchPay.data.orders[0].status, 1);
  assert.equal(batchPay.data.orders[1].status, 1);

  const recordsAfterPay = await call("/api/v1/checkout-records", {
    headers: { Authorization: `Bearer ${buyerToken}` },
  });
  assert.equal(recordsAfterPay.code, 200);
  const paidRecord = recordsAfterPay.data.records.find((r) => r.checkout_batch_no === checkoutBatchNo);
  assert.equal(!!paidRecord, true);
  assert.equal(paidRecord.payment_status_text, "全部已支付");

  const cartAfter = await call("/api/v1/cart/items", {
    headers: { Authorization: `Bearer ${buyerToken}` },
  });
  assert.equal(cartAfter.code, 200);
  assert.equal(cartAfter.data.total, 0);
});

test("商家对账汇总：支持时间范围并返回金额统计", async () => {
  const merchantRegister = await call("/api/v1/merchant/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      phone: "13800138123",
      shop_name: "对账商家",
      shop_address: "上海市静安区对账路123号",
      contact_name: "对账商家",
      contact_phone: "13800138123",
      shop_lat: 31.2299,
      shop_lng: 121.4729,
      business_hours: "10:00-22:00",
      license_images: ["/assets/product-bread-main.svg"],
    }),
  });
  assert.equal(merchantRegister.code, 200);

  const merchantLogin = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138123", role: "merchant" }),
  });
  assert.equal(merchantLogin.code, 200);
  const merchantToken = merchantLogin.data.token;

  const buyerLogin = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138000", role: "buyer" }),
  });
  assert.equal(buyerLogin.code, 200);
  const buyerToken = buyerLogin.data.token;

  const publish = await call("/api/v1/merchant/products", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
    body: JSON.stringify({
      name: "summary product",
      category_id: 1,
      original_price: 40,
      discount_price: 20,
      stock: 5,
      images: ["https://picsum.photos/200"],
      production_date: "2026-02-10",
      best_before_date: "2026-02-14",
    }),
  });
  assert.equal(publish.code, 200);
  const productID = publish.data.id;

  const orderA = await call("/api/v1/orders", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
    body: JSON.stringify({ product_id: productID, quantity: 1 }),
  });
  assert.equal(orderA.code, 200);
  const payA = await call(`/api/v1/orders/${orderA.data.order_id}/pay`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
  });
  assert.equal(payA.code, 200);

  const orderB = await call("/api/v1/orders", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
    body: JSON.stringify({ product_id: productID, quantity: 1 }),
  });
  assert.equal(orderB.code, 200);
  const payB = await call(`/api/v1/orders/${orderB.data.order_id}/pay`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
  });
  assert.equal(payB.code, 200);

  const verifyB = await call(`/api/v1/merchant/orders/${orderB.data.order_id}/verify`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
    body: JSON.stringify({ verify_code: payB.data.verify_code }),
  });
  assert.equal(verifyB.code, 200);

  const today = new Date().toISOString().slice(0, 10);
  const summary = await call(`/api/v1/merchant/settlement-summary?start_date=${today}&end_date=${today}`, {
    headers: { Authorization: `Bearer ${merchantToken}` },
  });
  assert.equal(summary.code, 200);
  assert.equal(summary.data.total_orders >= 2, true);
  assert.equal(summary.data.pending_verify_count >= 1, true);
  assert.equal(summary.data.verified_count >= 1, true);
  assert.equal(typeof summary.data.pending_verify_amount, "number");
  assert.equal(typeof summary.data.verified_amount, "number");
  assert.equal(typeof summary.data.refunded_amount, "number");

  const pendingDetails = await call(
    `/api/v1/merchant/settlement-details?start_date=${today}&end_date=${today}&bucket=pending_verify`,
    {
      headers: { Authorization: `Bearer ${merchantToken}` },
    }
  );
  assert.equal(pendingDetails.code, 200);
  assert.equal(pendingDetails.data.total >= 1, true);
  assert.equal(pendingDetails.data.orders.some((o) => o.status === 1), true);

  const verifiedDetails = await call(
    `/api/v1/merchant/settlement-details?start_date=${today}&end_date=${today}&bucket=verified`,
    {
      headers: { Authorization: `Bearer ${merchantToken}` },
    }
  );
  assert.equal(verifiedDetails.code, 200);
  assert.equal(verifiedDetails.data.total >= 1, true);
  assert.equal(verifiedDetails.data.orders.some((o) => o.status === 2), true);

  const exportRes = await fetch(
    `${BASE}/api/v1/merchant/settlement-details/export?start_date=${today}&end_date=${today}&bucket=verified`,
    {
      headers: { Authorization: `Bearer ${merchantToken}` },
    }
  );
  assert.equal(exportRes.status, 200);
  assert.equal(String(exportRes.headers.get("content-type") || "").includes("text/csv"), true);
  const csv = await exportRes.text();
  assert.equal(csv.includes("id,order_no,product_name,quantity,total_amount,status,created_at"), true);
  assert.equal(csv.includes(",2,"), true);
});

test("商家结算：单笔 + 批量结算并进入已结算统计", async () => {
  const merchantRegister = await call("/api/v1/merchant/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      phone: "13800138999",
      shop_name: "结算商家",
      shop_address: "上海市徐汇区结算路99号",
      contact_name: "结算商家",
      contact_phone: "13800138999",
      shop_lat: 31.2288,
      shop_lng: 121.4699,
      business_hours: "10:00-22:00",
      license_images: ["/assets/product-bread-main.svg"],
    }),
  });
  assert.equal(merchantRegister.code, 200);

  const merchantLogin = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138999", role: "merchant" }),
  });
  assert.equal(merchantLogin.code, 200);
  const merchantToken = merchantLogin.data.token;

  const buyerLogin = await call("/api/v1/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone: "13800138000", role: "buyer" }),
  });
  assert.equal(buyerLogin.code, 200);
  const buyerToken = buyerLogin.data.token;

  const publish = await call("/api/v1/merchant/products", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
    body: JSON.stringify({
      name: "settle product",
      category_id: 1,
      original_price: 50,
      discount_price: 25,
      stock: 10,
      images: ["https://picsum.photos/200"],
      production_date: "2026-02-10",
      best_before_date: "2026-02-14",
    }),
  });
  assert.equal(publish.code, 200);
  const productID = publish.data.id;

  const createAndVerify = async () => {
    const order = await call("/api/v1/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${buyerToken}`,
      },
      body: JSON.stringify({ product_id: productID, quantity: 1 }),
    });
    assert.equal(order.code, 200);
    const orderID = order.data.order_id;

    const pay = await call(`/api/v1/orders/${orderID}/pay`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${buyerToken}`,
      },
    });
    assert.equal(pay.code, 200);
    const verify = await call(`/api/v1/merchant/orders/${orderID}/verify`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${merchantToken}`,
      },
      body: JSON.stringify({ verify_code: pay.data.verify_code }),
    });
    assert.equal(verify.code, 200);
    assert.equal(verify.data.status, 2);
    return orderID;
  };

  const orderA = await createAndVerify();
  const orderB = await createAndVerify();
  const orderC = await createAndVerify();

  const settleSingle = await call(`/api/v1/merchant/orders/${orderA}/settle`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
  });
  assert.equal(settleSingle.code, 200);
  assert.equal(settleSingle.data.status, 6);
  assert.equal(typeof settleSingle.data.settle_no, "string");

  const settleBatch = await call("/api/v1/merchant/orders/settle/batch", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
    body: JSON.stringify({ order_ids: [orderB, orderC] }),
  });
  assert.equal(settleBatch.code, 200);
  assert.equal(settleBatch.data.count, 2);
  assert.equal(settleBatch.data.orders.every((o) => o.status === 6), true);

  const today = new Date().toISOString().slice(0, 10);
  const summary = await call(`/api/v1/merchant/settlement-summary?start_date=${today}&end_date=${today}`, {
    headers: { Authorization: `Bearer ${merchantToken}` },
  });
  assert.equal(summary.code, 200);
  assert.equal(summary.data.date_basis, "created_at");
  assert.equal(summary.data.settled_count >= 3, true);
  assert.equal(summary.data.settled_amount >= 75, true);

  const summaryBySettledAt = await call(
    `/api/v1/merchant/settlement-summary?start_date=${today}&end_date=${today}&date_basis=settled_at`,
    {
      headers: { Authorization: `Bearer ${merchantToken}` },
    }
  );
  assert.equal(summaryBySettledAt.code, 200);
  assert.equal(summaryBySettledAt.data.date_basis, "settled_at");
  assert.equal(summaryBySettledAt.data.settled_count >= 3, true);
  assert.equal(summaryBySettledAt.data.pending_verify_count, 0);
  assert.equal(summaryBySettledAt.data.verified_count, 0);
  assert.equal(summaryBySettledAt.data.refunded_count, 0);

  const settledDetails = await call(
    `/api/v1/merchant/settlement-details?start_date=${today}&end_date=${today}&bucket=settled&date_basis=settled_at`,
    {
      headers: { Authorization: `Bearer ${merchantToken}` },
    }
  );
  assert.equal(settledDetails.code, 200);
  assert.equal(settledDetails.data.date_basis, "settled_at");
  assert.equal(settledDetails.data.total >= 3, true);
  assert.equal(settledDetails.data.orders.every((o) => o.status === 6), true);

  const refundAfterSettled = await call(`/api/v1/orders/${orderA}/refund`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${buyerToken}`,
    },
    body: JSON.stringify({ reason: "已结算售后退款" }),
  });
  assert.equal(refundAfterSettled.code, 200);
  assert.equal(refundAfterSettled.data.status, 5);
  assert.equal(refundAfterSettled.data.refund_reason, "已结算售后退款");

  const approveRefundAfterSettled = await call(`/api/v1/merchant/orders/${orderA}/refund/approve`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${merchantToken}`,
    },
  });
  assert.equal(approveRefundAfterSettled.code, 200);
  assert.equal(approveRefundAfterSettled.data.status, 4);
  assert.equal(typeof approveRefundAfterSettled.data.refund_approved_at, "string");
  assert.equal(typeof approveRefundAfterSettled.data.refund_by, "number");

  const invalidDateBasis = await call(
    `/api/v1/merchant/settlement-summary?start_date=${today}&end_date=${today}&date_basis=paid_at`,
    {
      headers: { Authorization: `Bearer ${merchantToken}` },
    }
  );
  assert.equal(invalidDateBasis.code, 400);
  assert.equal(invalidDateBasis.error_code, "INVALID_DATE_BASIS");

  const invalidBucketByBasis = await call(
    `/api/v1/merchant/settlement-details?start_date=${today}&end_date=${today}&bucket=verified&date_basis=settled_at`,
    {
      headers: { Authorization: `Bearer ${merchantToken}` },
    }
  );
  assert.equal(invalidBucketByBasis.code, 400);
  assert.equal(invalidBucketByBasis.error_code, "INVALID_DATE_BASIS_BUCKET");
});

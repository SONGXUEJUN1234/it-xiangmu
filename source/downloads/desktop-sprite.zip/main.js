const { app, BrowserWindow, Tray, Menu, ipcMain, screen, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');

let win;
let tray;
const configPath = path.join(app.getPath('userData'), 'config.json');
const defaultConfig = {
  enabled: true,
  interval: 30,
  voice: true,
  startup: false,
  quietStart: '22:00',
  quietEnd: '07:00'
};

function loadConfig() {
  try { return { ...defaultConfig, ...JSON.parse(fs.readFileSync(configPath, 'utf8')) }; }
  catch { return { ...defaultConfig }; }
}
function saveConfig(config) {
  fs.mkdirSync(path.dirname(configPath), { recursive: true });
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf8');
  app.setLoginItemSettings({ openAtLogin: Boolean(config.startup) });
}
function createWindow() {
  const display = screen.getPrimaryDisplay();
  const { width, height } = display.workAreaSize;
  win = new BrowserWindow({
    width: 360, height: 465, x: width - 390, y: height - 505,
    frame: false, transparent: true, resizable: false,
    alwaysOnTop: true, skipTaskbar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  win.loadFile('index.html');
  win.setAlwaysOnTop(true, 'floating');
  win.on('closed', () => { win = null; });
}
function createTray() {
  tray = new Tray(nativeImage.createEmpty());
  tray.setToolTip('暖心桌面精灵');
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: '显示精灵', click: () => win && win.show() },
    { label: '立即发送一句', click: () => win && win.webContents.send('say-now') },
    { type: 'separator' },
    { label: '退出', click: () => app.quit() }
  ]));
}
app.whenReady().then(() => { createWindow(); createTray(); });
app.on('window-all-closed', (e) => e.preventDefault());

ipcMain.handle('get-config', () => loadConfig());
ipcMain.handle('save-config', (_, config) => { saveConfig({ ...defaultConfig, ...config }); return loadConfig(); });
ipcMain.on('hide-window', () => win && win.hide());
ipcMain.on('drag-window', (_, point) => { if (win) win.setPosition(point.x, point.y); });

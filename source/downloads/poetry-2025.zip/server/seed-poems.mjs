import "dotenv/config";
import { drizzle } from "drizzle-orm/mysql2";
import { selectedPoems } from "../shared/poems.ts";
import { poems } from "../drizzle/schema.ts";

const db = drizzle(process.env.DATABASE_URL);
for (const poem of selectedPoems) {
  await db.insert(poems).values(poem).onDuplicateKeyUpdate({
    set: { title: poem.title, body: poem.body, form: poem.form, note: poem.note },
  });
}
console.log(`Seeded ${selectedPoems.length} poems`);

# scorer.py (industrial stable)
# 用法：
#   python scorer.py path_to_json
#   python scorer.py path_to_json --pass 80 --retries 2
#
# 输出：
#   同目录下生成 <stem>_score.json

import argparse
import json
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

DEFAULT_PASS = 80


def _extract_first_json(text: str) -> Optional[str]:
    if not text:
        return None
    start = text.find("{")
    if start == -1:
        return None

    depth = 0
    in_str = False
    esc = False

    for i in range(start, len(text)):
        ch = text[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return text[start : i + 1]
    return None


def _to_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def _find_claude_cmd() -> List[str]:
    for name in ["claude", "claude.cmd", "claude.exe"]:
        p = shutil.which(name)
        if p:
            return [p]
    p_ps1 = shutil.which("claude.ps1")
    if p_ps1:
        return ["powershell", "-ExecutionPolicy", "Bypass", "-File", p_ps1]
    return []


def run_claude(prompt: str, timeout_sec: int = 3600) -> str:
    cmd = _find_claude_cmd()
    if not cmd:
        raise FileNotFoundError(
            "找不到 Claude CLI（claude/claude.cmd/claude.ps1）。请在当前 PowerShell 运行 where.exe claude 确认。"
        )

    p = subprocess.run(
        cmd,
        input=prompt,
        text=True,
        capture_output=True,
        encoding="utf-8",
        timeout=timeout_sec,
        shell=False,
    )
    if p.returncode != 0:
        msg = (p.stderr or p.stdout or "").strip()
        raise RuntimeError(f"Claude 调用失败：{msg[:400]}")
    return p.stdout or ""


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def detect_strength_scale(clues: List[Dict[str, Any]]) -> str:
    vals = []
    for c in clues:
        v = c.get("strength", None)
        if v is None:
            continue
        fv = _to_float(v, None)
        if fv is None:
            continue
        vals.append(fv)
    if not vals:
        return "unknown"
    mx = max(vals)
    if mx <= 5.5:
        return "1-5"
    return "1-10"


def summarize_for_judge(data: Dict[str, Any], max_clues: int = 16, clue_snip: int = 90) -> Dict[str, Any]:
    meta = data.get("meta", {}) or {}
    structure = data.get("structure", {}) or {}
    tc = data.get("truth_core", {}) or {}

    chars = data.get("characters") or []
    clues = data.get("clues") or []

    char_sum = []
    for c in chars[:10]:
        char_sum.append(
            {
                "name": c.get("name", ""),
                "public_background": (c.get("public_background", "") or "")[:120],
                "goal": (c.get("goal", "") or "")[:80],
                "secret": (c.get("secret", "") or "")[:120],
            }
        )

    clue_sum = []
    for c in clues[:max_clues]:
        content = (c.get("content", "") or "")
        clue_sum.append(
            {
                "id": c.get("id", ""),
                "type": c.get("type", ""),
                "appear_round": c.get("appear_round", ""),
                "strength": c.get("strength", ""),
                "misleading": c.get("misleading", False),
                "content_snip": content[:clue_snip],
            }
        )

    rounds = structure.get("rounds") or []
    round_sum = []
    for r in rounds[:6]:
        round_sum.append(
            {
                "theme": r.get("theme", ""),
                "unlock_condition": (r.get("unlock_condition", "") or "")[:120],
                "script_event": (r.get("script_event", "") or "")[:120],
            }
        )

    out = {
        "meta": {
            "title": meta.get("title", ""),
            "genre": meta.get("genre", ""),
            "player_count": meta.get("player_count", ""),
            "duration": meta.get("duration", ""),
            "difficulty": meta.get("difficulty", ""),
            "tags": meta.get("tags", []),
        },
        "structure": {
            "rounds": round_sum,
            "mechanics": structure.get("mechanics", None),
            "phase_design": structure.get("phase_design", None),
        },
        "truth_core": {
            "killer": tc.get("killer", ""),
            "crime_method": (tc.get("crime_method", "") or "")[:400],
            "motive_structure": (tc.get("motive_structure", "") or "")[:400],
            "hidden_twist": (tc.get("hidden_twist", "") or "")[:260],
            "timeline": (tc.get("timeline", []) or [])[:20],
            "real_story": (tc.get("real_story", "") or "")[:520],
        },
        "characters": char_sum,
        "clues": clue_sum,
        "counts": {
            "characters": len(chars),
            "clues": len(clues),
            "timeline": len((tc.get("timeline") or [])),
            "rounds": len((structure.get("rounds") or [])),
        },
    }
    return out


def structure_score(data: Dict[str, Any]) -> Tuple[int, Dict[str, Any]]:
    meta = data.get("meta", {}) or {}
    genre = (meta.get("genre") or data.get("genre") or "").strip() or "unknown"

    clues = data.get("clues") or []
    tc = data.get("truth_core", {}) or {}
    timeline = tc.get("timeline") or []
    rounds = (data.get("structure", {}) or {}).get("rounds") or []
    chars = data.get("characters") or []

    scale = detect_strength_scale(clues)
    if scale == "1-5":
        strong_thr = 4.0
        strong_need = 4
    elif scale == "1-10":
        strong_thr = 7.0
        strong_need = 4
    else:
        strong_thr = 7.0
        strong_need = 4

    if genre == "hardcore":
        clue_min, clue_max = 12, 16
        tl_need = 12
        round_need = 3
    else:
        clue_min, clue_max = 10, 18
        tl_need = 8
        round_need = 3

    score = 0
    breakdown = {
        "genre": genre,
        "strength_scale": scale,
        "targets": {
            "clues_range": [clue_min, clue_max],
            "strong_threshold": strong_thr,
            "strong_need": strong_need,
            "timeline_need": tl_need,
            "round_need": round_need,
            "characters_range": [5, 8],
        },
        "checks": {},
    }

    # clues count (20)
    cnum = len(clues)
    ok_clues = (clue_min <= cnum <= clue_max)
    score += 20 if ok_clues else max(0, 20 - abs(cnum - clue_min) * 2)
    breakdown["checks"]["clues_count"] = {"value": cnum, "ok": ok_clues, "weight": 20}

    # strong clues (20)
    strong = [c for c in clues if _to_float(c.get("strength", 0), 0) >= strong_thr]
    ok_strong = len(strong) >= strong_need
    score += 20 if ok_strong else int(20 * (len(strong) / max(1, strong_need)))
    breakdown["checks"]["strong_clues"] = {"value": len(strong), "ok": ok_strong, "weight": 20}

    # timeline (20)
    tnum = len(timeline)
    ok_tl = tnum >= tl_need
    score += 20 if ok_tl else int(20 * (tnum / max(1, tl_need)))
    breakdown["checks"]["timeline"] = {"value": tnum, "ok": ok_tl, "weight": 20}

    # rounds (15)
    rnum = len(rounds)
    ok_rounds = rnum >= round_need
    score += 15 if ok_rounds else int(15 * (rnum / max(1, round_need)))
    breakdown["checks"]["rounds"] = {"value": rnum, "ok": ok_rounds, "weight": 15}

    # motive (10)
    motive_ok = bool((tc.get("motive_structure") or "").strip())
    score += 10 if motive_ok else 0
    breakdown["checks"]["motive_structure"] = {"ok": motive_ok, "weight": 10}

    # characters (15)
    chnum = len(chars)
    ok_chars = (5 <= chnum <= 8)
    score += 15 if ok_chars else max(0, 15 - abs(chnum - 6) * 3)
    breakdown["checks"]["characters"] = {"value": chnum, "ok": ok_chars, "weight": 15}

    score = max(0, min(100, int(score)))
    return score, breakdown


def judge_logic(summary: Dict[str, Any], retries: int, timeout: int) -> Tuple[int, Dict[str, Any]]:
    prompt = f"""
你是剧本杀逻辑评审专家。只基于我给你的摘要进行评估。
请对以下维度给出 0-10 的分数（允许小数）：

1 logic 逻辑自洽
2 motive 动机合理性
3 clue_balance 线索公平性
4 difficulty_control 难度控制
5 ending_impact 结尾冲击力

只输出严格 JSON，不要输出任何多余文本，格式如下：
{{
  "logic": 0-10,
  "motive": 0-10,
  "clue_balance": 0-10,
  "difficulty_control": 0-10,
  "ending_impact": 0-10,
  "fatal_flaws": ["最多3条致命问题，短句"]
}}

摘要：
{json.dumps(summary, ensure_ascii=False)}
""".strip()

    last_err = ""
    for _ in range(max(1, retries)):
        try:
            out = run_claude(prompt, timeout_sec=timeout)
            js = _extract_first_json(out)
            if not js:
                last_err = "未抽取到JSON"
                continue
            obj = json.loads(js)
            vals = [
                _to_float(obj.get("logic", 0)),
                _to_float(obj.get("motive", 0)),
                _to_float(obj.get("clue_balance", 0)),
                _to_float(obj.get("difficulty_control", 0)),
                _to_float(obj.get("ending_impact", 0)),
            ]
            avg10 = sum(vals) / 5.0
            total100 = int(round(avg10 * 10))
            detail = {
                "logic": vals[0],
                "motive": vals[1],
                "clue_balance": vals[2],
                "difficulty_control": vals[3],
                "ending_impact": vals[4],
                "avg_10": avg10,
                "fatal_flaws": obj.get("fatal_flaws", []),
            }
            return total100, detail
        except Exception as e:
            last_err = str(e)
            continue

    return 0, {"error": last_err}


def judge_market(summary: Dict[str, Any], retries: int, timeout: int) -> Tuple[int, Dict[str, Any]]:
    prompt = f"""
你是剧本杀市场策划。只基于我给你的摘要进行评估。
请对以下维度给出 0-10 的分数（允许小数）：

1 title 标题吸引力
2 rarity 题材稀缺度
3 spread 传播话题性
4 operation 店家可操作性

只输出严格 JSON，不要输出任何多余文本，格式如下：
{{
  "title": 0-10,
  "rarity": 0-10,
  "spread": 0-10,
  "operation": 0-10,
  "sell_points": ["最多3条卖点短句"],
  "risks": ["最多3条风险短句"]
}}

摘要：
{json.dumps(summary, ensure_ascii=False)}
""".strip()

    last_err = ""
    for _ in range(max(1, retries)):
        try:
            out = run_claude(prompt, timeout_sec=timeout)
            js = _extract_first_json(out)
            if not js:
                last_err = "未抽取到JSON"
                continue
            obj = json.loads(js)
            vals = [
                _to_float(obj.get("title", 0)),
                _to_float(obj.get("rarity", 0)),
                _to_float(obj.get("spread", 0)),
                _to_float(obj.get("operation", 0)),
            ]
            avg10 = sum(vals) / 4.0
            total100 = int(round(avg10 * 10))
            detail = {
                "title": vals[0],
                "rarity": vals[1],
                "spread": vals[2],
                "operation": vals[3],
                "avg_10": avg10,
                "sell_points": obj.get("sell_points", []),
                "risks": obj.get("risks", []),
            }
            return total100, detail
        except Exception as e:
            last_err = str(e)
            continue

    return 0, {"error": last_err}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("json_path")
    ap.add_argument("--pass", dest="pass_threshold", type=int, default=DEFAULT_PASS)
    ap.add_argument("--retries", type=int, default=2)
    ap.add_argument("--timeout", type=int, default=3600)
    args = ap.parse_args()

    path = Path(args.json_path)
    if not path.exists():
        raise SystemExit(f"找不到文件：{path}")

    data = load_json(path)

    print("结构评分中...")
    s1, s1_detail = structure_score(data)

    summary = summarize_for_judge(data)

    print("逻辑评分中...")
    s2, s2_detail = judge_logic(summary, retries=args.retries, timeout=args.timeout)

    print("商业评分中...")
    s3, s3_detail = judge_market(summary, retries=args.retries, timeout=args.timeout)

    final_score = int(round(s1 * 0.4 + s2 * 0.4 + s3 * 0.2))
    passed = final_score >= args.pass_threshold

    result = {
        "structure_score": s1,
        "logic_score": s2,
        "market_score": s3,
        "final_score": final_score,
        "pass": passed,
        "details": {
            "structure": s1_detail,
            "logic": s2_detail,
            "market": s3_detail,
        },
    }

    out_path = path.parent / (path.stem + "_score.json")
    write_json(out_path, result)

    print("最终评分:", final_score)
    print("是否通过:", passed)
    print("评分文件:", out_path)


if __name__ == "__main__":
    main()
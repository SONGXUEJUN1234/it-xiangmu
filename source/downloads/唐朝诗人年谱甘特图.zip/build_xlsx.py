# -*- coding: utf-8 -*-
"""唐朝诗人年谱甘特图 · 生成脚本
读 data/*.csv → 渲染 唐朝诗人年谱甘特图.xlsx（7 sheet）
改数据后重跑本脚本即可重新生成。
"""
import csv
import sys
from collections import defaultdict
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

from openpyxl import Workbook
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
OUT = BASE / "唐朝诗人年谱甘特图.xlsx"

# ---------- 参数 ----------
YEAR_START, STEP, YEAR_END = 580, 5, 929
BUCKET_STARTS = list(range(YEAR_START, YEAR_END + 1, STEP))  # 70 桶
FIRST_COL = 4  # D 列起为年份桶

# 色板（dataviz 验证通过，见规格 5.3）
REGION_COLORS = {"两京": "FF2A78D6", "江南": "FFEB6834", "蜀中": "FF1BAF7A", "荆湘": "FFEDA100",
                 "中原": "FFE87BA4", "岭南": "FF008300", "西北": "FF4A3AA7", "不详": "FF898781"}
REGION_NAMES = {"两京": "两京（长安·洛阳）", "江南": "江南（吴越·淮南·闽）", "蜀中": "蜀中（剑南·巴蜀）",
                "荆湘": "荆湘（荆南·湖南·鄂岳）", "中原": "中原·河东·河北", "岭南": "岭南·西南",
                "西北": "西北边地（陇右·河西·安西）", "不详": "不详"}
TYPE_COLORS = {"京官": "FF2A78D6", "地方官": "FF1BAF7A", "贬谪": "FFE34948", "军幕": "FFEDA100",
               "漫游": "FFE87BA4", "隐居": "FF008300", "科举": "FF4A3AA7", "未仕": "FF898781",
               "不详": "FF898781"}
TYPE_NAMES = {"京官": "京官任职", "地方官": "地方任职", "贬谪": "贬谪流放", "军幕": "边塞军幕",
              "漫游": "漫游", "隐居": "隐居·方外", "科举": "科举·入仕过渡", "未仕": "未仕/布衣",
              "不详": "生平不详"}

INK, INK2, MUTED, GRID, WHITE = "FF0B0B0B", "FF52514E", "FF898781", "FFE1E0D9", "FFFFFFFF"
EVENT_INK = "FF8C2B2B"
PERIODS = [("初唐", 618, 712), ("盛唐", 712, 766), ("中唐", 766, 835), ("晚唐", 835, 907)]
PERIOD_TINT = {"初唐": "FFCDE2FB", "盛唐": "FFD7F0E2", "中唐": "FFFBE8CD", "晚唐": "FFF6D7DC"}


def read_csv(name):
    with open(DATA / name, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def load_all():
    poets = read_csv("poets.csv")
    for p in poets:
        p["birth"], p["death"] = int(p["birth"]), int(p["death"])
        p["birth_certain"], p["death_certain"] = int(p["birth_certain"]), int(p["death_certain"])
    segments = read_csv("segments.csv")
    for s in segments:
        s["start"], s["end"] = int(s["start"]), int(s["end"])
    events = read_csv("events.csv")
    for e in events:
        e["year"], e["ismajor"] = int(e["year"]), int(e["ismajor"])
    encounters = read_csv("encounters.csv")
    return poets, segments, events, encounters


def check_tiling(poets, segments):
    by_poet = defaultdict(list)
    for s in segments:
        by_poet[s["poet_id"]].append(s)
    errors = []
    for p in poets:
        segs = sorted(by_poet.get(p["id"], []), key=lambda s: s["start"])
        if not segs:
            errors.append(f"{p['name']}：无片段")
            continue
        cur = p["birth"]
        for s in segs:
            if s["start"] != cur:
                errors.append(f"{p['name']}：{s['start']} 年断链（期望 {cur}）")
            if s["end"] < s["start"]:
                errors.append(f"{p['name']}：{s['start']}-{s['end']} 起止倒序")
            cur = s["end"] + 1
        if cur != p["death"] + 1:
            errors.append(f"{p['name']}：末段止于 {cur - 1}，卒年 {p['death']}")
    return errors


def bucket_seg_map(segs):
    """桶 → 段。
    第一轮：相对覆盖度 = 重叠年数 / min(段长, 桶长) 最高者（同率取重叠多、起年晚），
    保证短段（如 1 年的贬谪）能占到自己所在的桶。
    第二轮（救济）：≥3 年却无桶的段（如被相邻短段挤出安西幕、河西幕等关键经历），
    从其重叠桶中抢一个回来——优先抢"主段拥有桶数多"的桶，其次重叠大、桶更晚。
    失去桶的 ≤2 年短段降为文字标签（label_positions 兜底）。"""
    assign = {}
    for idx, bs in enumerate(BUCKET_STARTS):
        be = bs + STEP - 1
        best = None
        for s in segs:
            ov = min(s["end"], be) - max(s["start"], bs) + 1
            if ov <= 0:
                continue
            ratio = round(ov / min(s["end"] - s["start"] + 1, STEP), 6)
            cand = (ratio, ov, s["start"])
            if best is None or cand > best[0]:
                best = (cand, s)
        if best is not None:
            assign[idx] = best[1]

    def slen(s):
        return s["end"] - s["start"] + 1

    owner = {}
    for sg in assign.values():
        owner[id(sg)] = owner.get(id(sg), 0) + 1
    for s in sorted(segs, key=lambda s: (-slen(s), s["start"])):
        if any(sg is s for sg in assign.values()) or slen(s) < 3:
            continue
        cand_idx = []
        for idx, bs in enumerate(BUCKET_STARTS):
            be = bs + STEP - 1
            if idx in assign and min(s["end"], be) - max(s["start"], bs) + 1 > 0:
                cand_idx.append(idx)
        if not cand_idx:
            continue

        def keyf(idx, s=s):
            main = assign[idx]
            bs, be = BUCKET_STARTS[idx], BUCKET_STARTS[idx] + STEP - 1
            ov = min(s["end"], be) - max(s["start"], bs) + 1
            return (owner.get(id(main), 0), ov, idx)

        target = max(cand_idx, key=keyf)
        owner[id(assign[target])] -= 1
        owner[id(s)] = owner.get(id(s), 0) + 1
        assign[target] = s
    return assign


def bucket_color_map(segs, key, palette=None):
    return {i: s[key] for i, s in bucket_seg_map(segs).items()}


def label_positions(segs, key, palette):
    """每段文字标签放哪一桶：该段着色桶中最接近段中点者。"""
    seg_of_bucket = bucket_seg_map(segs)
    out = {}
    for s in segs:
        cand = [i for i, sg in seg_of_bucket.items() if sg is s]
        if not cand:
            continue
        mid_year = (s["start"] + s["end"]) // 2
        out[min(cand, key=lambda i: abs((BUCKET_STARTS[i] + 2) - mid_year))] = s
    # 未占到桶的段（含骑跨型长段）：在其所在桶落文字标签；被占则试相邻桶，保证不丢信息
    for s in segs:
        if any(out[i] is s for i in out):
            continue
        mid_year = (s["start"] + s["end"]) // 2
        target = max(0, min(len(BUCKET_STARTS) - 1, (mid_year - YEAR_START) // STEP))
        for t in (target, target - 1, target + 1):
            if 0 <= t < len(BUCKET_STARTS) and t not in out:
                out[t] = s
                break
    return out, {i: sg[key] for i, sg in seg_of_bucket.items()}


def life_disp(p):
    b = ("约" if not p["birth_certain"] else "") + str(p["birth"])
    d = ("约" if not p["death_certain"] else "") + str(p["death"])
    return f"{b}-{d}"


thin = Side(style="thin", color=GRID)
hair = Side(style="hair", color=GRID)
gap_side = Side(style="medium", color=WHITE)
event_side = Side(style="medium", color="FF5A5A55")


def build_gantt(ws, poets, segments, events, key, palette, title):
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "D5"
    ws.column_dimensions["A"].width = 4.5
    ws.column_dimensions["B"].width = 10.5
    ws.column_dimensions["C"].width = 11.5
    for i in range(len(BUCKET_STARTS)):
        ws.column_dimensions[get_column_letter(FIRST_COL + i)].width = 4.3

    last_col = FIRST_COL + len(BUCKET_STARTS) - 1
    lc = get_column_letter(last_col)

    # 行1 标题
    ws.merge_cells(f"A1:{lc}1")
    c = ws["A1"]
    c.value = title
    c.font = Font(name="微软雅黑", size=13, bold=True, color=INK)
    c.alignment = Alignment(vertical="center")
    ws.row_dimensions[1].height = 24

    # 行2 分期带（桶按中点归属分期，合并连续同段，互不重叠）
    def bucket_period(mid):
        for name, y0, y1 in PERIODS:
            if y0 <= mid < y1:
                return name
        return "晚唐" if mid >= 907 else None

    runs = []
    for i, bs in enumerate(BUCKET_STARTS):
        pname = bucket_period(bs + 2)
        if pname and runs and runs[-1][0] == pname:
            runs[-1][2] = i
        elif pname:
            runs.append([pname, i, i])
    for name, i0, i1 in runs:
        c0, c1 = FIRST_COL + i0, FIRST_COL + i1
        if c1 > c0:
            ws.merge_cells(start_row=2, start_column=c0, end_row=2, end_column=c1)
        cell = ws.cell(row=2, column=c0, value=name)
        cell.font = Font(name="微软雅黑", size=9, bold=True, color=INK2)
        cell.alignment = Alignment(horizontal="center", vertical="center")
        f = PatternFill("solid", start_color=PERIOD_TINT[name], end_color=PERIOD_TINT[name])
        for cc in range(c0, c1 + 1):
            ws.cell(row=2, column=cc).fill = f
    for col, txt in ((1, "分期"), (2, ""), (3, "")):
        cell = ws.cell(row=2, column=col, value=txt)
        cell.font = Font(size=8, color=MUTED)
    ws.row_dimensions[2].height = 14

    # 行3 事件带 + 行4 桶头
    for col, txt in ((1, "大事"), (2, ""), (3, "")):
        ws.cell(row=3, column=col, value=txt).font = Font(size=8, color=MUTED)
    for e in events:
        idx = (e["year"] - YEAR_START) // STEP
        cell = ws.cell(row=3, column=FIRST_COL + idx, value=f"▎{e['year']} {e['label']}")
        cell.font = Font(size=7, bold=bool(e["ismajor"]), color=EVENT_INK)
        cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[3].height = 12

    for col, txt in ((1, "序"), (2, "诗人"), (3, "生卒")):
        cell = ws.cell(row=4, column=col, value=txt)
        cell.font = Font(size=9, bold=True, color=INK2)
    for i, bs in enumerate(BUCKET_STARTS):
        cell = ws.cell(row=4, column=FIRST_COL + i, value=bs)
        cell.font = Font(size=7, color=MUTED)
        cell.alignment = Alignment(horizontal="center")
        cell.border = Border(bottom=thin)
    ws.row_dimensions[4].height = 12

    # 事件竖线所在桶
    event_cols = {FIRST_COL + (e["year"] - YEAR_START) // STEP for e in events if e["ismajor"]}

    by_poet = defaultdict(list)
    for s in segments:
        by_poet[s["poet_id"]].append(s)

    row = 5
    seq = 0
    for pname, y0, y1 in PERIODS:
        group = [p for p in poets if p["period"] == pname]
        ws.merge_cells(start_row=row, start_column=2, end_row=row, end_column=last_col)
        cell = ws.cell(row=row, column=2, value=f"{pname}（{y0}-{y1}） · {len(group)} 人")
        cell.font = Font(name="微软雅黑", size=9, bold=True, color=INK2)
        cell.alignment = Alignment(vertical="center")
        tint = PatternFill("solid", start_color=PERIOD_TINT[pname], end_color=PERIOD_TINT[pname])
        for cc in range(1, last_col + 1):
            ws.cell(row=row, column=cc).fill = tint
        ws.row_dimensions[row].height = 15
        row += 1
        for p in group:
            seq += 1
            segs = sorted(by_poet[p["id"]], key=lambda s: s["start"])
            labels, colored = label_positions(segs, key, palette)
            bar_row, lab_row = row, row + 1
            ws.row_dimensions[bar_row].height = 9.5
            ws.row_dimensions[lab_row].height = 13
            for rr, val, font in ((bar_row, seq, Font(size=8, color=MUTED)),
                                  (lab_row, p["name"], Font(name="微软雅黑", size=10, bold=True, color=INK)),
                                  (lab_row + 0, None, None)):
                pass
            ws.cell(row=bar_row, column=1, value=seq).font = Font(size=8, color=MUTED)
            ws.cell(row=bar_row, column=1).alignment = Alignment(horizontal="center", vertical="center")
            ws.merge_cells(start_row=bar_row, start_column=1, end_row=lab_row, end_column=1)
            ws.merge_cells(start_row=bar_row, start_column=2, end_row=lab_row, end_column=2)
            ws.merge_cells(start_row=bar_row, start_column=3, end_row=lab_row, end_column=3)
            name_c = ws.cell(row=bar_row, column=2, value=p["name"])
            name_c.font = Font(name="微软雅黑", size=10, bold=True, color=INK)
            name_c.alignment = Alignment(horizontal="right", vertical="center")
            life_c = ws.cell(row=bar_row, column=3, value=life_disp(p))
            life_c.font = Font(size=8, color=INK2)
            life_c.alignment = Alignment(horizontal="center", vertical="center")

            prev_key = None
            for i in range(len(BUCKET_STARTS)):
                col = FIRST_COL + i
                cell = ws.cell(row=bar_row, column=col)
                k = colored.get(i)
                left = right = None
                if k is not None:
                    color = palette[k]
                    cell.fill = PatternFill("solid", start_color=color, end_color=color)
                    if k != prev_key and prev_key is not None:
                        left = gap_side          # 段间白色隔断（2px gap）
                    prev_key = k
                if col in event_cols:
                    left = event_side            # 重大事件竖线优先
                if left or right:
                    cell.border = Border(left=left, right=right)
                lab_cell = ws.cell(row=lab_row, column=col)
                lab_cell.border = Border(bottom=hair)
                if col in event_cols:
                    old = lab_cell.border
                    lab_cell.border = Border(left=event_side, bottom=hair)
            for i, s in labels.items():
                cell = ws.cell(row=lab_row, column=FIRST_COL + i, value=s["label"])
                cell.font = Font(size=7.5, color=INK2)
                cell.alignment = Alignment(horizontal="left", vertical="center")
            row += 2
    return row


def build_readme(ws):
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 2
    ws.column_dimensions["B"].width = 6
    ws.column_dimensions["C"].width = 100
    ws["B1"] = "唐朝诗人年谱甘特图"
    ws["B1"].font = Font(name="微软雅黑", size=16, bold=True, color=INK)
    lines = [
        ("h", "怎么看这张图"),
        ("t", "· 每位诗人一行甘特条，横轴每格 5 年（列头数字为该格起始年），条上颜色 = 该时段的主要居留地或主要身份。"),
        ("t", "· 「甘特·地点」按地理大区着色：同一年两行同色 = 两位诗人同处一地（看交集用这张）。"),
        ("t", "· 「甘特·类型」按人生类型着色：一眼看出谁仕途顺遂、谁长期贬谪漂泊。"),
        ("t", "· 每条色带下方一行小字是「地点·身份」标签；色带之间的白色隔断是分段线。"),
        ("t", "· 深色竖线 = 重大历史事件（武周革命 690、安史之乱 755、永贞革新 805、甘露之变 835、黄巢起义 875、唐亡 907）。"),
        ("t", "· 「交集」sheet：50×50 同在世年数矩阵（活公式，对角线为享年）+ 著名交游事件表。"),
        ("h", "图例 · 地理大区（甘特·地点）"),
    ]
    row = 2
    for kind, text in lines:
        if kind == "h":
            ws.cell(row=row, column=2, value=text).font = Font(name="微软雅黑", size=11, bold=True, color=INK)
        else:
            ws.cell(row=row, column=3, value=text).font = Font(size=10, color=INK2)
        row += 1
    for k in REGION_COLORS:
        cell = ws.cell(row=row, column=2, value="")
        cell.fill = PatternFill("solid", start_color=REGION_COLORS[k], end_color=REGION_COLORS[k])
        ws.merge_cells(start_row=row, start_column=2, end_row=row, end_column=2)
        ws.cell(row=row, column=3, value=REGION_NAMES[k]).font = Font(size=10, color=INK2)
        ws.row_dimensions[row].height = 12
        row += 1
    ws.cell(row=row, column=2, value="图例 · 人生类型（甘特·类型）").font = Font(name="微软雅黑", size=11, bold=True, color=INK)
    row += 1
    for k in TYPE_COLORS:
        cell = ws.cell(row=row, column=2, value="")
        cell.fill = PatternFill("solid", start_color=TYPE_COLORS[k], end_color=TYPE_COLORS[k])
        ws.cell(row=row, column=3, value=TYPE_NAMES[k]).font = Font(size=10, color=INK2)
        ws.row_dimensions[row].height = 12
        row += 1
    for text in [
        "数据口径",
        "· 生卒年取学界通行值；存疑者在「生卒」列标「约」、名录备注列记异说（如张若虚生年 647/670 两说，取 670）。",
        "· 年谱片段按「主要居留地 / 主要身份」分段，段落级精度；每人片段首尾相接铺满一生，无重叠无缝隙。",
        "· 着色规则：桶中点所在段着色；不足一格的短段按最大重叠归属，细节以文字标签与「年谱数据」表为准。",
        "· 东北边塞（幽蓟）归「中原·河东·河北」；淮南归「江南」；夔州归「蜀中」。",
        "· 维护：改 data/*.csv 后重跑 build_xlsx.py 重新生成，再跑 verify_xlsx.py 复验。",
    ]:
        if not text.startswith("·"):
            ws.cell(row=row, column=2, value=text).font = Font(name="微软雅黑", size=11, bold=True, color=INK)
        else:
            ws.cell(row=row, column=3, value=text).font = Font(size=10, color=INK2)
        row += 1


def build_roster(ws, poets):
    ws.sheet_view.showGridLines = False
    headers = ["序号", "ID", "姓名", "生年", "卒年", "享年", "生卒", "分期", "字号·称谓", "存疑备注"]
    for j, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=j, value=h)
        cell.font = Font(size=10, bold=True, color=INK2)
        cell.border = Border(bottom=thin)
    widths = [5, 6, 9, 7, 7, 7, 10, 7, 26, 30]
    for j, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(j)].width = w
    for i, p in enumerate(poets):
        r = i + 2
        vals = [i + 1, p["id"], p["name"], p["birth"], p["death"], f"=E{r}-D{r}+1",
                life_disp(p), p["period"], p["alias"], p["note"]]
        for j, v in enumerate(vals, 1):
            cell = ws.cell(row=r, column=j, value=v)
            cell.font = Font(size=10, color=INK2)
            if j in (4, 5):
                cell.alignment = Alignment(horizontal="center")
    ws.auto_filter.ref = "A1:J51"
    ws.freeze_panes = "A2"


def build_segments_sheet(ws, poets, segments):
    ws.sheet_view.showGridLines = False
    name_of = {p["id"]: p for p in poets}
    headers = ["序号", "诗人", "分期", "起年", "止年", "年数", "人生类型", "地理大区", "事件·地点", "备注"]
    for j, h in enumerate(headers, 1):
        ws.cell(row=1, column=j, value=h).font = Font(size=10, bold=True, color=INK2)
        ws.cell(row=1, column=j).border = Border(bottom=thin)
    widths = [5, 9, 7, 7, 7, 7, 12, 14, 24, 20]
    for j, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(j)].width = w
    r = 2
    for i, s in enumerate(segments, 1):
        p = name_of[s["poet_id"]]
        vals = [i, p["name"], p["period"], s["start"], s["end"], f"=E{r}-D{r}+1",
                TYPE_NAMES[s["type"]], REGION_NAMES[s["region"]], s["label"], s.get("note", "")]
        for j, v in enumerate(vals, 1):
            ws.cell(row=r, column=j, value=v).font = Font(size=10, color=INK2)
        r += 1
    ws.auto_filter.ref = f"A1:J{r - 1}"
    ws.freeze_panes = "A2"


def build_matrix(ws, poets):
    ws.sheet_view.showGridLines = False
    n = len(poets)
    ws["A1"] = "同在世年数矩阵（活公式：MAX(0,MIN(卒A,卒B)-MAX(生A,生B)+1)；对角线 = 享年）"
    ws["A1"].font = Font(name="微软雅黑", size=12, bold=True, color=INK)
    for j, p in enumerate(poets):
        col = 2 + j
        cell = ws.cell(row=2, column=col, value=p["name"])
        cell.font = Font(size=8, color=INK2)
        cell.alignment = Alignment(textRotation=90, horizontal="center")
        ws.column_dimensions[get_column_letter(col)].width = 3.2
    ws.column_dimensions["A"].width = 9
    for i, p in enumerate(poets):
        r = 3 + i
        cell = ws.cell(row=r, column=1, value=p["name"])
        cell.font = Font(size=8, color=INK2)
        for j in range(n):
            rr, cc = i + 2, j + 2  # 名录行号
            f = (f"=MAX(0,MIN('名录'!$E${rr},'名录'!$E${cc})"
                 f"-MAX('名录'!$D${rr},'名录'!$D${cc})+1)")
            cell = ws.cell(row=r, column=2 + j, value=f)
            cell.font = Font(size=7, color=INK2)
            cell.alignment = Alignment(horizontal="center")
    rng = f"B3:{get_column_letter(1 + n)}{2 + n}"
    ws.conditional_formatting.add(rng, ColorScaleRule(
        start_type="num", start_value=0, start_color="FFCDE2FB",
        mid_type="num", mid_value=25, mid_color="FF3987E5",
        end_type="num", end_value=75, end_color="FF0D366B"))
    ws.freeze_panes = "B3"


def build_encounters(ws, encounters, start_row=56):
    # 注意：交集矩阵占据 B3 起约 50 行，事件表必须放在矩阵下方，勿重叠
    ws.cell(row=start_row - 1, column=1, value="著名交游事件（含并称齐名）").font = Font(
        name="微软雅黑", size=12, bold=True, color=INK)
    headers = ["诗人甲", "诗人乙", "年份", "地点", "事件"]
    for j, h in enumerate(headers, 1):
        cell = ws.cell(row=start_row, column=j, value=h)
        cell.font = Font(size=10, bold=True, color=INK2)
        cell.border = Border(bottom=thin)
    for j, w in enumerate([10, 10, 9, 12, 44], 1):
        ws.column_dimensions[get_column_letter(j)].width = max(
            w, ws.column_dimensions[get_column_letter(j)].width or 0)
    for i, e in enumerate(encounters):
        r = start_row + 1 + i
        vals = [e["poet_a"], e["poet_b"], e["year"], e["place"], e["event"]]
        for j, v in enumerate(vals, 1):
            ws.cell(row=r, column=j, value=v).font = Font(size=10, color=INK2)


def build_events_sheet(ws, events):
    ws.sheet_view.showGridLines = False
    ws["A1"] = "历史大事年表（加粗者在甘特图上画竖线）"
    ws["A1"].font = Font(name="微软雅黑", size=12, bold=True, color=INK)
    for j, h in enumerate(["年份", "事件", "竖线"], 1):
        ws.cell(row=2, column=j, value=h).font = Font(size=10, bold=True, color=INK2)
        ws.cell(row=2, column=j).border = Border(bottom=thin)
    for j, w in enumerate([8, 28, 8], 1):
        ws.column_dimensions[get_column_letter(j)].width = w
    for i, e in enumerate(events):
        r = 3 + i
        for j, v in enumerate([e["year"], e["label"], "▎" if e["ismajor"] else ""], 1):
            cell = ws.cell(row=r, column=j, value=v)
            cell.font = Font(size=10, bold=bool(e["ismajor"]), color=INK2)


def main():
    poets, segments, events, encounters = load_all()
    errs = check_tiling(poets, segments)
    if errs:
        print("数据校验失败：")
        print("\n".join(errs))
        sys.exit(1)
    print(f"数据校验通过：{len(poets)} 位诗人、{len(segments)} 条年谱片段、"
          f"{len(events)} 条大事、{len(encounters)} 条交游事件")

    wb = Workbook()
    ws = wb.active
    ws.title = "读我"
    build_readme(ws)

    build_gantt(wb.create_sheet("甘特·地点"), poets, segments, events, "region", REGION_COLORS,
                "唐朝诗人年谱甘特图 · 按地理大区着色（每格 5 年，同列同色 = 同地同时）")
    build_gantt(wb.create_sheet("甘特·类型"), poets, segments, events, "type", TYPE_COLORS,
                "唐朝诗人年谱甘特图 · 按人生类型着色（每格 5 年，色带 = 人生阶段）")
    build_roster(wb.create_sheet("名录"), poets)
    build_segments_sheet(wb.create_sheet("年谱数据"), poets, segments)
    build_matrix(wb.create_sheet("交集"), poets)
    build_encounters(wb["交集"], encounters)
    build_events_sheet(wb.create_sheet("历史大事"), events)

    wb.save(OUT)
    print(f"已生成：{OUT}")


if __name__ == "__main__":
    main()

# 剧本杀内容工厂 UI（INIT）

本项目新增了一个基于 Streamlit 的最小 UI，用于可视化触发现有 `factory.py` 流水线。

## 新增目录

- `ui/app.py`：UI 入口。
- `services/job_runner.py`：后台任务执行、日志与状态落盘。
- `services/pipeline_service.py`：UI 调用的服务封装。

任务状态与日志写入：

- `pipeline_reports/ui_jobs/<job_id>/status.json`
- `pipeline_reports/ui_jobs/<job_id>/run.log`

## 安装依赖

```powershell
cd D:\juben
python -m pip install --upgrade pip
python -m pip install streamlit python-docx reportlab
```

## 启动 UI

```powershell
cd D:\juben
streamlit run ui/app.py
```

默认浏览器会打开本地地址（通常是 `http://localhost:8501`）。

## 当前能力（第一版）

- 在 UI 中配置 `factory.py` 常用参数。
- 后台启动任务并记录运行日志。
- 查看最近任务状态与日志。
- 浏览并下载 `release_zips/`、`release/`、`out/` 下的产物。

## 说明

- 这一版不改动核心流水线逻辑，只做可视化入口与任务管理层。
- 如果后续需要多用户并发、鉴权、远程部署，建议升级为前后端分离架构（FastAPI + React/Vue）。

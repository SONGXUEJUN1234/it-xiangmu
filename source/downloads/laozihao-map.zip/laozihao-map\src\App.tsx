import { useEffect, useMemo, useRef, useState } from "react";
import {
  Store,
  Search,
  ArrowUpRight,
  MapPin,
  SlidersHorizontal,
  ShoppingBag,
  Utensils,
  Cookie,
  Leaf,
  FlaskConical,
  Wine,
  Sparkles,
  Shirt,
  Brush,
  LayoutGrid,
  Map,
  List,
  X,
  CircleHelp,
  Database,
  ChevronRight,
  BookOpen,
  RotateCcw,
} from "lucide-react";
import { BrandImage, StorefrontArt } from "./Art";
import { HeritageMap, type Geography } from "./HeritageMap";
import { About, BrandDetail, CorrectionDialog, DataManager } from "./Dialogs";
import {
  CATEGORIES,
  EMPTY_FILTERS,
  STORAGE_KEY,
  errorMessage,
  filterBrands,
  readFilters,
  shortRegion,
  validateBrands,
  writeFilters,
  type Brand,
  type Filters,
  type Region,
} from "./model";

const icons = [
  LayoutGrid,
  Utensils,
  Cookie,
  Leaf,
  FlaskConical,
  BookOpen,
  Wine,
  Sparkles,
  Shirt,
  Brush,
];
type Data = { brands: Brand[]; regions: Region[]; geography: Geography };
async function loadData(): Promise<Data> {
  const paths = [
    "/data/brands.json",
    "/data/regions.json",
    "/data/china.geojson",
  ];
  const [raw, regions, geography] = await Promise.all(
    paths.map(async (p) => {
      const res = await fetch(p);
      if (!res.ok) throw new Error(`无法加载 ${p}（${res.status}）`);
      return res.json();
    }),
  );
  if (!Array.isArray(regions) || !geography.features?.length)
    throw new Error("地图与地区数据格式错误");
  return { brands: validateBrands(raw, regions), regions, geography };
}

export default function App() {
  const [data, setData] = useState<Data | null>(null);
  const [loadError, setLoadError] = useState("");
  const [retry, setRetry] = useState(0);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [filters, setFilters] = useState<Filters>(() =>
    readFilters(window.location.search),
  );
  const [selectedId, setSelectedId] = useState<string | undefined>(
    () => new URLSearchParams(window.location.search).get("brand") || undefined,
  );
  const [modal, setModal] = useState<"about" | "manager" | null>(null);
  const [correction, setCorrection] = useState<Brand | null>(null);
  const [mobileView, setMobileView] = useState<"map" | "list">("map");
  const [desktopView, setDesktopView] = useState<"split" | "grid">("split");
  const [toast, setToast] = useState("");
  const [localMode, setLocalMode] = useState(false);
  const [sort, setSort] = useState("curated");
  const [listLimit, setListLimit] = useState(60);
  const searchRef = useRef<HTMLInputElement>(null);
  useEffect(() => {
    let cancelled = false;
    setLoadError("");
    loadData()
      .then((next) => {
        if (cancelled) return;
        setData(next);
        let initial = next.brands;
        try {
          const local = localStorage.getItem(STORAGE_KEY);
          if (local) {
            initial = validateBrands(JSON.parse(local), next.regions);
            setLocalMode(true);
          }
        } catch {
          setToast("本地存储不可用或数据有误，已加载内置资料，未删除原存储。");
        }
        setBrands(initial);
        setFilters((f) => {
          const region = next.regions.find((r) => r.name === f.province);
          return {
            ...f,
            province: region?.name || "",
            city:
              region &&
              (region.name === f.city ||
                region.cities.some((c) => c.name === f.city))
                ? f.city
                : "",
          };
        });
      })
      .catch((error) => {
        if (!cancelled) setLoadError(errorMessage(error));
      });
    return () => {
      cancelled = true;
    };
  }, [retry]);
  useEffect(() => {
    if (!data) return;
    window.history.replaceState(null, "", writeFilters(filters, selectedId));
  }, [filters, selectedId, data]);
  useEffect(() => {
    const onBack = () => {
      setFilters(readFilters(window.location.search));
      setSelectedId(
        new URLSearchParams(window.location.search).get("brand") || undefined,
      );
    };
    window.addEventListener("popstate", onBack);
    return () => window.removeEventListener("popstate", onBack);
  }, []);
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(""), 5500);
    return () => clearTimeout(timer);
  }, [toast]);
  useEffect(() => {
    if (data && selectedId && !brands.some((b) => b.id === selectedId)) {
      setSelectedId(undefined);
      setToast("没有找到这个品牌，已返回地图。");
    }
  }, [data, brands, selectedId]);
  const filtered = useMemo(() => {
    const result = filterBrands(brands, filters);
    if (sort === "name")
      return result.sort((a, b) => a.name.localeCompare(b.name, "zh-CN"));
    if (sort === "shop")
      return result.sort((a, b) => Number(!!b.shop) - Number(!!a.shop));
    return result;
  }, [brands, filters, sort]);
  useEffect(() => {
    setListLimit(60);
  }, [filters, sort]);
  const categoryCounts = useMemo(
    () =>
      CATEGORIES.map(
        (c) => filterBrands(brands, { ...filters, category: c.id }).length,
      ),
    [brands, filters],
  );
  const selected = brands.find((b) => b.id === selectedId);
  const provinceCount = new Set(brands.map((b) => b.province)).size;
  const shoppingCount = brands.filter((b) => b.shop).length;
  const region = data?.regions.find((r) => r.name === filters.province);
  const cityOptions = [
    ...new Set(
      brands.filter((b) => b.province === filters.province).map((b) => b.city),
    ),
  ];
  const hasFilters =
    filters.query ||
    filters.province ||
    filters.city ||
    filters.category !== "all" ||
    filters.shopping;
  const chooseProvince = (province: string) =>
    setFilters((f) => ({ ...f, province, city: "" }));
  const reset = () => {
    setFilters({ ...EMPTY_FILTERS });
    setSelectedId(undefined);
  };
  function saveBrands(next: Brand[]) {
    validateBrands(next, data?.regions);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    setBrands(next);
    setLocalMode(true);
  }
  if (loadError)
    return (
      <div className="load-state">
        <Store size={40} />
        <h1>资料暂时未能加载</h1>
        <p>{loadError}</p>
        <button
          className="primary-button"
          onClick={() => setRetry((r) => r + 1)}
        >
          重新加载
        </button>
      </div>
    );
  if (!data)
    return (
      <div className="load-state">
        <Store size={40} />
        <h1>正在展开老字号地图</h1>
        <p>加载地方风物与品牌档案…</p>
      </div>
    );
  return (
    <>
      <header className="site-header">
        <button
          className="wordmark"
          onClick={reset}
          aria-label="老字号地图首页"
        >
          <span className="logo-mark">
            <Store size={25} strokeWidth={1.6} />
          </span>
          <span>
            <strong>老字号地图</strong>
            <small>一方风土 · 一份传承</small>
          </span>
        </button>
        <nav aria-label="主导航">
          <button
            className={!modal ? "active" : ""}
            onClick={() => {
              setModal(null);
              document
                .getElementById("explore")
                ?.scrollIntoView({ behavior: "smooth" });
            }}
          >
            发现老字号
          </button>
          <button
            className={modal === "about" ? "active" : ""}
            onClick={() => setModal("about")}
          >
            收录说明 <ArrowUpRight size={13} />
          </button>
        </nav>
        <button className="header-about" onClick={() => setModal("manager")}>
          <Database size={15} />
          <span>数据工作台</span>
        </button>
      </header>
      <main>
        <section className="hero">
          <div className="hero-copy">
            <span className="eyebrow">寻一方风物 · 识一份匠心</span>
            <h1>
              好东西，<em>有来处。</em>
            </h1>
            <p>
              从一盏茶、一味香，到一桌家乡菜。
              <br className="mobile-break" />
              在地图上，遇见值得记住的老字号。
            </p>
          </div>
          <StorefrontArt />
          <div className="hero-stats">
            <div>
              <strong>
                {brands.length}
                <span>家</span>
              </strong>
              <small>名录在册品牌</small>
            </div>
            <div>
              <strong>
                {provinceCount}
                <span>地</span>
              </strong>
              <small>覆盖省级地区</small>
            </div>
            <div>
              <strong>
                {shoppingCount}
                <span>家</span>
              </strong>
              <small>有来源网购入口</small>
            </div>
          </div>
          <span className="edition-label">
            全量名录版 <span>2025-12 版</span>
          </span>
        </section>
        <section className="explorer" id="explore" aria-label="探索老字号">
          <div className="discovery-toolbar">
            <label className="search-box">
              <Search size={19} />
              <input
                ref={searchRef}
                aria-label="搜索品牌、城市、特色产品"
                placeholder="搜一搜品牌、城市或特色产品…"
                value={filters.query}
                maxLength={100}
                onChange={(e) =>
                  setFilters((f) => ({ ...f, query: e.target.value }))
                }
              />
              {filters.query && (
                <button
                  aria-label="清空搜索"
                  onClick={() => {
                    setFilters((f) => ({ ...f, query: "" }));
                    searchRef.current?.focus();
                  }}
                >
                  <X size={16} />
                </button>
              )}
              <span className="search-hint">风物有迹可寻</span>
            </label>
            <div className="region-picker">
              <MapPin size={17} />
              <select
                aria-label="选择省份"
                value={filters.province}
                onChange={(e) => chooseProvince(e.target.value)}
              >
                <option value="">全国地区</option>
                {data.regions.map((r) => (
                  <option key={r.code} value={r.name}>
                    {r.name}
                  </option>
                ))}
              </select>
              <span className="picker-divider" />
              <select
                aria-label="选择城市"
                value={filters.city}
                disabled={!region}
                onChange={(e) =>
                  setFilters((f) => ({ ...f, city: e.target.value }))
                }
              >
                <option value="">全部城市</option>
                {cityOptions.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <label className="shopping-toggle">
              <input
                type="checkbox"
                checked={filters.shopping}
                onChange={(e) =>
                  setFilters((f) => ({ ...f, shopping: e.target.checked }))
                }
              />
              <span className="switch-track" />
              <ShoppingBag size={15} />
              <span>仅看可网购</span>
            </label>
          </div>
          <div className="category-row" role="group" aria-label="品牌分类">
            {CATEGORIES.map((category, i) => {
              const Icon = icons[i];
              return (
                <button
                  key={category.id}
                  className={`category-button ${filters.category === category.id ? "active" : ""}`}
                  aria-pressed={filters.category === category.id}
                  onClick={() =>
                    setFilters((f) => ({ ...f, category: category.id }))
                  }
                >
                  <Icon size={17} strokeWidth={1.6} />
                  <span>{category.label}</span>
                  <small>{categoryCounts[i]}</small>
                </button>
              );
            })}
          </div>
          <div className="results-heading">
            <div>
              <h2>
                {filters.province ? shortRegion(filters.province) : "全国"}风物
                <span className="result-count" aria-live="polite">
                  {filtered.length} 家老字号
                </span>
              </h2>
              {hasFilters ? (
                <button className="clear-filters" onClick={reset}>
                  <RotateCcw size={12} /> 清除筛选
                </button>
              ) : (
                <span className="result-subtitle">
                  山河之间，发现熟悉与惊喜
                </span>
              )}
            </div>
            <div className="result-controls">
              <label className="sort-picker">
                <SlidersHorizontal size={14} />
                <select
                  aria-label="排序方式"
                  value={sort}
                  onChange={(e) => setSort(e.target.value)}
                >
                  <option value="curated">默认顺序</option>
                  <option value="shop">可网购优先</option>
                  <option value="name">品牌名称排序</option>
                </select>
              </label>
              <div className="desktop-view-toggle">
                <button
                  aria-label="地图与列表"
                  aria-pressed={desktopView === "split"}
                  className={desktopView === "split" ? "active" : ""}
                  onClick={() => setDesktopView("split")}
                >
                  <Map size={16} />
                </button>
                <button
                  aria-label="卡片网格"
                  aria-pressed={desktopView === "grid"}
                  className={desktopView === "grid" ? "active" : ""}
                  onClick={() => setDesktopView("grid")}
                >
                  <LayoutGrid size={16} />
                </button>
              </div>
            </div>
          </div>
          <div className="mobile-view-toggle">
            <button
              className={mobileView === "map" ? "active" : ""}
              onClick={() => setMobileView("map")}
            >
              <Map size={15} /> 看地图
            </button>
            <button
              className={mobileView === "list" ? "active" : ""}
              onClick={() => setMobileView("list")}
            >
              <List size={15} /> 逛品牌 · {filtered.length}
            </button>
          </div>
          <div
            className={`explore-layout ${desktopView === "grid" ? "grid-mode" : ""} mobile-${mobileView}`}
          >
            <section className="brand-list-panel" aria-label="品牌列表">
              <div className="list-topline">
                <span>一店一故事</span>
                <span>
                  {filtered.length
                    ? "点击卡片，了解与选购"
                    : "试试其他地区或分类"}
                </span>
              </div>
              <div className="brand-list">
                {filtered.slice(0, listLimit).map((brand) => (
                  <button
                    className={`brand-card ${selectedId === brand.id ? "selected" : ""}`}
                    key={brand.id}
                    onClick={() => setSelectedId(brand.id)}
                    aria-label={`查看${brand.name}详情`}
                  >
                    <BrandImage
                      brand={brand}
                      compact={desktopView !== "grid"}
                    />
                    <div className="brand-card-content">
                      <div className="card-title">
                        <h3>{brand.name}</h3>
                        <ChevronRight size={16} />
                      </div>
                      <p className="card-location">
                        <MapPin size={11} />
                        {brand.city === brand.province
                          ? shortRegion(brand.province)
                          : `${shortRegion(brand.province)} · ${shortRegion(brand.city)}`}
                      </p>
                      <p className="card-description">{brand.description}</p>
                      <div className="card-bottom">
                        <span
                          className="category-tag"
                          style={{
                            color: CATEGORIES.find(
                              (c) => c.id === brand.categories[0],
                            )?.color,
                          }}
                        >
                          {
                            CATEGORIES.find((c) => c.id === brand.categories[0])
                              ?.label
                          }
                        </span>
                        {brand.shop ? (
                          <span className="shop-badge">
                            <ShoppingBag size={11} /> 网购入口
                          </span>
                        ) : (
                          <span className="pending-link">网购待核实</span>
                        )}
                      </div>
                    </div>
                  </button>
                ))}
                {!filtered.length && (
                  <div className="empty-state">
                    <Search size={32} strokeWidth={1} />
                    <h3>这一站，还在整理中</h3>
                    <p>
                      当前筛选没有匹配的品牌。
                      <br />
                      未收录不代表当地没有老字号。
                    </p>
                    <button className="primary-button" onClick={reset}>
                      查看全部品牌
                    </button>
                  </div>
                )}
                {filtered.length > listLimit && (
                  <button
                    className="load-more-button"
                    onClick={() => setListLimit((n) => n + 60)}
                  >
                    加载更多 · 还有 {filtered.length - listLimit} 家
                  </button>
                )}
              </div>
              <div className="list-bottom">
                <BookOpen size={12} /> 有出处的资料，有分寸的推荐
              </div>
            </section>
            <HeritageMap
              geography={data.geography}
              regions={data.regions}
              brands={filtered}
              province={filters.province}
              city={filters.city}
              selectedId={selectedId}
              onProvince={chooseProvince}
              onCity={(city) => setFilters((f) => ({ ...f, city }))}
              onBrand={(brand) => setSelectedId(brand.id)}
              onReset={() =>
                setFilters((f) => ({ ...f, province: "", city: "" }))
              }
            />
          </div>
          <div className="collection-note">
            <span>
              <CircleHelp size={14} />{" "}
              已按商务部名录（2025年12月版）全量收录；精简条目的品类标签为初步归类，当前采用品类插画，非品牌实拍。
              {localMode && " · 当前使用本地修改数据"}
            </span>
            <button onClick={() => setModal("about")}>
              了解收录标准 <ArrowUpRight size={12} />
            </button>
          </div>
        </section>
      </main>
      <footer className="site-footer">
        <span>
          <Store size={14} /> 老字号地图
        </span>
        <p>独立整理 · 不代表官方 · 交易与售后由第三方平台提供</p>
        <button onClick={() => setModal("about")}>资料与使用说明</button>
      </footer>
      {selected && !correction && (
        <BrandDetail
          brand={selected}
          onClose={() => setSelectedId(undefined)}
          onLocate={() => {
            setFilters({
              ...EMPTY_FILTERS,
              province: selected.province,
              city: selected.city,
            });
            setSelectedId(undefined);
            setDesktopView("split");
            setMobileView("map");
          }}
          onCorrection={setCorrection}
        />
      )}
      {modal === "about" && (
        <About brands={brands} onClose={() => setModal(null)} />
      )}
      {modal === "manager" && (
        <DataManager
          brands={brands}
          regions={data.regions}
          onSave={saveBrands}
          onReset={() => {
            localStorage.removeItem(STORAGE_KEY);
            setBrands(data.brands);
            setLocalMode(false);
            setToast("已恢复内置数据。");
          }}
          onClose={() => setModal(null)}
        />
      )}
      {correction && (
        <CorrectionDialog
          brand={correction}
          onClose={() => setCorrection(null)}
          onSaved={() => {
            setCorrection(null);
            setToast("已保存本地纠错草稿，可在数据工作台导出。");
          }}
        />
      )}
      {toast && (
        <div className="toast" role="status">
          {toast}
          <button aria-label="关闭提示" onClick={() => setToast("")}>
            <X size={14} />
          </button>
        </div>
      )}
    </>
  );
}

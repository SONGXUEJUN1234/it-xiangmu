# 见星 NIGHTSKY：河北四季观星网页

## 运行

```sh
npm ci
npm run client:dev -- --host 0.0.0.0
```

打开终端给出的 Vite 地址。这个页面不依赖后端、数据库、账号或 API 密钥。原有微信阅读应用代码仍保留在 `src/App.tsx` 与 `src/pages/`，当前入口 `src/main.tsx` 改为加载观星页面。

```sh
npm run test:sky
npx eslint src/observatory src/main.tsx tests/astronomy.test.ts
npm run build
npm run preview -- --host 0.0.0.0
```

`dist/` 可以部署到静态网站的根目录。不要直接双击 `index.html`，星表需要通过 HTTP 加载。离线使用已打包的星表、中文字体、12 张深空照片及 6 张精选恒星照片；未缓存恒星的巡天照片需要联网访问 CDS。

## 操作

- 地点：承德、张家口、石家庄。采用城市中心近似坐标。
- 季节：使用 2026 年 1、4、7、10 月 15 日，北京时间 22:00 作为代表夜。
- 时间轴：18:00 至次日 06:00，可拖动或播放；不是实时天气预报。
- 星图：拖动转向，点击恒星查看档案；滚轮、双指、加减按钮或键盘加减键缩放。方向键改变视角。
- 星图缩放达到 14 倍，进入当前所选天体的真实影像；也可以直接点击「进入望远镜视野」。
- 望远镜：持续缩放、拖动平移、重置。采用对数缩放状态与 Canvas 源图裁剪，避免创建超大 DOM 图片。达到浮点精度范围后只显示原图像素，没有额外真实细节。
- 搜索：中文名、英文名、星座、HIP 编号、M 天体；按 `/` 聚焦，回车选第一个结果。
- 图层：星座连线、标签、赤道网格、银河氛围与 1–6 等阈值。
- 手记：收藏天体与自由文字，仅保存到当前浏览器的 localStorage。清除浏览器数据会删除手记。
- Esc 关闭窗口、弹出菜单与展开星图。弹窗支持键盘焦点约束与焦点恢复。

## 数据与署名

- [D3-Celestial](https://github.com/ofrohn/d3-celestial)：5,044 颗恒星的 J2000 赤道坐标、视星等、B−V 色指数、中文星名与星座连线。星座文件有 89 条线图记录，含蛇夫座附近分为两部分的巨蛇座。原数据的 `starnames.json` 已合并到 `stars.6.json`，`dsos.14.json` 提取成 12 个深空目标。BSD 许可见 `public/data/LICENSE.txt`。
- [CDS HiPS2FITS](https://alasky.cds.unistra.fr/hips-image-services/hips2fits)：DSS2 彩色巡天照片。该研究使用了 CDS 提供的 hips2fits 服务。查询通过目标的实际赤经、赤纬构造，预选天体照片保存在 `public/images/`。
- [M57 哈勃照片](https://esahubble.org/images/heic1310a/)：NASA, ESA, and C. Robert O’Dell (Vanderbilt University)。`public/images/m57.jpg` 为该页面的真实观测照片，不是生成的星云图。
- Noto Sans SC / Noto Serif SC：Google Fonts 的中文界面与星名字符子集，保存在 `public/fonts/`，SIL Open Font License 见同目录 `OFL-sans.txt` 与 `OFL-serif.txt`。无需依赖运行时字体 CDN。

## 科学边界

`astronomy.ts` 将赤经、赤纬通过儒略日和格林尼治恒星时转换为当地高度角、方位角。以北为 0°，东为 90°。`SkyMap.tsx` 采用立体投影，仅绘制地平线上方天体，地平线是投影后的真实高度 0° 曲线。

星表使用 J2000 坐标，没有校正岁差、自行、大气折射、消光。未模拟太阳、月球、行星、晨昏亮度、云量或光污染。银河云雾是围绕真实银道面绘制的艺术氛围，燕山地景为艺术剪影。这是交互式观星演示，不是精密望远镜指向或观测规划软件。

实拍来自历史巡天/空间望远镜，不能表示河北此刻的望远镜实时画面。普通恒星在这些照片中仍是亮点、饱和光斑与衍射结构，不是恒星表面；持续缩放不会创造无限空间分辨率。

## 结构与验证

- `src/observatory/Observatory.tsx`：页面、季节、地点、搜索、图层、收藏与手记。
- `src/observatory/astronomy.ts`：天体目录、坐标转换与投影、影像 URL。
- `src/observatory/SkyMap.tsx`：Canvas 星图、拾取、拖动、触控与键盘交互。
- `src/observatory/UI.tsx`：弹窗、影像查看器、目标卡片。
- `tests/astronomy.test.ts`：6 组测试，覆盖 UTC+8/跨午夜、J2000 恒星时基准、方位正负、投影、完整星表、四季三地代表星可见性、12 张本地 JPEG、网络失败处理。

浏览器验证覆盖桌面与 390px 手机布局、四季切换、搜索、星等阈值、收藏、真实哈勃图片和影像缩放。星图初次绘制会等待中文字体加载，以避免 Canvas 标签使用缺字回退字体。

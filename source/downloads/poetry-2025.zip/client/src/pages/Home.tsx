import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link, useLocation, useRoute } from "wouter";
import { ArrowLeft, ArrowRight, BookOpen, CloudRain, Download, Feather, Music2, Pause, Share2, Sparkles, Volume2, VolumeX, X } from "lucide-react";
import { Streamdown } from "streamdown";
import { trpc } from "@/lib/trpc";
import { createPosterSvg } from "@shared/poster";
import { clampSoundVolume, toggleSoundMode, type SoundMode } from "@shared/soundscape";

type Poem = { id: number; title: string; body: string; form: string; note: string; interpretation?: string | null };

function escapeXml(value: string) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

function wrapText(text: string, width: number) {
  const result: string[] = [];
  for (const paragraph of text.split(/\n/)) {
    if (!paragraph) { result.push(""); continue; }
    for (let i = 0; i < paragraph.length; i += width) result.push(paragraph.slice(i, i + width));
  }
  return result;
}

function svgLines(lines: string[], x: number, y: number, lineHeight: number, className: string) {
  return `<text x="${x}" y="${y}" class="${className}">${lines.map((line, index) => `<tspan x="${x}" dy="${index === 0 ? 0 : lineHeight}">${escapeXml(line) || " "}</tspan>`).join("")}</text>`;
}

function createLegacyPosterSvg(poem: Poem, summary: string) {
  const poemLines = wrapText(poem.body, 25).slice(0, 18);
  const summaryLines = wrapText(summary, 31).slice(0, 5);
  const number = String(poem.id).padStart(2, "0");
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1440" viewBox="0 0 1080 1440">
  <rect width="1080" height="1440" fill="#f4f1ea"/>
  <rect x="42" y="42" width="996" height="1356" fill="none" stroke="#d9d3c7" stroke-width="2"/>
  <circle cx="92" cy="100" r="22" fill="none" stroke="#a24e38" stroke-width="2"/>
  <path d="M82 109 Q92 91 103 89 Q95 104 82 109Z" fill="none" stroke="#a24e38" stroke-width="2"/>
  <text x="135" y="98" class="brand">2025 诗篇</text><text x="135" y="123" class="meta">一年之内的回声</text>
  <text x="950" y="103" text-anchor="end" class="meta">${number} / 20</text>
  <line x1="92" y1="190" x2="988" y2="190" stroke="#a24e38" stroke-width="3"/>
  <text x="92" y="245" class="meta accent">${escapeXml(poem.form)} · 2025</text>
  <text x="92" y="330" class="title">${escapeXml(poem.title)}</text>
  ${svgLines(poemLines, 92, 430, 42, "poem")}
  <line x1="92" y1="1065" x2="988" y2="1065" stroke="#d9d3c7" stroke-width="2"/>
  <text x="92" y="1115" class="meta accent">AI 赏析摘要</text>
  ${svgLines(summaryLines, 92, 1165, 35, "summary")}
  <text x="92" y="1328" class="footer">从《2025》精选 · 愿每一次阅读，都把时间还给自己。</text>
  <style>
    .brand{font:600 25px 'Noto Serif SC',serif;letter-spacing:5px;fill:#28251f}.meta{font:16px 'Source Sans 3',sans-serif;letter-spacing:3px;fill:#8e897e}.accent{fill:#a24e38}.title{font:600 64px 'Noto Serif SC',serif;letter-spacing:3px;fill:#28251f}.poem{font:25px 'Noto Serif SC',serif;letter-spacing:2px;fill:#28251f}.summary{font:19px 'Noto Serif SC',serif;letter-spacing:1px;fill:#59544b}.footer{font:14px 'Source Sans 3',sans-serif;letter-spacing:2px;fill:#8e897e}
  </style>
</svg>`;
}

async function posterBlob(svg: string) {
  const image = new Image();
  const url = URL.createObjectURL(new Blob([svg], { type: "image/svg+xml;charset=utf-8" }));
  await new Promise<void>((resolve, reject) => { image.onload = () => resolve(); image.onerror = () => reject(new Error("poster render failed")); image.src = url; });
  const canvas = document.createElement("canvas"); canvas.width = 1080; canvas.height = 1600;
  canvas.getContext("2d")?.drawImage(image, 0, 0); URL.revokeObjectURL(url);
  return new Promise<Blob>((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error("poster export failed")), "image/png"));
}

function PosterLoading({ stage }: { stage: 1 | 2 }) { return <div className="poster-loading" role="status" aria-live="polite"><div className="ink-orbit"><span /><span /><span /><i /></div><p>{stage === 1 ? "让诗意慢慢浮现" : "正在铺开这一页"}</p><small>{stage === 1 ? "AI 正在阅读诗中的光与影" : "墨色、留白与余韵即将成形"}</small><div className="loading-progress"><b className={stage === 2 ? "is-rendering" : ""} /></div></div>; }

function PosterModal({ poem, summary, onClose }: { poem: Poem; summary: string; onClose: () => void }) {
  const svg = useMemo(() => createPosterSvg(poem, summary), [poem, summary]);
  const [busy, setBusy] = useState(false);
  const save = async () => { setBusy(true); try { const blob = await posterBlob(svg); const link = document.createElement("a"); link.download = `2025诗篇-${poem.title}.png`; link.href = URL.createObjectURL(blob); link.click(); URL.revokeObjectURL(link.href); } finally { setBusy(false); } };
  const share = async () => { setBusy(true); try { const blob = await posterBlob(svg); const file = new File([blob], `2025诗篇-${poem.title}.png`, { type: "image/png" }); if (navigator.share && (!navigator.canShare || navigator.canShare({ files: [file] }))) await navigator.share({ title: `2025诗篇 · ${poem.title}`, text: "来自《2025 诗篇》的分享海报", files: [file] }); else await save(); } finally { setBusy(false); } };
  return <div className="poster-backdrop" role="dialog" aria-modal="true" aria-label="分享海报预览"><div className="poster-modal"><div className="poster-modal-head"><div><p>分享海报</p><small>将这一首诗保存为一张纸</small></div><button onClick={onClose} aria-label="关闭"><X size={20} /></button></div><div className="poster-preview" dangerouslySetInnerHTML={{ __html: svg }} /><div className="poster-actions"><button onClick={save} disabled={busy}><Download size={16} /> {busy ? "处理中…" : "保存图片"}</button><button onClick={share} disabled={busy} className="poster-share"><Share2 size={16} /> 分享</button></div></div></div>;
}

function useInterpretation(id: number | null, initialContent = "") {
  const [content, setContent] = useState(initialContent); const [loading, setLoading] = useState(false); const [error, setError] = useState("");
  const run = () => { if (!id || loading) return; setContent(""); setError(""); setLoading(true); const source = new EventSource(`/api/poems/${id}/interpretation`); source.onmessage = event => { if (event.data === "[DONE]") { source.close(); setLoading(false); return; } const payload = JSON.parse(event.data); if (payload.error) { setError(payload.error); source.close(); setLoading(false); return; } setContent(prev => prev + (payload.chunk ?? "")); }; source.onerror = () => { source.close(); setLoading(false); if (!content) setError("赏析生成失败，请稍后再试。"); }; };
  useEffect(() => { setContent(initialContent); setError(""); setLoading(false); }, [id, initialContent]);
  return { content, loading, error, run };
}

function useSoundscape() {
  const contextRef = useRef<AudioContext | null>(null); const masterRef = useRef<GainNode | null>(null); const nodesRef = useRef<AudioNode[]>([]); const lastActiveModeRef = useRef<Exclude<SoundMode, "off">>("nature"); const [mode, setMode] = useState<SoundMode>("off"); const [volume, setVolumeState] = useState(0.18);
  const stop = useCallback(() => { nodesRef.current.forEach(node => { try { const stoppable = node as AudioBufferSourceNode | OscillatorNode; stoppable.stop?.(); } catch {} try { node.disconnect(); } catch {} }); nodesRef.current = []; masterRef.current = null; }, []);
  const ensureContext = useCallback(() => { if (!contextRef.current) contextRef.current = new AudioContext(); return contextRef.current; }, []);
  const start = useCallback((nextMode: SoundMode) => { if (nextMode === "off") { stop(); return; } const context = ensureContext(); stop(); const master = context.createGain(); master.gain.value = volume; master.connect(context.destination); masterRef.current = master; const nodes: AudioNode[] = [master];
    if (nextMode === "music") { [261.63, 329.63, 392].forEach((frequency, index) => { const oscillator = context.createOscillator(); const gain = context.createGain(); oscillator.type = index === 1 ? "triangle" : "sine"; oscillator.frequency.value = frequency; gain.gain.value = index === 0 ? 0.08 : 0.045; oscillator.connect(gain).connect(master); oscillator.start(); nodes.push(oscillator, gain); }); }
    if (nextMode === "nature") { const buffer = context.createBuffer(1, context.sampleRate * 2, context.sampleRate); const data = buffer.getChannelData(0); for (let i = 0; i < data.length; i += 1) data[i] = (Math.random() * 2 - 1) * 0.35; const noise = context.createBufferSource(); noise.buffer = buffer; noise.loop = true; const filter = context.createBiquadFilter(); filter.type = "lowpass"; filter.frequency.value = 1700; const gain = context.createGain(); gain.gain.value = 0.1; noise.connect(filter).connect(gain).connect(master); noise.start(); const wind = context.createOscillator(); const windGain = context.createGain(); wind.type = "sine"; wind.frequency.value = 110; windGain.gain.value = 0.018; wind.connect(windGain).connect(master); wind.start(); nodes.push(noise, filter, gain, wind, windGain); }
    nodesRef.current = nodes; void context.resume();
  }, [ensureContext, stop, volume]);
  useEffect(() => { start(mode); return () => { if (mode === "off") stop(); }; }, [mode]);
  useEffect(() => { if (masterRef.current) masterRef.current.gain.value = volume; }, [volume]);
  const chooseMode = useCallback((nextMode: SoundMode) => { if (nextMode !== "off") lastActiveModeRef.current = nextMode; setMode(nextMode); }, []);
  const togglePause = useCallback(() => { const nextMode = toggleSoundMode(mode, lastActiveModeRef.current); if (nextMode !== "off") lastActiveModeRef.current = nextMode; setMode(nextMode); }, [mode]);
  const setVolume = useCallback((nextVolume: number) => setVolumeState(clampSoundVolume(nextVolume)), []);
  useEffect(() => () => { stop(); void contextRef.current?.close(); }, [stop]);
  return { mode, volume, setVolume, setMode: chooseMode, togglePause };
}

function SoundscapeControl({ mode, volume, setMode, setVolume, togglePause }: ReturnType<typeof useSoundscape>) { return <div className="soundscape-control"><div className="soundscape-copy"><span>{mode === "music" ? <Music2 size={14} /> : mode === "nature" ? <CloudRain size={14} /> : <VolumeX size={14} />}</span><div><strong>{mode === "music" ? "静谧和声" : mode === "nature" ? "雨落纸上" : "声音已静音"}</strong><small>阅读氛围</small></div></div><div className="soundscape-actions"><button aria-label="切换背景音乐" className={mode === "music" ? "active" : ""} onClick={() => setMode(mode === "music" ? "off" : "music")}><Music2 size={14} /></button><button aria-label="切换自然环境音" className={mode === "nature" ? "active" : ""} onClick={() => setMode(mode === "nature" ? "off" : "nature")}><CloudRain size={14} /></button><button aria-label={mode === "off" ? "恢复声音" : "暂停声音"} onClick={togglePause}>{mode === "off" ? <Volume2 size={14} /> : <Pause size={14} />}</button><input aria-label="声音音量" type="range" min="0" max="0.4" step="0.01" value={volume} onChange={event => setVolume(Number(event.target.value))} /></div></div>; }

function Header({ onIndex }: { onIndex: () => void }) { return <header className="site-header"><Link href="/" className="brand" onClick={onIndex}><span className="brand-mark"><Feather size={16} /></span><span><strong>2025 诗篇</strong><small>一年之内的回声</small></span></Link><div className="header-rule" /><span className="header-year">精选二十首</span></header>; }

function IndexPage({ poems }: { poems: Poem[] }) { return <main className="index-shell"><section className="index-intro"><p className="eyebrow">A POETRY NOTEBOOK · 2025</p><h1>一年之内的<br /><em>回声</em></h1><p className="intro-copy">从村庄、山河、爱情与时间中，拾取二十个仍在发光的片段。每一首诗，都是一次回到自身的阅读。</p><div className="intro-meta"><span>20 首精选</span><span>古体与现代</span><span>附 AI 赏析</span></div></section><section className="poem-index"><div className="section-caption"><span>目录</span><span>2025 / 20</span></div>{poems.map(poem => <Link key={poem.id} href={`/poem/${poem.id}`} className="index-item"><span className="index-no">{String(poem.id).padStart(2, "0")}</span><span className="index-title">{poem.title}<small>{poem.note}</small></span><span className="index-form">{poem.form}</span><ArrowRight className="index-arrow" size={18} /></Link>)}</section></main>; }

function DetailPage({ poems, id }: { poems: Poem[]; id: number }) {
  const poem = poems.find(item => item.id === id); const currentIndex = poems.findIndex(item => item.id === id); const previous = poems[currentIndex - 1]; const next = poems[currentIndex + 1]; const interpretation = useInterpretation(poem?.id ?? null, poem?.interpretation ?? ""); const [showAI, setShowAI] = useState(false); const [showPoster, setShowPoster] = useState(Boolean(new URLSearchParams(window.location.search).has("poster") && poem?.interpretation)); const [pendingPoster, setPendingPoster] = useState(false); const [posterStage, setPosterStage] = useState<1 | 2 | null>(null);
  useEffect(() => { if (pendingPoster && interpretation.content && !interpretation.loading) { setPendingPoster(false); setPosterStage(2); window.setTimeout(() => { setPosterStage(null); setShowPoster(true); }, 720); } if (pendingPoster && interpretation.error) { setPendingPoster(false); setPosterStage(null); } }, [pendingPoster, interpretation.content, interpretation.loading, interpretation.error]);
  if (!poem) return <div className="loading-state">正在打开这首诗……</div>;
  const rawSummary = interpretation.content.replace(/[#*_`]/g, "").replace(/\s+/g, " ").trim(); const summary = rawSummary.split(/(?=意象与语言|余韵)/)[0].replace(/^阅读入口/, "").trim() || rawSummary;
  const paragraphs = poem.body.split("\n\n"); const handleAI = () => { setShowAI(true); if (!interpretation.content) interpretation.run(); }; const handlePoster = () => { if (summary) { setPosterStage(2); window.setTimeout(() => { setPosterStage(null); setShowPoster(true); }, 720); return; } setPendingPoster(true); setPosterStage(1); setShowAI(true); interpretation.run(); };
  return <main className="reader-shell"><div className="reader-top"><Link href="/" className="back-link"><ArrowLeft size={16} /> 返回目录</Link><span>{String(poem.id).padStart(2, "0")} / 20</span></div><article className="poem-article"><div className="poem-kicker"><span>{poem.form}</span><span>2025</span></div><h1>{poem.title}</h1><p className="poem-note">{poem.note}</p><div className="poem-body">{paragraphs.map((paragraph, index) => <p key={index}>{paragraph.split("\n").map((line, lineIndex, lines) => <span key={lineIndex}>{line}{lineIndex < lines.length - 1 && <br />}</span>)}</p>)}</div><div className="poem-footer"><span>选自《2025》</span><div className="poem-actions"><button className="poster-button" onClick={handlePoster} disabled={interpretation.loading}><Share2 size={15} /> {interpretation.loading ? "准备中…" : "生成海报"}</button><button className="ai-button" onClick={handleAI}><Sparkles size={15} /> AI 解读</button></div></div></article><nav className="poem-nav">{previous ? <Link href={`/poem/${previous.id}`} className="nav-card"><ArrowLeft size={18} /><span><small>上一首</small>{previous.title}</span></Link> : <span />}{next ? <Link href={`/poem/${next.id}`} className="nav-card nav-next"><span><small>下一首</small>{next.title}</span><ArrowRight size={18} /></Link> : <span />}</nav>{showAI && <section className="ai-panel"><div className="ai-heading"><span className="ai-icon"><Sparkles size={15} /></span><div><p>AI 赏析</p><small>一场与诗意的缓慢对话</small></div><button onClick={() => setShowAI(false)} aria-label="关闭赏析">×</button></div>{interpretation.loading && !interpretation.content ? <div className="ai-loading"><span /><span /><span />正在阅读这首诗</div> : interpretation.error ? <div className="ai-error">{interpretation.error}<button onClick={interpretation.run}>重新生成</button></div> : <div className="ai-content"><Streamdown>{interpretation.content}</Streamdown>{interpretation.loading && <span className="stream-caret" />}</div>}</section>}{posterStage && <PosterLoading stage={posterStage} />}{showPoster && <PosterModal poem={poem} summary={summary} onClose={() => setShowPoster(false)} />}</main>;
}

export default function Home() { const [match, params] = useRoute("/poem/:id"); const { data: poems, isLoading } = trpc.poems.list.useQuery(); const [, navigate] = useLocation(); const safePoems = useMemo(() => poems ?? [], [poems]); const soundscape = useSoundscape(); if (isLoading) return <div className="loading-state">正在整理诗篇……</div>; return <div className="site-frame"><Header onIndex={() => navigate("/")} /><SoundscapeControl {...soundscape} />{match ? <DetailPage poems={safePoems} id={Number(params?.id)} /> : <IndexPage poems={safePoems} />}<footer className="site-footer"><BookOpen size={14} /><span>愿每一次阅读，都把时间还给自己。</span></footer></div>; }

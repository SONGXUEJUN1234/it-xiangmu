const quotes = [
  '愿你今天也被温柔以待。', '别急，慢慢来，你已经做得很好了。', '记得喝口水，也记得照顾好自己。', '今天的你，值得一份小小的奖励。', '累了就休息一下，生活不需要一直冲刺。', '愿你心中有光，脚下有路。', '你不必完美，也一直值得被喜欢。', '把烦恼放一放，先给自己一个拥抱。', '每一个认真生活的你，都闪闪发光。', '今天也要对自己温柔一点。'
];
let config = {};
let timer;
const $ = (id) => document.getElementById(id);
function inQuietHours() {
  const now = new Date();
  const current = now.getHours() * 60 + now.getMinutes();
  const [sh, sm] = (config.quietStart || '22:00').split(':').map(Number);
  const [eh, em] = (config.quietEnd || '07:00').split(':').map(Number);
  const start = sh * 60 + sm, end = eh * 60 + em;
  return start > end ? current >= start || current < end : current >= start && current < end;
}
function speak(text) {
  if (!config.voice || !('speechSynthesis' in window)) return;
  speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(text);
  utter.lang = 'zh-CN'; utter.rate = .92; utter.pitch = 1.08; utter.volume = .9;
  speechSynthesis.speak(utter);
}
function sayQuote(force = false) {
  if (!force && inQuietHours()) return;
  const bubble = $('bubble');
  const text = quotes[Math.floor(Math.random() * quotes.length)];
  bubble.classList.remove('pop'); void bubble.offsetWidth; bubble.classList.add('pop'); bubble.textContent = text;
  $('pet').style.animation = 'none'; void $('pet').offsetWidth; $('pet').style.animation = '';
  speak(text);
  $('status').textContent = '刚刚送来一句关心 · 下次提醒稍后到来';
}
function schedule() {
  clearInterval(timer);
  const minutes = Number(config.interval || 30);
  timer = setInterval(() => sayQuote(false), minutes * 60 * 1000);
}
function fillSettings() {
  $('interval').value = String(config.interval || 30); $('voice').checked = config.voice !== false;
  $('startup').checked = Boolean(config.startup); $('quietStart').value = config.quietStart || '22:00'; $('quietEnd').value = config.quietEnd || '07:00';
}
$('sayBtn').onclick = () => sayQuote(true);
$('settingsBtn').onclick = () => $('settings').classList.toggle('open');
$('closeBtn').onclick = () => window.spriteAPI.hide();
$('saveBtn').onclick = async () => {
  config = await window.spriteAPI.saveConfig({ interval: Number($('interval').value), voice: $('voice').checked, startup: $('startup').checked, quietStart: $('quietStart').value, quietEnd: $('quietEnd').value });
  schedule(); $('status').textContent = '设置已保存 · 暖心守护中'; $('status').classList.add('saved'); setTimeout(() => $('status').classList.remove('saved'), 1500);
};
window.spriteAPI.onSayNow(() => sayQuote(true));
(async () => { config = await window.spriteAPI.getConfig(); fillSettings(); schedule(); setTimeout(() => sayQuote(true), 1200); })();

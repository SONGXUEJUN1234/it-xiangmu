import { useId, useState } from "react";
import type { Brand } from "./model";

const palettes: Record<string, [string, string, string]> = {
  restaurant: ["#e8d9bf", "#8f402d", "#c09760"],
  food: ["#eee0c9", "#a66e39", "#d5af6a"],
  tea: ["#dce4d5", "#496650", "#8e9c6c"],
  seasoning: ["#e5d6bf", "#835538", "#be8550"],
  medicine: ["#e2ddc8", "#696447", "#b29260"],
  drink: ["#e5d5cd", "#80494d", "#c7a28b"],
  daily: ["#dce5e3", "#527779", "#98b7ad"],
  clothing: ["#dde2e8", "#5c7184", "#9bafbb"],
  craft: ["#e3dce7", "#726078", "#b8a0bb"],
};

export function BrandArt({
  category,
  compact = false,
}: {
  category: string;
  compact?: boolean;
}) {
  const id = useId().replace(/:/g, "");
  const [bg, ink, accent] = palettes[category] || palettes.food;
  return (
    <svg className="brand-art" viewBox="0 0 360 230" aria-hidden="true">
      <defs>
        <pattern id={id} width="14" height="14" patternUnits="userSpaceOnUse">
          <circle cx="2" cy="2" r=".6" fill={ink} opacity=".1" />
        </pattern>
        <linearGradient id={`${id}g`} x2=".5" y2="1">
          <stop stopColor="#fff" stopOpacity=".25" />
          <stop offset="1" stopColor={ink} stopOpacity=".08" />
        </linearGradient>
      </defs>
      <rect width="360" height="230" fill={bg} />
      <rect width="360" height="230" fill={`url(#${id})`} />
      <circle cx="268" cy="67" r="76" fill="#fff" opacity=".22" />
      <path d="M0 190Q110 150 360 185V230H0Z" fill={ink} opacity=".055" />
      <ellipse cx="185" cy="186" rx="112" ry="15" fill={ink} opacity=".12" />
      {category === "tea" || category === "daily" ? (
        <g stroke={ink} strokeWidth="2.5">
          <path d="M98 103Q80 69 63 82Q48 101 101 129" fill="none" />
          <path
            d="M106 106Q111 86 145 86Q181 86 185 116L204 105L198 129L184 137Q178 177 140 177Q99 174 99 139Z"
            fill={accent}
          />
          <ellipse cx="141" cy="92" rx="27" ry="6" fill={ink} />
          <path d="M135 85v-8h13v8" fill={ink} />
          <path d="M224 150h64l-8 25h-48Z" fill={bg} />
          <ellipse cx="256" cy="151" rx="32" ry="6" fill={accent} />
          <path
            d="M228 94Q250 69 254 40Q274 55 250 80M260 112Q276 91 302 99Q284 119 260 112"
            fill={ink}
            stroke="none"
            opacity=".85"
          />
          <path d="M241 128Q250 78 275 62" fill="none" />
          <path
            d="M239 134q-9-13 0-23M253 135q-9-13 0-23"
            fill="none"
            opacity=".3"
          />
        </g>
      ) : category === "medicine" ? (
        <g stroke={ink} strokeWidth="2.5">
          <rect x="92" y="54" width="169" height="124" rx="5" fill={accent} />
          <rect x="87" y="45" width="179" height="12" rx="2" fill={ink} />
          {[0, 1, 2].map((row) =>
            [0, 1, 2].map((col) => (
              <g key={`${row}${col}`}>
                <rect
                  x={99 + col * 53}
                  y={64 + row * 36}
                  width="46"
                  height="29"
                  rx="2"
                  fill={bg}
                />
                <path d={`M${114 + col * 53} ${80 + row * 36}h16`} />
                <circle
                  cx={122 + col * 53}
                  cy={86 + row * 36}
                  r="1"
                  fill={ink}
                />
              </g>
            )),
          )}
          <path
            d="M238 180q14-39 34-40q-2 25-34 40M241 172q-7-30-24-34q-7 22 24 34"
            fill={ink}
          />
          <ellipse cx="91" cy="184" rx="22" ry="8" fill={bg} />
        </g>
      ) : category === "seasoning" || category === "drink" ? (
        <g stroke={ink} strokeWidth="2.5">
          <path
            d="M120 79h39v26q28 14 28 37v34q-47 13-94 0v-34q0-23 27-37Z"
            fill={ink}
          />
          <rect x="117" y="65" width="45" height="18" rx="4" fill={accent} />
          <path d="M110 123h60v45h-60Z" fill={bg} />
          <path d="M129 133h22M129 143h22M129 153h22" stroke={accent} />
          <path
            d="M224 54h25v58q22 16 22 38v29q-37 12-75 0v-29q0-22 28-38Z"
            fill={accent}
          />
          <rect x="220" y="46" width="33" height="13" rx="3" fill={ink} />
          <rect x="213" y="134" width="43" height="36" rx="2" fill={bg} />
          <circle cx="234" cy="152" r="10" fill="none" />
          <path d="M279 170l18 12-20 9 5-21 11 23" fill={accent} />
        </g>
      ) : category === "clothing" ? (
        <g stroke={ink} strokeWidth="3">
          <path
            d="M115 64l33-15 31 20 31-20 33 15 42 45-34 25-20-22v69H127v-69l-20 22-34-25Z"
            fill={accent}
          />
          <path d="M148 49l31 34 31-34M179 83v97" fill="none" />
          {[98, 119, 140, 161].map((y) => (
            <path d={`M175 ${y}h14`} key={y} />
          ))}
          <path d="M134 141h28v22h-28" fill={bg} />
        </g>
      ) : category === "craft" ? (
        <g stroke={ink} strokeWidth="2.5">
          <path
            d="M136 85h65l-11 34q37 30 32 54q-46 24-92 0q-5-24 32-54Z"
            fill={accent}
          />
          <ellipse cx="168" cy="86" rx="33" ry="8" fill={bg} />
          <path d="M150 145q25-30 44 14M148 159q19-24 44 0" fill="none" />
          <path d="M245 51l-22 108 6 23 13-20 16-108" fill={ink} />
        </g>
      ) : (
        <g stroke={ink} strokeWidth="2.5">
          <path d="M85 134v32q96 49 192 0v-32" fill={accent} />
          <ellipse cx="181" cy="132" rx="96" ry="32" fill={bg} />
          <path
            d="M90 152q91 42 182 0M102 147v25M126 156v24M153 164v21M184 165v22M215 162v21M246 154v23M266 146v25"
            fill="none"
            opacity=".6"
          />
          {[
            [132, 123],
            [183, 140],
            [218, 111],
          ].map(([x, y], i) => (
            <g key={i}>
              <path
                d={`M${x - 26} ${y}q0-26 26-31q26 5 26 31q-26 17-52 0`}
                fill={category === "restaurant" ? "#f8efd9" : "#cfaa65"}
              />
              <path
                d={`M${x} ${y - 28}l-9 23M${x} ${y - 28}l9 23M${x} ${y - 28}v25`}
                fill="none"
                stroke={accent}
              />
            </g>
          ))}
          <path
            d="M137 77q-12-14 0-28M180 63q-12-14 0-28M222 71q-12-14 0-28"
            fill="none"
            opacity=".35"
          />
        </g>
      )}
      <rect width="360" height="230" fill={`url(#${id}g)`} />
      {!compact && (
        <g fill={ink} opacity=".28">
          <path d="M21 27h38M21 35h23M301 200h38M316 208h23" stroke={ink} />
        </g>
      )}
    </svg>
  );
}
export function BrandImage({
  brand,
  compact = false,
}: {
  brand: Brand;
  compact?: boolean;
}) {
  const [failedUrl, setFailedUrl] = useState("");
  const actual = brand.image && brand.image.url !== failedUrl;
  return (
    <div className={`brand-image ${compact ? "compact" : ""}`}>
      {actual ? (
        <img
          src={brand.image!.url}
          alt={brand.image!.alt}
          loading="lazy"
          referrerPolicy="no-referrer"
          onError={() => setFailedUrl(brand.image!.url)}
        />
      ) : (
        <BrandArt category={brand.categories[0]} compact={compact} />
      )}
      {!compact && (
        <span className="image-credit">
          {actual ? "品牌图片" : "品类插画 · 非品牌实拍"}
        </span>
      )}
    </div>
  );
}

export function StorefrontArt() {
  return (
    <svg
      className="storefront-art"
      viewBox="0 0 600 210"
      fill="none"
      aria-hidden="true"
    >
      <circle cx="456" cy="88" r="72" fill="#c6ad7b" opacity=".14" />
      <path
        d="M2 193Q100 139 208 186Q372 149 595 190"
        stroke="#8c906c"
        opacity=".3"
      />
      <g stroke="#9c8260" strokeWidth="1.3" opacity=".62">
        <path d="M94 187V95h310v92M80 99h339l-15-16H97Z" fill="#f1e6cf" />
        <path
          d="M112 81l30-21h217l30 21M119 57h266l-22-15H141Z"
          fill="#e6d5b4"
        />
        <path d="M150 40l35-20h134l30 20M132 104v81M366 103v82M208 106v79M300 106v79" />
        <rect
          x="220"
          y="102"
          width="67"
          height="83"
          fill="#ac7455"
          fillOpacity=".17"
        />
        <path d="M253 104v79M224 119h59M224 126h59M105 186h304M96 193h322M116 81v13M131 81v13M146 81v13M162 81v13M178 81v13M194 81v13M210 81v13M226 81v13M242 81v13M258 81v13M274 81v13M290 81v13M306 81v13M322 81v13M338 81v13M354 81v13M370 81v13M386 81v13" />
        <rect
          x="225"
          y="53"
          width="57"
          height="22"
          rx="1"
          fill="#a33e2c"
          fillOpacity=".75"
          stroke="none"
        />
        <path
          d="M235 59h8v10h-8M251 59h8v10h-8M267 59h8v10h-8"
          stroke="#f1e6cf"
        />
        <rect x="144" y="116" width="51" height="48" />
        <rect x="312" y="116" width="41" height="48" />
        <path d="M154 116v48M164 116v48M175 116v48M186 116v48M322 116v48M332 116v48M342 116v48M144 134h51M312 134h41" />
        <path d="M123 101v17M385 101v17" />
        <ellipse
          cx="123"
          cy="129"
          rx="9"
          ry="15"
          fill="#a33e2c"
          fillOpacity=".7"
        />
        <ellipse
          cx="385"
          cy="129"
          rx="9"
          ry="15"
          fill="#a33e2c"
          fillOpacity=".7"
        />
        <path d="M123 144v10M385 144v10" />
        <path d="M449 188q-3-75 14-140M455 107q-35-29-52-19M454 140q38-31 60-21" />
        <path
          d="M449 88q-39-17-51-2q18 19 51 2M454 115q44-39 68-11q-27 27-68 11M460 71q-28-44-43-23q-3 23 43 23M463 64q44-37 50-11q-10 19-50 11"
          fill="#8c906c"
          fillOpacity=".2"
        />
        <path
          d="M51 177h29v12H51zM56 162h19v15H56zM45 161h39l-19-11Z"
          fill="#c6ad7b"
          fillOpacity=".2"
        />
      </g>
    </svg>
  );
}
